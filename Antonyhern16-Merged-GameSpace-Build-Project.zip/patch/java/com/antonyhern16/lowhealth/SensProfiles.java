package com.antonyhern16.lowhealth;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Locally stored sensitivity profiles (survive restarts). Linked to games by package name. */
final class SensProfiles {
    static final String[] KEYS = {"cam", "ads", "gyro", "adsGyro", "red", "x2", "x3", "x4", "x6", "x8", "sniper", "vmult"};
    static final String[] LABELS = {"Camera", "ADS", "Gyroscope", "ADS gyroscope", "Red dot", "2x scope", "3x scope",
            "4x scope", "6x scope", "8x scope", "Sniper", "Vertical multiplier"};
    static final float[] DEF = {100, 60, 200, 120, 50, 40, 30, 25, 20, 15, 10, 1.0f};
    static final float[] MAX = {300, 300, 600, 600, 300, 300, 300, 300, 300, 300, 300, 2.0f};
    private static final String K = "sens_profiles";

    private SensProfiles() {}

    static JSONArray all(Context c) {
        try { return new JSONArray(Store.sp(c).getString(K, "[]")); } catch (Exception e) { return new JSONArray(); }
    }

    static void save(Context c, JSONArray a) { Store.sp(c).edit().putString(K, a.toString()).apply(); }

    static JSONObject make(String name, String game) {
        JSONObject o = new JSONObject();
        try {
            o.put("name", name).put("game", game);
            for (int i = 0; i < KEYS.length; i++) o.put(KEYS[i], DEF[i]);
        } catch (Exception ignored) { }
        return o;
    }

    static void ensureDefault(Context c) {
        if (all(c).length() > 0) return;
        JSONArray a = new JSONArray();
        a.put(make("CODM default", "CODM"));
        a.put(make("PUBG default", "PUBG Mobile"));
        save(c, a);
    }

    static List<String> names(Context c) {
        List<String> l = new ArrayList<>();
        JSONArray a = all(c);
        for (int i = 0; i < a.length(); i++) l.add(a.optJSONObject(i).optString("name"));
        return l;
    }

    static JSONObject find(Context c, String name) {
        JSONArray a = all(c);
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && o.optString("name").equals(name)) return o;
        }
        return null;
    }

    static float get(JSONObject p, int i) { return p == null ? DEF[i] : (float) p.optDouble(KEYS[i], DEF[i]); }

    static String unique(Context c, String base) {
        List<String> n = names(c);
        String s = base;
        int k = 2;
        while (n.contains(s)) s = base + " " + (k++);
        return s;
    }

    private static void replace(Context c, String name, JSONObject neu) {
        JSONArray a = all(c), out = new JSONArray();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && o.optString("name").equals(name)) { if (neu != null) out.put(neu); } else out.put(o);
        }
        save(c, out);
    }

    static String add(Context c, String name, String game) {
        String n = unique(c, name.trim().isEmpty() ? "Profile" : name.trim());
        JSONArray a = all(c);
        a.put(make(n, game));
        save(c, a);
        return n;
    }

    static void setVal(Context c, String name, int idx, float v) {
        JSONObject o = find(c, name);
        if (o == null) return;
        try { o.put(KEYS[idx], v); } catch (Exception ignored) { }
        replace(c, name, o);
    }

    static void setGame(Context c, String name, String game) {
        JSONObject o = find(c, name);
        if (o == null) return;
        try { o.put("game", game); } catch (Exception ignored) { }
        replace(c, name, o);
    }

    static String duplicate(Context c, String name) {
        JSONObject o = find(c, name);
        if (o == null) return name;
        try {
            JSONObject d = new JSONObject(o.toString());
            String n = unique(c, name + " copy");
            d.put("name", n);
            JSONArray a = all(c);
            a.put(d);
            save(c, a);
            return n;
        } catch (Exception e) { return name; }
    }

    static String rename(Context c, String name, String neu) {
        JSONObject o = find(c, name);
        if (o == null || neu.trim().isEmpty()) return name;
        String n = neu.trim().equals(name) ? name : unique(c, neu.trim());
        try { o.put("name", n); } catch (Exception ignored) { }
        replace(c, name, o);
        return n;
    }

    static void reset(Context c, String name) {
        JSONObject o = find(c, name);
        if (o == null) return;
        try { for (int i = 0; i < KEYS.length; i++) o.put(KEYS[i], DEF[i]); } catch (Exception ignored) { }
        replace(c, name, o);
    }

    static void delete(Context c, String name) { replace(c, name, null); }

    static String export(Context c) { return all(c).toString(); }

    /** Accepts an exported array or a single profile. Returns how many profiles were added. */
    static int importJson(Context c, String text) {
        int n = 0;
        try {
            String t = text.trim();
            JSONArray in = t.startsWith("[") ? new JSONArray(t) : new JSONArray().put(new JSONObject(t));
            JSONArray a = all(c);
            for (int i = 0; i < in.length(); i++) {
                JSONObject o = in.optJSONObject(i);
                if (o == null) continue;
                JSONObject d = make(unique(c, o.optString("name", "Imported")), o.optString("game", "CODM"));
                for (int k = 0; k < KEYS.length; k++) {
                    float v = (float) o.optDouble(KEYS[k], DEF[k]);
                    d.put(KEYS[k], Math.max(0f, Math.min(MAX[k], v)));
                }
                a.put(d);
                n++;
            }
            save(c, a);
        } catch (Exception ignored) { }
        return n;
    }

    static String activeFor(Context c, String pkg) { return Store.sp(c).getString("prof_" + pkg, ""); }

    static void setActive(Context c, String pkg, String name) { Store.sp(c).edit().putString("prof_" + pkg, name).apply(); }
}
