package com.antonyhern16.lowhealth;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Offline aim-training drills. Everything happens on this screen against practice targets that
 * this app draws itself. It never reads or touches any other app.
 * Modes: "reaction", "switch", "track".
 */
public class TrainActivity extends Activity {
    static final String X_MODE = "mode", X_GAME = "game";
    private DrillView view;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        String mode = getIntent().getStringExtra(X_MODE);
        String game = getIntent().getStringExtra(X_GAME);
        view = new DrillView(this, mode == null ? "reaction" : mode, game == null ? "CODM" : game);
        setContentView(view);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (view != null) view.stop();
        if (!isFinishing() && !view.dialogShowing) finish();   // abandon an unfinished drill
    }

    // ---------------------------------------------------------------------------------------
    private static final class DrillView extends View {
        static final int IDLE = 0, WAIT = 1, GO = 2, SHOW = 3, RUN = 4, DONE = 5;
        final Activity act;
        final String mode, game;
        final Handler h = new Handler(Looper.getMainLooper());
        final Random rnd = new Random();
        final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), ring = new Paint(Paint.ANTI_ALIAS_FLAG), txt = new Paint(Paint.ANTI_ALIAS_FLAG);
        final float d;
        int state = IDLE;
        boolean dialogShowing = false;
        String msg = "";

        // reaction
        final List<Long> times = new ArrayList<>();
        int falseStarts = 0;
        long goAt;
        // switching
        static final int TARGETS = 20;
        int hits, misses;
        float tx, ty, tr;
        long appearAt;
        final List<Long> hitTimes = new ArrayList<>();
        // tracking
        static final float TRACK_SECONDS = 20f;
        float vx, vy, turnLeft, elapsed, onTime;
        float px, py;
        boolean down;
        long lastNs;

        final Runnable goRunnable = () -> {
            state = GO;
            goAt = SystemClock.uptimeMillis();
            invalidate();
        };
        final Runnable nextRound = this::startRound;

        DrillView(Activity a, String mode, String game) {
            super(a);
            act = a;
            this.mode = mode;
            this.game = game;
            d = a.getResources().getDisplayMetrics().density;
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(3 * d);
            txt.setColor(0xFFFFFFFF);
            txt.setTextAlign(Paint.Align.CENTER);
            txt.setTextSize(20 * d);
        }

        void stop() {
            h.removeCallbacksAndMessages(null);
        }

        // ---- drawing ---------------------------------------------------------------------
        @Override
        protected void onDraw(Canvas c) {
            int w = getWidth(), hgt = getHeight();
            float cx = w / 2f, cy = hgt / 2f;
            int bg = 0xFF0B0B0E;
            if ("reaction".equals(mode)) {
                if (state == WAIT) bg = 0xFF8A1020;
                else if (state == GO) bg = 0xFF12803F;
                else if (state == SHOW) bg = 0xFF22222A;
            }
            c.drawColor(bg);
            txt.setTextSize(20 * d);
            switch (mode) {
                case "reaction": drawReaction(c, cx, cy); break;
                case "switch": drawSwitch(c, cx, cy); break;
                default: drawTrack(c, cx, cy); break;
            }
            txt.setTextSize(12 * d);
            txt.setColor(0xFF9A9AA6);
            c.drawText(Store.modeName(mode) + " · " + game + " · offline practice only", cx, 30 * d, txt);
            txt.setColor(0xFFFFFFFF);
        }

        private void drawReaction(Canvas c, float cx, float cy) {
            String big, small = "";
            if (state == IDLE) { big = "Tap to start"; small = "5 rounds. Tap the instant the screen turns green."; }
            else if (state == WAIT) { big = "Wait for green..."; small = "Tapping early is a false start"; }
            else if (state == GO) { big = "TAP NOW"; }
            else { big = msg; small = times.size() + "/5 done"; }
            c.drawText(big, cx, cy, txt);
            txt.setTextSize(13 * d);
            c.drawText(small, cx, cy + 32 * d, txt);
        }

        private void drawSwitch(Canvas c, float cx, float cy) {
            if (state == IDLE) {
                c.drawText("Tap to start", cx, cy, txt);
                txt.setTextSize(13 * d);
                c.drawText("Hit " + TARGETS + " targets as fast as you can", cx, cy + 32 * d, txt);
                return;
            }
            fill.setColor(0xFFFF2D4B);
            c.drawCircle(tx, ty, tr, fill);
            fill.setColor(0xFF0B0B0E);
            c.drawCircle(tx, ty, tr * 0.45f, fill);
            txt.setTextSize(14 * d);
            c.drawText(hits + "/" + TARGETS + "   misses " + misses, cx, getHeight() - 24 * d, txt);
        }

        private void drawTrack(Canvas c, float cx, float cy) {
            if (state == IDLE) {
                c.drawText("Tap to start", cx, cy, txt);
                txt.setTextSize(13 * d);
                c.drawText("Keep your finger on the moving target for " + (int) TRACK_SECONDS + " s", cx, cy + 32 * d, txt);
                return;
            }
            long now = System.nanoTime();
            float dt = Math.min(0.05f, (now - lastNs) / 1e9f);
            lastNs = now;
            if (state == RUN) update(dt);
            boolean on = down && dist(px, py, tx, ty) <= tr * 1.3f;
            fill.setColor(on ? 0xFF35D07F : 0xFFFF2D4B);
            c.drawCircle(tx, ty, tr, fill);
            if (down) {
                ring.setColor(0xFFFFFFFF);
                c.drawCircle(px, py, tr * 0.45f, ring);
            }
            txt.setTextSize(14 * d);
            c.drawText(String.format(Locale.US, "%.0f s left   on target %.0f%%", Math.max(0, TRACK_SECONDS - elapsed), elapsed > 0 ? onTime / elapsed * 100 : 0), cx, getHeight() - 24 * d, txt);
            if (state == RUN) postInvalidateOnAnimation();
        }

        // ---- logic -----------------------------------------------------------------------
        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if ("track".equals(mode)) {
                if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_MOVE) {
                    px = e.getX();
                    py = e.getY();
                    down = true;
                } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    down = false;
                }
                if (a == MotionEvent.ACTION_DOWN && state == IDLE) startTrack();
                return true;
            }
            if (a != MotionEvent.ACTION_DOWN) return true;
            if ("reaction".equals(mode)) touchReaction(e);
            else touchSwitch(e);
            return true;
        }

        private void startRound() {
            state = WAIT;
            invalidate();
            h.postDelayed(goRunnable, 1500 + rnd.nextInt(2500));
        }

        private void touchReaction(MotionEvent e) {
            if (state == IDLE) {
                startRound();
            } else if (state == WAIT) {
                h.removeCallbacks(goRunnable);
                falseStarts++;
                msg = "Too early!";
                state = SHOW;
                invalidate();
                h.postDelayed(nextRound, 900);
            } else if (state == GO) {
                long rt = Math.max(0, e.getEventTime() - goAt);
                times.add(rt);
                msg = rt + " ms";
                if (times.size() >= 5) {
                    long sum = 0;
                    for (long t : times) sum += t;
                    finishDrill(sum / (double) times.size(), "false starts: " + falseStarts, false);
                } else {
                    state = SHOW;
                    invalidate();
                    h.postDelayed(nextRound, 900);
                }
            }
        }

        private void placeTarget() {
            float m = Math.min(getWidth(), getHeight());
            tr = 0.07f * m;
            float ox = tx, oy = ty;
            for (int i = 0; i < 20; i++) {
                tx = tr + 20 * d + rnd.nextFloat() * (getWidth() - 2 * tr - 40 * d);
                ty = tr + 60 * d + rnd.nextFloat() * (getHeight() - 2 * tr - 120 * d);
                if (hits == 0 || dist(tx, ty, ox, oy) > 0.25f * m) break;   // force a real target switch
            }
            appearAt = SystemClock.uptimeMillis();
        }

        private void touchSwitch(MotionEvent e) {
            if (state == IDLE) {
                state = RUN;
                hits = 0;
                misses = 0;
                hitTimes.clear();
                placeTarget();
                invalidate();
                return;
            }
            if (state != RUN) return;
            if (dist(e.getX(), e.getY(), tx, ty) <= tr) {
                hitTimes.add(Math.max(0, e.getEventTime() - appearAt));
                hits++;
                if (hits >= TARGETS) {
                    long sum = 0;
                    for (long t : hitTimes) sum += t;
                    int tries = hits + misses;
                    finishDrill(sum / (double) hitTimes.size(), String.format(Locale.US, "misses %d, accuracy %.0f%%", misses, hits * 100.0 / tries), false);
                    return;
                }
                placeTarget();
            } else {
                misses++;
            }
            invalidate();
        }

        private void startTrack() {
            state = RUN;
            elapsed = 0;
            onTime = 0;
            float m = Math.min(getWidth(), getHeight());
            tr = 0.08f * m;
            tx = getWidth() / 2f;
            ty = getHeight() / 2f;
            newHeading();
            lastNs = System.nanoTime();
            invalidate();
        }

        private void newHeading() {
            float m = Math.min(getWidth(), getHeight());
            double ang = rnd.nextDouble() * Math.PI * 2;
            float speed = m * (0.25f + rnd.nextFloat() * 0.3f);
            vx = (float) Math.cos(ang) * speed;
            vy = (float) Math.sin(ang) * speed;
            turnLeft = 0.4f + rnd.nextFloat() * 0.8f;
        }

        private void update(float dt) {
            elapsed += dt;
            turnLeft -= dt;
            if (turnLeft <= 0) newHeading();
            tx += vx * dt;
            ty += vy * dt;
            float minX = tr, maxX = getWidth() - tr, minY = tr + 50 * d, maxY = getHeight() - tr - 50 * d;
            if (tx < minX) { tx = minX; vx = Math.abs(vx); }
            if (tx > maxX) { tx = maxX; vx = -Math.abs(vx); }
            if (ty < minY) { ty = minY; vy = Math.abs(vy); }
            if (ty > maxY) { ty = maxY; vy = -Math.abs(vy); }
            if (down && dist(px, py, tx, ty) <= tr * 1.3f) onTime += dt;
            if (elapsed >= TRACK_SECONDS) {
                finishDrill(onTime / TRACK_SECONDS * 100.0, "", true);
            }
        }

        private static float dist(float a, float b, float c, float e) {
            float dx = a - c, dy = b - e;
            return (float) Math.sqrt(dx * dx + dy * dy);
        }

        private void finishDrill(double score, String extra, boolean higherIsBetter) {
            if (state == DONE) return;
            state = DONE;
            stop();
            Double prev = Store.best(act, game, mode);
            boolean saved = false;
            try {
                JSONObject o = new JSONObject();
                o.put("t", System.currentTimeMillis()).put("game", game).put("mode", mode)
                        .put("score", Math.round(score * 10) / 10.0).put("extra", extra);
                saved = Store.append(act, "train", o, 500);
            } catch (Exception ignored) {
            }
            boolean pb = prev == null || (Store.lowerBetter(mode) ? score < prev : score > prev);
            String body = String.format(Locale.US, "%.1f%s", score, Store.unit(mode)) + (extra.length() > 0 ? "\n" + extra : "")
                    + (prev != null ? String.format(Locale.US, "\nPrevious best: %.1f%s", prev, Store.unit(mode)) : "")
                    + (pb ? "\n\nNEW PERSONAL BEST" : "")
                    + (saved ? "" : "\n\nCould not save this result.")
                    + ("reaction".equals(mode) ? "\n\nIncludes your screen and touch delay, so compare it with your own earlier results rather than with other phones." : "");
            dialogShowing = true;
            new AlertDialog.Builder(act).setTitle(Store.modeName(mode)).setMessage(body)
                    .setCancelable(false)
                    .setPositiveButton("Done", (dd, w) -> act.finish())
                    .setNegativeButton("Again", (dd, w) -> {
                        act.recreate();
                    }).show();
        }
    }
}
