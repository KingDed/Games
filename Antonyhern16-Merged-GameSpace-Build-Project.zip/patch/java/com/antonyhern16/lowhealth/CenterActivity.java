package com.antonyhern16.lowhealth;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.hardware.input.InputManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.TrafficStats;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * One screen for the Game Space centers: network, cooling, display, graphics, controllers, stats, notes.
 * Live centers (network, cooling) refresh once a second only while the screen is visible.
 */
public class CenterActivity extends Activity {
    static final String EXTRA = "center";

    static Intent open(Context c, String center) {
        return new Intent(c, CenterActivity.class).putExtra(EXTRA, center);
    }

    private static final ArrayList<String> EVENTS = new ArrayList<>();
    private static String lastProbe = "No test run yet";

    private final Handler h = new Handler(Looper.getMainLooper());
    private String center = "network";
    private LinearLayout live;
    private EditText noteField;
    private boolean visible, probing;
    private long lastRx = -1, lastTx = -1, lastT = 0;
    private String throughput = "Measuring...";
    private ConnectivityManager cm;
    private ConnectivityManager.NetworkCallback netCb;
    private InputManager im;
    private InputManager.InputDeviceListener devCb;
    private final SimpleDateFormat clock = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());

    private int dp(float v) { return HubUi.dp(this, v); }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!visible) return;
            sampleThroughput();
            fillLive();
            h.postDelayed(this, 1000);
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        String c = getIntent() == null ? null : getIntent().getStringExtra(EXTRA);
        if (c != null) center = c;
        build();
    }

    private String title() {
        switch (center) {
            case "cooling": return "COOLING & CHARGING";
            case "display": return "DISPLAY & EXTERNAL DISPLAY";
            case "graphics": return "GRAPHICS INFO";
            case "controllers": return "CONTROLLER CENTER";
            case "stats": return "GAME STATISTICS";
            case "notes": return "GAME NOTES";
            default: return "NETWORK CENTER";
        }
    }

    private void build() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(HubUi.BG);
        sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(28), dp(18), dp(30));
        sv.addView(root);
        setContentView(sv);

        TextView back = HubUi.text(this, "\u2039  BACK", 13, HubUi.ACCENT, true);
        back.setPadding(0, dp(8), dp(16), dp(8));
        back.setOnClickListener(v -> finish());
        root.addView(back);
        root.addView(HubUi.text(this, "GAME SPACE \u2022 " + title(), 20, Color.WHITE, true));
        root.addView(HubUi.text(this, CapabilityMatrix.deviceSummary(this), 11, HubUi.DIM, false));

        if ("network".equals(center)) {
            root.addView(HubUi.text(this, "Latency is measured by timing real TCP connections. Nothing is estimated.", 12, 0xFFFF8796, false));
            root.addView(HubUi.button(this, "RUN LATENCY TEST (10 probes)", true, v -> runProbe()));
        } else if ("display".equals(center)) {
            root.addView(HubUi.button(this, "OPEN ANDROID DISPLAY SETTINGS", false,
                    v -> safeStart(new Intent(Settings.ACTION_DISPLAY_SETTINGS))));
        } else if ("stats".equals(center) && !GameCenters.hasUsageAccess(this)) {
            root.addView(HubUi.button(this, "GRANT USAGE ACCESS FOR PLAY TIME", false,
                    v -> safeStart(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))));
        } else if ("notes".equals(center)) {
            String g = gamePkg();
            root.addView(HubUi.text(this, g.length() == 0 ? "Notes for: all games (pick a game in Booster to add per-game notes)"
                    : "Notes for: " + gameLabel(g) + " (plus general notes)", 12, HubUi.DIM, false));
            noteField = HubUi.field(this, "Write a note...", false);
            noteField.setSingleLine(false);
            noteField.setMinLines(2);
            root.addView(noteField);
            root.addView(HubUi.button(this, "ADD NOTE", true, v -> {
                String t = noteField.getText().toString().trim();
                if (t.length() == 0) { HubUi.toast(this, "Type something first"); return; }
                GameCenters.addNote(this, gamePkg(), t);
                noteField.setText("");
                fillLive();
            }));
            root.addView(HubUi.button(this, "PASTE FROM CLIPBOARD (reads only when you tap)", false, v -> pasteClip()));
        }
        live = new LinearLayout(this);
        live.setOrientation(LinearLayout.VERTICAL);
        root.addView(live, new LinearLayout.LayoutParams(-1, -2));
        fillLive();
    }

    @Override protected void onStart() {
        super.onStart();
        visible = true;
        if ("network".equals(center)) registerNet();
        if ("controllers".equals(center)) registerDevices();
        if ("network".equals(center) || "cooling".equals(center)) {
            lastRx = -1; lastTx = -1;
            h.post(tick);
        } else {
            fillLive();
        }
    }

    @Override protected void onStop() {
        visible = false;
        h.removeCallbacks(tick);
        try { if (cm != null && netCb != null) cm.unregisterNetworkCallback(netCb); } catch (Exception ignored) { }
        netCb = null;
        try { if (im != null && devCb != null) im.unregisterInputDeviceListener(devCb); } catch (Exception ignored) { }
        devCb = null;
        super.onStop();
    }

    // ------------------------------------------------------------------ live content
    private void fillLive() {
        if (live == null) return;
        live.removeAllViews();
        switch (center) {
            case "cooling": rows(live, "THERMAL, BATTERY & CHARGING", GameCenters.cooling(this)); break;
            case "display": rows(live, "DISPLAY", GameCenters.display(this)); break;
            case "graphics": rows(live, "GRAPHICS", GameCenters.graphics(this)); break;
            case "controllers": rows(live, "INPUT DEVICES", GameCenters.controllers(this)); break;
            case "stats": rows(live, "LAUNCHES & PLAY TIME", GameCenters.stats(this)); break;
            case "notes": notesList(); break;
            default: networkCards(); break;
        }
    }

    private void networkCards() {
        rows(live, "CONNECTION", GameCenters.network(this));
        LinearLayout t = HubUi.card(this, live);
        t.addView(HubUi.text(this, "LIVE TRAFFIC (this device)", 13, HubUi.ACCENT, true));
        t.addView(HubUi.text(this, throughput, 12, Color.WHITE, false));
        LinearLayout p = HubUi.card(this, live);
        p.addView(HubUi.text(this, "LATENCY TEST", 13, HubUi.ACCENT, true));
        p.addView(HubUi.text(this, probing ? "Testing..." : lastProbe, 12, Color.WHITE, false));
        LinearLayout e = HubUi.card(this, live);
        e.addView(HubUi.text(this, "NETWORK CHANGE EVENTS", 13, HubUi.ACCENT, true));
        if (EVENTS.isEmpty()) e.addView(HubUi.text(this, "No changes seen while this screen was open", 11, HubUi.DIM, false));
        for (int i = EVENTS.size() - 1; i >= 0 && i >= EVENTS.size() - 12; i--)
            e.addView(HubUi.text(this, EVENTS.get(i), 11, Color.WHITE, false));
    }

    private void rows(LinearLayout parent, String head, List<GameCenters.Row> list) {
        LinearLayout c = HubUi.card(this, parent);
        c.addView(HubUi.text(this, head, 13, HubUi.ACCENT, true));
        for (GameCenters.Row r : list) {
            int col = r.s == GameCenters.OK ? HubUi.GOOD : r.s == GameCenters.WARN ? HubUi.WARN : HubUi.DIM;
            c.addView(HubUi.text(this, r.k, 11, HubUi.DIM, false));
            TextView v = HubUi.text(this, r.v, 13, col, true);
            v.setPadding(0, 0, 0, dp(6));
            c.addView(v);
        }
    }

    // ------------------------------------------------------------------ network helpers
    private void sampleThroughput() {
        if (!"network".equals(center)) return;
        long now = System.currentTimeMillis();
        long rx = TrafficStats.getTotalRxBytes(), tx = TrafficStats.getTotalTxBytes();
        if (rx == TrafficStats.UNSUPPORTED || tx == TrafficStats.UNSUPPORTED) {
            throughput = "N/A (traffic counters not supported on this device)";
            return;
        }
        if (lastRx >= 0 && now > lastT) {
            double s = (now - lastT) / 1000.0;
            throughput = String.format(Locale.US, "Download %.0f KB/s   Upload %.0f KB/s", (rx - lastRx) / 1024.0 / s, (tx - lastTx) / 1024.0 / s);
        }
        lastRx = rx; lastTx = tx; lastT = now;
    }

    private void runProbe() {
        if (probing) return;
        probing = true;
        fillLive();
        GameCenters.probe(10, (summary, ok) -> {
            probing = false;
            lastProbe = clock.format(new Date()) + "\n" + summary;
            if (visible) fillLive();
        });
    }

    private void registerNet() {
        cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        netCb = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network n) { log("Connected: " + describe(n)); }
            @Override public void onLost(Network n) { log("Connection lost"); }
        };
        try { cm.registerDefaultNetworkCallback(netCb, h); } catch (Exception e) { netCb = null; }
    }

    private String describe(Network n) {
        NetworkCapabilities nc = cm.getNetworkCapabilities(n);
        if (nc == null) return "network";
        return nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ? "Wi-Fi"
                : nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ? "Mobile data" : "other network";
    }

    private void log(String s) {
        EVENTS.add(clock.format(new Date()) + "  " + s);
        while (EVENTS.size() > 40) EVENTS.remove(0);
    }

    // ------------------------------------------------------------------ controllers
    private void registerDevices() {
        im = (InputManager) getSystemService(Context.INPUT_SERVICE);
        devCb = new InputManager.InputDeviceListener() {
            @Override public void onInputDeviceAdded(int id) { fillLive(); }
            @Override public void onInputDeviceRemoved(int id) { fillLive(); }
            @Override public void onInputDeviceChanged(int id) { fillLive(); }
        };
        im.registerInputDeviceListener(devCb, h);
    }

    // ------------------------------------------------------------------ notes
    private String gamePkg() { return Store.sp(this).getString("boost_game", ""); }

    private String gameLabel(String pkg) {
        try { return getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(pkg, 0)).toString(); }
        catch (Exception e) { return pkg; }
    }

    private void pasteClip() {
        try {
            ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData d = cb.getPrimaryClip();
            CharSequence t = d != null && d.getItemCount() > 0 ? d.getItemAt(0).coerceToText(this) : null;
            if (t == null || t.length() == 0) { HubUi.toast(this, "Clipboard is empty or not readable"); return; }
            noteField.setText(t.toString());
        } catch (Exception e) {
            HubUi.toast(this, "Could not read the clipboard");
        }
    }

    private void notesList() {
        List<JSONObject> list = GameCenters.notes(this, gamePkg());
        LinearLayout c = HubUi.card(this, live);
        c.addView(HubUi.text(this, "YOUR NOTES (" + list.size() + ")", 13, HubUi.ACCENT, true));
        if (list.isEmpty()) c.addView(HubUi.text(this, "No notes yet. Notes are stored only on this phone.", 12, HubUi.DIM, false));
        SimpleDateFormat f = new SimpleDateFormat("MMM d, HH:mm", Locale.getDefault());
        for (final JSONObject o : list) {
            LinearLayout n = HubUi.card(this, c);
            boolean pin = o.optBoolean("p");
            n.addView(HubUi.text(this, (pin ? "\uD83D\uDCCC " : "") + f.format(new Date(o.optLong("t")))
                    + (o.optString("g").length() == 0 ? "  \u2022 General" : "  \u2022 " + gameLabel(o.optString("g"))), 10, HubUi.DIM, false));
            n.addView(HubUi.text(this, o.optString("x"), 13, Color.WHITE, false));
            final long id = o.optLong("id");
            LinearLayout row = new LinearLayout(this);
            row.addView(HubUi.button(this, pin ? "UNPIN" : "PIN", false, v -> { GameCenters.editNote(this, id, true, false); fillLive(); }),
                    new LinearLayout.LayoutParams(0, dp(44), 1f));
            row.addView(HubUi.button(this, "DELETE", false, v -> { GameCenters.editNote(this, id, false, true); fillLive(); }),
                    new LinearLayout.LayoutParams(0, dp(44), 1f));
            n.addView(row);
        }
    }

    private void safeStart(Intent i) {
        try { startActivity(i); } catch (Exception e) { HubUi.toast(this, "This screen is not available on your device"); }
    }
}
