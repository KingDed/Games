package com.antonyhern16.lowhealth;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.view.Choreographer;
import android.view.WindowManager;

import java.io.BufferedReader;
import java.io.FileReader;
import java.net.InetSocketAddress;
import java.net.Socket;

/** Real device readings shared by the Shooter Center. Nothing here is estimated or invented. */
final class PerfInfo {
    static volatile long pingMs = -1;
    private static volatile boolean pinging = false;

    private PerfInfo() {}

    static synchronized void startPing() {
        if (pinging) return;
        pinging = true;
        Thread t = new Thread(() -> {
            while (pinging) {
                long t0 = System.nanoTime();
                long v = -1;
                try (Socket s = new Socket()) {
                    s.connect(new InetSocketAddress("1.1.1.1", 443), 1500);
                    v = (System.nanoTime() - t0) / 1000000L;
                } catch (Exception ignored) { }
                pingMs = v;
                try { Thread.sleep(2000); } catch (InterruptedException e) { return; }
            }
        });
        t.setDaemon(true);
        t.start();
    }

    static void stopPing() { pinging = false; }

    /** Highest current core frequency in GHz, or 0 when Android does not let apps read it. */
    static double cpuGhz() {
        long best = 0;
        for (int i = 0; i < 16; i++) {
            try (BufferedReader r = new BufferedReader(new FileReader("/sys/devices/system/cpu/cpu" + i + "/cpufreq/scaling_cur_freq"))) {
                best = Math.max(best, Long.parseLong(r.readLine().trim()));
            } catch (Exception ignored) { }
        }
        return best / 1000000.0;
    }

    static float ramUsedFrac(Context c) {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ((ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(mi);
        return 1f - (float) mi.availMem / mi.totalMem;
    }

    static int battery(Context c) {
        Intent b = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        return b == null ? 0 : b.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
    }

    static int hz(Context c) {
        try {
            return Math.round(((WindowManager) c.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRefreshRate());
        } catch (Exception e) { return 0; }
    }

    /** Measures how many frames per second THIS app actually renders. */
    static final class Fps implements Choreographer.FrameCallback {
        volatile float fps = 0;
        private long start = 0;
        private int n = 0;
        private boolean on = false;

        void start() {
            if (on) return;
            on = true; start = 0; n = 0;
            Choreographer.getInstance().postFrameCallback(this);
        }

        void stop() { on = false; }

        @Override public void doFrame(long t) {
            if (!on) return;
            if (start == 0) start = t;
            n++;
            long span = t - start;
            if (span >= 500000000L) {
                fps = n * 1e9f / span;
                start = t; n = 0;
            }
            Choreographer.getInstance().postFrameCallback(this);
        }
    }
}
