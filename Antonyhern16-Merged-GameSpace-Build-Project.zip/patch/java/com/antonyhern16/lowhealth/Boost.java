package com.antonyhern16.lowhealth;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.NotificationManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.StatFs;
import android.provider.Settings;
import android.view.Display;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Booster panel: permission checklist, live device status, one-tap boost and launch, stats overlay,
 * network latency test. Uses only normal Android APIs: it frees cached background apps, turns on
 * Do Not Disturb, raises brightness and starts your game. It does not touch the game or its input.
 */
final class Boost {
    private static final String[][] GAMES = {
            {"CODM", "com.activision.callofduty.shooter"},
            {"CODM (Garena)", "com.garena.game.codm"},
            {"PUBG Mobile", "com.tencent.ig"},
            {"BGMI", "com.pubg.imobile"},
            {"Free Fire", "com.dts.freefireth"},
            {"Standoff 2", "com.axlebolt.standoff2"}};
    private static final String[][] TOGGLES = {
            {"b_clean", "Free RAM (close background apps)"},
            {"b_dnd", "Do Not Disturb while playing"},
            {"b_bright", "Max brightness"},
            {"b_overlay", "Live stats overlay in game"},
            {"b_ping", "Check connection before launch"}};

    private Boost() {}

    // ------------------------------------------------------------------ status helpers

    static String statsLine(Context c, String time) {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ((ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(mi);
        Intent b = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        float temp = b == null ? 0 : b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f;
        int lvl = b == null ? 0 : b.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
        return String.format(Locale.US, "%s  RAM %.1fG free  %.1f\u00B0C  %d%%  %s", time,
                mi.availMem / 1073741824.0, temp, lvl, thermal(c));
    }

    static String thermal(Context c) {
        try {
            int t = ((PowerManager) c.getSystemService(Context.POWER_SERVICE)).getCurrentThermalStatus();
            String[] n = {"Cool", "Light", "Warm", "Hot", "Very hot", "Critical", "Shutdown"};
            return n[Math.max(0, Math.min(6, t))];
        } catch (Exception e) {
            return "?";
        }
    }

    private static long availMb(Context c) {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ((ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(mi);
        return mi.availMem / 1048576L;
    }

    private static String statusText(Activity a) {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ((ActivityManager) a.getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(mi);
        Intent b = a.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        float temp = b == null ? 0 : b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f;
        int lvl = b == null ? 0 : b.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
        boolean chg = b != null && b.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0;
        StatFs fs = new StatFs(Environment.getDataDirectory().getPath());
        float hz = 0;
        try {
            Display d = a.getDisplay();
            if (d != null) hz = d.getRefreshRate();
        } catch (Exception ignored) {
        }
        return String.format(Locale.US,
                "RAM free: %d MB of %d MB\nBattery: %d%%%s   %.1f\u00B0C\nHeat level: %s\nStorage free: %.1f GB\nScreen refresh: %.0f Hz",
                mi.availMem / 1048576L, mi.totalMem / 1048576L, lvl, chg ? " (charging)" : "", temp, thermal(a),
                fs.getAvailableBytes() / 1073741824.0, hz);
    }

    private static String selectedGame(Context c) {
        return Store.sp(c).getString("boost_game", "");
    }

    static List<String[]> installedGames(Context c) {
        List<String[]> out = new ArrayList<>();
        PackageManager pm = c.getPackageManager();
        for (String[] g : GAMES) if (pm.getLaunchIntentForPackage(g[1]) != null) out.add(g);
        return out;
    }

    // ------------------------------------------------------------------ the panel

    static void panel(final Activity a, final LinearLayout body, final Runnable refresh) {
        final SharedPreferences sp = Store.sp(a);

        // ---- permissions
        LinearLayout pc = HubUi.card(a, body);
        pc.addView(HubUi.text(a, "PERMISSIONS", 12, HubUi.ACCENT, true));
        int miss = PermGate.missing(a);
        pc.addView(HubUi.text(a, miss == 0 ? "All set. Every Booster feature is ready."
                : miss + " still off. Android needs you to flip each switch yourself, so tap one below or use Grant all.",
                12, miss == 0 ? HubUi.GOOD : HubUi.WARN, false));
        for (final PermGate.Item it : PermGate.items(a)) {
            LinearLayout row = new LinearLayout(a);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(0, HubUi.dp(a, 6), 0, HubUi.dp(a, 4));
            row.addView(HubUi.text(a, (it.granted ? "\u2714  " : "\u2718  ") + it.name, 14,
                    it.granted ? HubUi.GOOD : 0xFFFFFFFF, true));
            row.addView(HubUi.text(a, it.why, 11, HubUi.DIM, false));
            if (!it.granted) row.setOnClickListener(v -> PermGate.request(a, it.key));
            pc.addView(row);
        }
        if (miss > 0) pc.addView(HubUi.button(a, "Grant all missing", true, v -> PermGate.restart(a)));
        final boolean auto = PermGate.autoOn(a);
        pc.addView(HubUi.button(a, auto ? "Ask automatically when I open Booster: ON" : "Ask automatically when I open Booster: OFF",
                false, v -> {
                    sp.edit().putBoolean("auto_perm", !auto).apply();
                    refresh.run();
                }));

        // ---- live status
        LinearLayout sc = HubUi.card(a, body);
        sc.addView(HubUi.text(a, "LIVE STATUS", 12, HubUi.ACCENT, true));
        final TextView st = HubUi.text(a, statusText(a), 13, 0xFFFFFFFF, false);
        sc.addView(st);
        final Handler h = new Handler(Looper.getMainLooper());
        h.postDelayed(new Runnable() {
            @Override public void run() {
                if (!st.isAttachedToWindow()) return;
                st.setText(statusText(a));
                h.postDelayed(this, 2000);
            }
        }, 2000);

        // ---- game + options
        LinearLayout gc = HubUi.card(a, body);
        gc.addView(HubUi.text(a, "GAME", 12, HubUi.ACCENT, true));
        List<String[]> inst = installedGames(a);
        if (inst.isEmpty()) {
            gc.addView(HubUi.text(a, "No supported game found (CODM, PUBG Mobile, BGMI).", 12, HubUi.WARN, false));
        } else {
            String cur = selectedGame(a);
            boolean found = false;
            String[] labels = new String[inst.size()];
            for (int i = 0; i < inst.size(); i++) {
                labels[i] = inst.get(i)[0];
                if (inst.get(i)[1].equals(cur)) found = true;
            }
            if (!found) {
                cur = inst.get(0)[1];
                sp.edit().putString("boost_game", cur).apply();
            }
            String curLabel = labels[0];
            for (String[] g : inst) if (g[1].equals(cur)) curLabel = g[0];
            final List<String[]> fi = inst;
            HubUi.chips(a, gc, labels, curLabel, v -> {
                for (String[] g : fi) if (g[0].equals(v)) sp.edit().putString("boost_game", g[1]).apply();
                refresh.run();
            });
        }
        gc.addView(HubUi.text(a, "WHAT BOOST DOES", 12, HubUi.ACCENT, true));
        for (final String[] t : TOGGLES) {
            final boolean on = sp.getBoolean(t[0], true);
            LinearLayout row = new LinearLayout(a);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(0, HubUi.dp(a, 4), 0, HubUi.dp(a, 4));
            TextView tv = HubUi.text(a, t[1], 13, 0xFFFFFFFF, false);
            row.addView(tv, new LinearLayout.LayoutParams(0, -2, 1f));
            Button sw = HubUi.pill(a, on ? "ON" : "OFF", on);
            sw.setOnClickListener(v -> {
                sp.edit().putBoolean(t[0], !on).apply();
                refresh.run();
            });
            row.addView(sw, new LinearLayout.LayoutParams(HubUi.dp(a, 70), HubUi.dp(a, 38)));
            gc.addView(row);
        }
        final TextView result = HubUi.text(a, sp.getString("boost_last", "Nothing run yet."), 12, HubUi.DIM, false);
        gc.addView(HubUi.button(a, "BOOST & LAUNCH", true, v -> runBoost(a, result, true)));
        gc.addView(HubUi.button(a, "Boost only (stay here)", false, v -> runBoost(a, result, false)));
        gc.addView(HubUi.button(a, "Restore normal (DND, brightness, overlay)", false, v -> restore(a, result)));
        gc.addView(result);

        // ---- Game Space panel
        LinearLayout gs = HubUi.card(a, body);
        gs.addView(HubUi.text(a, "GAME SPACE PANEL", 12, HubUi.ACCENT, true));
        gs.addView(HubUi.text(a, "REDMAGIC-style panel over your game: status bar, CPU and RAM gauges, Turbo X, quick toggles, brightness and volume. Tap the red tab on the right edge to open it.", 12, HubUi.DIM, false));
        final boolean gsOn = GameSpaceService.isRunning();
        gs.addView(HubUi.button(a, gsOn ? "Turn Game Space OFF" : "Turn Game Space ON", !gsOn, v -> {
            if (gsOn) {
                a.startService(new Intent(a, GameSpaceService.class).setAction(GameSpaceService.ACTION_STOP));
            } else if (!PermGate.has(a, "overlay")) {
                PermGate.request(a, "overlay");
            } else {
                a.startForegroundService(new Intent(a, GameSpaceService.class).setAction(GameSpaceService.ACTION_START));
            }
            new Handler(Looper.getMainLooper()).postDelayed(refresh, 500);
        }));

        gs.addView(HubUi.button(a, "Open Shooter Center (trainers, sensitivity, game profiles)", false,
                v -> a.startActivity(new Intent(a, ShooterActivity.class))));

        // ---- overlay
        LinearLayout oc = HubUi.card(a, body);
        oc.addView(HubUi.text(a, "STATS OVERLAY", 12, HubUi.ACCENT, true));
        oc.addView(HubUi.text(a, "A thin strip at the top of the screen: time, free RAM, battery, temperature, heat level. Touches pass straight through it.", 12, HubUi.DIM, false));
        final boolean ovOn = BoostOverlayService.isRunning();
        oc.addView(HubUi.button(a, ovOn ? "Turn overlay OFF" : "Turn overlay ON", !ovOn, v -> {
            if (ovOn) {
                a.startService(new Intent(a, BoostOverlayService.class).setAction(BoostOverlayService.ACTION_STOP));
            } else if (!PermGate.has(a, "overlay")) {
                PermGate.request(a, "overlay");
            } else {
                a.startForegroundService(new Intent(a, BoostOverlayService.class).setAction(BoostOverlayService.ACTION_START));
            }
            new Handler(Looper.getMainLooper()).postDelayed(refresh, 500);
        }));

        // ---- ping
        LinearLayout nc = HubUi.card(a, body);
        nc.addView(HubUi.text(a, "CONNECTION CHECK", 12, HubUi.ACCENT, true));
        final TextView pr = HubUi.text(a, "Tap to measure latency and jitter (8 quick tests).", 12, HubUi.DIM, false);
        nc.addView(pr);
        nc.addView(HubUi.button(a, "Run test", false, v -> {
            pr.setText("Testing...");
            pingTest(a, pr);
        }));

        // ---- adb tips
        LinearLayout tc = HubUi.card(a, body);
        tc.addView(HubUi.text(a, "EXTRA PERFORMANCE (needs a PC + USB debugging)", 12, HubUi.ACCENT, true));
        tc.addView(HubUi.text(a, "An app cannot change Android's game mode or lock the refresh rate by itself. These commands can. Copy one and paste it into adb on your computer.", 12, HubUi.DIM, false));
        String pkg = selectedGame(a).length() > 0 ? selectedGame(a) : "com.activision.callofduty.shooter";
        copyRow(a, tc, "Game mode: performance", "adb shell cmd game mode performance " + pkg);
        copyRow(a, tc, "Run the bundled helper script", "adb push start.sh /sdcard/ && adb shell sh /sdcard/start.sh start --perf --game " + pkg);
        copyRow(a, tc, "Undo everything", "adb shell sh /sdcard/start.sh stop");
    }

    private static void copyRow(final Activity a, LinearLayout p, final String label, final String cmd) {
        p.addView(HubUi.button(a, "Copy: " + label, false, v -> {
            ((ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("adb", cmd));
            HubUi.toast(a, "Copied");
        }));
    }

    // ------------------------------------------------------------------ actions

    static void runBoost(final Activity a, final TextView out, final boolean launch) {
        final SharedPreferences sp = Store.sp(a);
        final String game = selectedGame(a);
        out.setText("Boosting...");
        new Thread(() -> {
            final StringBuilder log = new StringBuilder();
            try {
                if (sp.getBoolean("b_clean", true)) log.append(cleanRam(a, game)).append('\n');
                if (sp.getBoolean("b_dnd", true)) log.append(setDnd(a, true)).append('\n');
                log.append(ShooterMode.loadProfile(a, game)).append('\n');
                if (sp.getBoolean("b_bright", true)) log.append(ShooterMode.brightness(a)).append('\n');
                PerfInfo.startPing();
                if (sp.getBoolean("b_ping", true)) log.append(pingSummary()).append('\n');
            } catch (Exception e) {
                log.append("Some steps failed: ").append(e.getClass().getSimpleName()).append('\n');
            }
            final String text = log.toString().trim();
            a.runOnUiThread(() -> {
                try {
                    if (sp.getBoolean("b_overlay", true) && PermGate.has(a, "overlay")) {
                        a.startForegroundService(new Intent(a, BoostOverlayService.class).setAction(BoostOverlayService.ACTION_START));
                    }
                    if (launch && PermGate.has(a, "overlay") && !GameSpaceService.isRunning()) {
                        a.startForegroundService(new Intent(a, GameSpaceService.class).setAction(GameSpaceService.ACTION_START));
                    }
                } catch (Exception ignored) {
                }
                sp.edit().putString("boost_last", text).putInt("boost_count", sp.getInt("boost_count", 0) + 1).apply();
                out.setText(text + "\nBoosts run: " + sp.getInt("boost_count", 1));
                if (launch) {
                    Intent li = game.length() == 0 ? null : a.getPackageManager().getLaunchIntentForPackage(game);
                    if (li == null) HubUi.toast(a, "Pick an installed game first.");
                    else { GameCenters.recordLaunch(a, game); a.startActivity(li); }
                }
            });
        }).start();
    }

    static String cleanRam(Context c, String game) {
        long before = availMb(c);
        PackageManager pm = c.getPackageManager();
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        String ime = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
        int n = 0;
        for (ApplicationInfo ai : pm.getInstalledApplications(0)) {
            if ((ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
            if (ai.packageName.equals(c.getPackageName()) || ai.packageName.equals(game)) continue;
            if (ime != null && ime.startsWith(ai.packageName)) continue;
            am.killBackgroundProcesses(ai.packageName);
            n++;
        }
        try {
            Thread.sleep(700);
        } catch (InterruptedException ignored) {
        }
        long freed = Math.max(0, availMb(c) - before);
        return "RAM: asked " + n + " background apps to close, freed about " + freed + " MB (Android may reopen some).";
    }

    static String setDnd(Context c, boolean on) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (!nm.isNotificationPolicyAccessGranted()) return "Do Not Disturb: skipped (access not granted).";
        SharedPreferences sp = Store.sp(c);
        if (on) {
            if (!sp.contains("prev_dnd")) sp.edit().putInt("prev_dnd", nm.getCurrentInterruptionFilter()).apply();
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY);
            return "Do Not Disturb: on (priority only).";
        }
        nm.setInterruptionFilter(sp.getInt("prev_dnd", NotificationManager.INTERRUPTION_FILTER_ALL));
        sp.edit().remove("prev_dnd").apply();
        return "Do Not Disturb: restored.";
    }

    static String setBrightness(Context c, boolean on) {
        if (!Settings.System.canWrite(c)) return "Brightness: skipped (permission not granted).";
        SharedPreferences sp = Store.sp(c);
        try {
            if (on) {
                if (!sp.contains("prev_bright")) {
                    sp.edit().putInt("prev_bright", Settings.System.getInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 128))
                            .putInt("prev_bmode", Settings.System.getInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE, 1)).apply();
                }
                Settings.System.putInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                Settings.System.putInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 255);
                return "Brightness: maxed.";
            }
            if (sp.contains("prev_bright")) {
                Settings.System.putInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, sp.getInt("prev_bright", 128));
                Settings.System.putInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE, sp.getInt("prev_bmode", 1));
                sp.edit().remove("prev_bright").remove("prev_bmode").apply();
            }
            return "Brightness: restored.";
        } catch (Exception e) {
            return "Brightness: could not change.";
        }
    }

    private static void restore(Activity a, TextView out) {
        String s = setDnd(a, false) + "\n" + setBrightness(a, false);
        a.startService(new Intent(a, BoostOverlayService.class).setAction(BoostOverlayService.ACTION_STOP));
        out.setText(s + "\nOverlay: off.");
    }

    // ------------------------------------------------------------------ latency

    private static long[] samples() {
        String[] hosts = {"1.1.1.1", "8.8.8.8"};
        int[] ports = {443, 53};
        long[] r = new long[8];
        for (int i = 0; i < r.length; i++) {
            long t0 = System.nanoTime();
            try (Socket s = new Socket()) {
                s.connect(new InetSocketAddress(hosts[i % 2], ports[i % 2]), 1500);
                r[i] = (System.nanoTime() - t0) / 1000000L;
            } catch (Exception e) {
                r[i] = -1;
            }
        }
        return r;
    }

    private static String summarize(long[] r) {
        long sum = 0, ok = 0, min = Long.MAX_VALUE, max = 0;
        for (long v : r) {
            if (v < 0) continue;
            ok++;
            sum += v;
            min = Math.min(min, v);
            max = Math.max(max, v);
        }
        if (ok == 0) return "No connection (airplane mode or offline).";
        long avg = sum / ok, jitter = max - min;
        String grade = avg < 40 && jitter < 25 ? "Excellent" : avg < 80 ? "Good" : avg < 130 ? "Playable" : "Laggy";
        return String.format(Locale.US, "Latency %d ms avg, jitter %d ms, %d/%d replies: %s", avg, jitter, ok, r.length, grade);
    }

    private static String pingSummary() {
        return "Network: " + summarize(samples());
    }

    private static void pingTest(final Activity a, final TextView out) {
        new Thread(() -> {
            final String s = summarize(samples());
            a.runOnUiThread(() -> out.setText(s));
        }).start();
    }
}
