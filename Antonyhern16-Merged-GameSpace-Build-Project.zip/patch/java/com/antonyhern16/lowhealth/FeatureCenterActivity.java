package com.antonyhern16.lowhealth;
import android.app.*; import android.os.*; import android.graphics.Color; import android.content.*; import android.provider.Settings; import android.view.*; import android.widget.*; import java.util.*;
/** Honest feature/capability center for the expanded Game Space architecture. */
public class FeatureCenterActivity extends Activity {
 LinearLayout root; int dp(float v){return HubUi.dp(this,v);} @Override public void onCreate(Bundle b){super.onCreate(b); render();}
 void render(){ ScrollView sv=new ScrollView(this); root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(24),dp(18),dp(30));root.setBackgroundColor(HubUi.BG); sv.addView(root);setContentView(sv);
  TextView h=HubUi.text(this,"GAME SPACE • FEATURE & CAPABILITY CENTER",22,Color.WHITE,true);root.addView(h); root.addView(HubUi.text(this,CapabilityMatrix.deviceSummary(this),11,HubUi.DIM,false));
  root.addView(HubUi.text(this,"Every item below reports its real Android/device state. Vendor-only controls stay disabled instead of faking hardware behavior.",12,0xFFFF8796,false));
  addAction("PERMISSION CENTER","Open overlay / DND / system-setting access routes",()->startActivity(new Intent(Settings.ACTION_SETTINGS)));
  addAction("SHOOTER CENTER","Aim, recoil, gyro, reaction, sensitivity and game profiles",()->startActivity(new Intent(this,ShooterActivity.class)));
  addAction("GAME SPACE EDGE PANEL","Start the floating gaming panel (overlay permission required)",()->{if(!Settings.canDrawOverlays(this))startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,android.net.Uri.parse("package:"+getPackageName())));else startForegroundService(new Intent(this,GameSpaceService.class).setAction(GameSpaceService.ACTION_START));});
  String[][] real={{"NETWORK CENTER","Connection type, link estimate, latency / jitter / packet-loss test, traffic, change events","network"},
   {"COOLING & CHARGING","Battery temperature, thermal status and headroom, charging source, recommendations","cooling"},
   {"DISPLAY & EXTERNAL DISPLAY","Current and supported refresh rates, HDR, screen timeout, external displays","display"},
   {"GRAPHICS INFO","GPU, OpenGL ES, Vulkan, resolution","graphics"},
   {"CONTROLLER CENTER","Gamepads, keyboards and mice Android can see, with battery when exposed","controllers"},
   {"GAME STATISTICS","Launches from Game Space and 7-day play time (needs Usage access)","stats"},
   {"GAME NOTES","Per-game notes, pin, delete, paste from clipboard on tap","notes"}};
  LinearLayout rc=HubUi.card(this,root);rc.addView(HubUi.text(this,"WORKING CENTERS (tap to open)",13,HubUi.ACCENT,true));
  for(final String[] m:real){LinearLayout x=HubUi.card(this,rc);x.addView(HubUi.text(this,m[0],13,Color.WHITE,true));x.addView(HubUi.text(this,m[1],11,HubUi.DIM,false));x.setOnClickListener(v->startActivity(CenterActivity.open(this,m[2])));}
  LinearLayout pc=HubUi.card(this,root);pc.addView(HubUi.text(this,"IN THE GAME SPACE PANEL",13,HubUi.ACCENT,true));
  pc.addView(HubUi.text(this,"Stopwatch / Timer with lap, pause and alarm; Network monitor and Cooling monitor floating readouts; Shooter Mode; Free RAM; Do Not Disturb; brightness; volume; Booster.",11,Color.WHITE,false));
  String[] todo={"Performance profiles (Eco / Balanced / Rise / Diablo)","Touch Control Center","Anti-mistouch edge guard","Screen recording / replay buffer / screenshot tool","Magnifier / screen extraction","Scout visual tools","Motion control mapping","Sound equalizer","Auxiliary lines","RGB / lighting","AI game assistant / voice commands","Plugin center with per-plugin settings","Profile import/export across all centers"};
  LinearLayout mc=HubUi.card(this,root);mc.addView(HubUi.text(this,"NOT BUILT YET (no buttons exist for these)",13,0xFFFFC857,true)); for(String m:todo)mc.addView(HubUi.text(this,"\u2022 "+m,12,HubUi.DIM,false));
  mc.addView(HubUi.text(this,"Crosshair, counter and trigger overlays were removed from this app on purpose and stay out.",11,HubUi.DIM,false));
  LinearLayout c=HubUi.card(this,root);c.addView(HubUi.text(this,"LIVE CAPABILITY MATRIX",13,HubUi.ACCENT,true)); for(CapabilityMatrix.Cap x:CapabilityMatrix.scan(this)){int col=(x.state==CapabilityMatrix.State.SUPPORTED?HubUi.GOOD:(x.state==CapabilityMatrix.State.PARTIALLY_SUPPORTED?0xFFFFC857:0xFFFF8796)); c.addView(HubUi.text(this,x.name+"  —  "+x.state.name().replace('_',' '),12,col,true));c.addView(HubUi.text(this,x.detail,10,HubUi.DIM,false));}
 }
 interface A{void go();} void addAction(String t,String s,A a){LinearLayout c=HubUi.card(this,root);c.addView(HubUi.text(this,t,13,Color.WHITE,true));c.addView(HubUi.text(this,s,11,HubUi.DIM,false));c.setOnClickListener(v->a.go());}
}
