package com.antonyhern16.lowhealth;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.net.TrafficStats;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.FileReader;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * REDMAGIC-style "Game Space" panel drawn over your game. A small edge handle opens a landscape
 * panel: status bar, CPU and RAM gauges, tool tiles, quick toggles, brightness and volume.
 * Only normal Android APIs. It never touches the game, its memory or its input.
 */
public class GameSpaceService extends Service implements Runnable {
    public static final String ACTION_START = "com.antonyhern16.lowhealth.GS_START";
    public static final String ACTION_STOP = "com.antonyhern16.lowhealth.GS_STOP";
    private static final String CHANNEL = "gamespace_panel";
    private static final int RED = 0xFFB00000, RED_HI = 0xFFFF1E2D, TILE = 0xFF2B2B2E, TILE_ON = 0xFFB30000;
    private static volatile boolean running = false;
    static boolean isRunning() { return running; }

    private static final String[][] SHORTCUTS = {
            {"com.android.chrome", "Chrome"}, {"com.twitter.android", "X"},
            {"com.facebook.katana", "Facebook"}, {"com.google.android.youtube", "YouTube"}};

    private WindowManager wm;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final SimpleDateFormat clock = new SimpleDateFormat("HH:mm", Locale.getDefault());
    private View handle, panel;
    private TextView sTime, sHz, sCpu, sPing, sNet, sBat, tickerLeft;
    private Gauge cpuGauge, ramGauge;
    private LinearLayout leftList;
    private boolean gridMode = false, turbo = false;
    private long lastRx = -1, lastT = 0;
    private volatile long pingMs = -1;
    private long infoRx = -1, infoT = 0;
    private double infoKbs = 0;
    private int tick = 0;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent i, int flags, int id) {
        if (i != null && ACTION_STOP.equals(i.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (running) return START_STICKY;
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY; }
        startAsForeground();
        try {
            wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            addHandle();
            running = true;
            h.post(this);
        } catch (Exception e) { stopSelf(); }
        return START_STICKY;
    }

    private void startAsForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Game Space panel", NotificationManager.IMPORTANCE_LOW));
        PendingIntent pi = PendingIntent.getService(this, 2, new Intent(this, GameSpaceService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, CHANNEL).setContentTitle("Game Space is on")
                .setContentText("Tap to turn it off").setSmallIcon(android.R.drawable.ic_menu_manage)
                .setContentIntent(pi).setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(4302, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(4302, n);
    }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private static GradientDrawable round(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(r);
        return g;
    }

    // ------------------------------------------------------------ edge handle
    private void addHandle() {
        TextView t = new TextView(this);
        t.setText("\u2039");
        t.setTextColor(Color.WHITE);
        t.setTextSize(22);
        t.setGravity(Gravity.CENTER);
        t.setBackground(round(0xAAB00000, dp(10)));
        t.setOnClickListener(v -> openPanel());
        handle = t;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(dp(22), dp(84),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.END | Gravity.CENTER_VERTICAL;
        wm.addView(handle, lp);
    }

    // ------------------------------------------------------------ the panel
    private void openPanel() {
        if (panel != null) return;
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xB8000000);
        root.setOnClickListener(v -> closePanel());      // tap the middle to go back to the game

        // top status bar
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14), dp(4), dp(14), dp(4));
        bar.setBackground(round(0xE6000000, dp(18)));
        sTime = stat(bar); sHz = stat(bar); sCpu = stat(bar); sPing = stat(bar); sNet = stat(bar); sBat = stat(bar);
        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(-2, dp(34), Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        bl.topMargin = dp(6);
        root.addView(bar, bl);

        // top-left round buttons
        LinearLayout tl = new LinearLayout(this);
        tl.addView(roundBtn("\u2302", v -> goHome()));
        tl.addView(roundBtn("\u2699", v -> openSettings()));
        tl.addView(roundBtn("\uD83C\uDFAE", v -> launchGame()));
        tl.addView(roundBtn("\u23FB", v -> closePanel()));
        root.addView(tl, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START));

        // top-right app shortcuts
        LinearLayout tr = new LinearLayout(this);
        PackageManager pm = getPackageManager();
        for (final String[] s : SHORTCUTS) {
            Intent li = pm.getLaunchIntentForPackage(s[0]);
            if (li == null) continue;
            ImageView iv = new ImageView(this);
            try { iv.setImageDrawable(pm.getApplicationIcon(s[0])); } catch (Exception ignored) { }
            iv.setPadding(dp(8), dp(8), dp(8), dp(8));
            iv.setBackground(round(0x33FFFFFF, dp(30)));
            final Intent fi = li;
            iv.setOnClickListener(v -> { closePanel(); fi.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(fi); });
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(52), dp(52));
            p.setMargins(dp(5), dp(6), dp(5), 0);
            tr.addView(iv, p);
        }
        root.addView(tr, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END));

        // left column: list/grid switch, ticker, tiles, CPU gauge
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.setPadding(dp(8), dp(68), dp(6), dp(8));
        left.addView(modeSwitch(), new LinearLayout.LayoutParams(dp(150), dp(38)));
        tickerLeft = new TextView(this);
        tickerLeft.setTextColor(0x66FFFFFF);
        tickerLeft.setTextSize(10);
        left.addView(tickerLeft);
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        leftList = new LinearLayout(this);
        leftList.setOrientation(LinearLayout.VERTICAL);
        sv.addView(leftList);
        left.addView(sv, new LinearLayout.LayoutParams(dp(150), 0, 1f));
        buildTiles();
        FrameLayout.LayoutParams ll = new FrameLayout.LayoutParams(dp(160), -1, Gravity.START);
        root.addView(left, ll);

        cpuGauge = new Gauge(this, "CPU");
        FrameLayout.LayoutParams cg = new FrameLayout.LayoutParams(dp(150), dp(130), Gravity.START | Gravity.TOP);
        cg.leftMargin = dp(176); cg.topMargin = dp(66);
        root.addView(cpuGauge, cg);
        TextView turboTag = new TextView(this);
        turboTag.setText("Turbo X Mode");
        turboTag.setTextColor(Color.WHITE);
        turboTag.setTextSize(13);
        turboTag.setPadding(dp(14), dp(6), dp(14), dp(6));
        turboTag.setBackground(outline());
        turboTag.setOnClickListener(v -> { turbo = !turbo; if (turbo) turboBoost(); v.setBackground(turbo ? round(0x66B30000, dp(8)) : outline()); });
        FrameLayout.LayoutParams tt = new FrameLayout.LayoutParams(-2, -2, Gravity.START | Gravity.TOP);
        tt.leftMargin = dp(190); tt.topMargin = dp(210);
        root.addView(turboTag, tt);

        // right column: RAM gauge + quick toggles
        ramGauge = new Gauge(this, "RAM");
        FrameLayout.LayoutParams rg = new FrameLayout.LayoutParams(dp(150), dp(130), Gravity.END | Gravity.TOP);
        rg.rightMargin = dp(176); rg.topMargin = dp(66);
        root.addView(ramGauge, rg);
        root.addView(quickGrid(), gridParams());

        // brightness (left) + volume (right) bars
        root.addView(slider(true), sliderParams(Gravity.START, dp(176)));
        root.addView(slider(false), sliderParams(Gravity.END, dp(176)));

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(-1, -1,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        panel = root;
        handle.setVisibility(View.GONE);
        wm.addView(panel, lp);
        refresh();
    }

    private void closePanel() {
        try { if (panel != null) wm.removeView(panel); } catch (Exception ignored) { }
        panel = null;
        if (handle != null) handle.setVisibility(View.VISIBLE);
    }

    private GradientDrawable outline() {
        GradientDrawable g = new GradientDrawable();
        g.setColor(0x00000000);
        g.setStroke(dp(1), 0xFFD02030);
        g.setCornerRadius(dp(8));
        return g;
    }

    private TextView stat(LinearLayout bar) {
        TextView t = new TextView(this);
        t.setTextColor(Color.WHITE);
        t.setTextSize(11);
        t.setPadding(dp(8), 0, dp(8), 0);
        bar.addView(t);
        return t;
    }

    private TextView roundBtn(String glyph, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(glyph);
        t.setTextColor(Color.WHITE);
        t.setTextSize(20);
        t.setGravity(Gravity.CENTER);
        t.setBackground(round(0xFF2B2B2E, dp(26)));
        t.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(50), dp(50));
        p.setMargins(dp(8), dp(8), 0, 0);
        t.setLayoutParams(p);
        return t;
    }

    private View modeSwitch() {
        LinearLayout r = new LinearLayout(this);
        r.setBackground(round(0xFF2B2B2E, dp(10)));
        final TextView a = new TextView(this), b = new TextView(this);
        a.setText("\u2630"); b.setText("\u25A6");
        for (TextView t : new TextView[]{a, b}) { t.setTextColor(Color.WHITE); t.setTextSize(18); t.setGravity(Gravity.CENTER); }
        a.setBackground(round(gridMode ? 0 : RED, dp(10)));
        b.setBackground(round(gridMode ? RED : 0, dp(10)));
        a.setOnClickListener(v -> { gridMode = false; rebuild(); });
        b.setOnClickListener(v -> { gridMode = true; rebuild(); });
        r.addView(a, new LinearLayout.LayoutParams(0, -1, 1f));
        r.addView(b, new LinearLayout.LayoutParams(0, -1, 1f));
        return r;
    }

    private void rebuild() { closePanel(); openPanel(); }

    private void rebuildIfOpen() { if (panel != null) rebuild(); }

    // ------------------------------------------------------------ tiles
    private interface Act { void go(); }

    private void buildTiles() {
        leftList.removeAllViews();
        addTile("\uD83C\uDFAF", "SHOOTER MODE", prefs().getBoolean("shooter_on", false), () -> {
            prefs().edit().putBoolean("shooter_on", true).apply();
            toast("Applying Shooter Mode...");
            ShooterMode.apply(this, log -> { toast(log); rebuildIfOpen(); });
        });
        addTile("\uD83D\uDD2B", "Shooter Center", false, () -> {
            closePanel();
            startActivity(new Intent(this, ShooterActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        });
        addTile("\uD83E\uDDF9", "Free RAM", false, () -> toast(cleanRam()));
        addTile("\uD83D\uDD15", "Do Not Disturb", dndOn(), () -> { toggleDnd(); rebuild(); });
        addTile("\u2600", "Max brightness", false, () -> { setBrightness(255); toast("Brightness maxed"); });
        addTile("\uD83D\uDCF6", "Reduce ping", false, () -> { toast("Testing connection..."); pingNow(true); });
        addTile("\uD83D\uDCCA", "Active info", prefs().getBoolean("gs_stats", true), () -> {
            prefs().edit().putBoolean("gs_stats", !prefs().getBoolean("gs_stats", true)).apply(); rebuild(); });
        addTile("\uD83D\uDE80", "Turbo X mode", turbo, () -> { turbo = true; turboBoost(); rebuild(); });
        addTile("\u23F1", "Stopwatch / Timer", swRun || timerEnd > 0, () -> { closePanel(); showClock(); });
        addTile("\uD83D\uDCF6", "Network monitor", false, () -> { closePanel(); showInfo("NETWORK", () -> networkText()); });
        addTile("\uD83C\uDF21", "Cooling monitor", false, () -> { closePanel(); showInfo("COOLING", () -> coolingText()); });
        addTile("\uD83D\uDCDD", "Game notes", false, () -> openCenter("notes"));
        addTile("\uD83D\uDCCA", "Game statistics", false, () -> openCenter("stats"));
        addTile("\uD83C\uDFAE", "Controllers", false, () -> openCenter("controllers"));
        addTile("\uD83D\uDDA5", "Display info", false, () -> openCenter("display"));
        addTile("\uD83E\uDDE9", "Feature center", false, () -> {
            closePanel();
            startActivity(new Intent(this, FeatureCenterActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        });
    }

    private void openCenter(String name) {
        closePanel();
        startActivity(CenterActivity.open(this, name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
    }

    private void addTile(String glyph, String label, boolean on, final Act act) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(4), dp(10), dp(4), dp(6));
        TextView g = new TextView(this);
        g.setText(glyph); g.setTextSize(26); g.setGravity(Gravity.CENTER); g.setTextColor(Color.WHITE);
        g.setBackground(round(on ? TILE_ON : TILE, dp(10)));
        g.setPadding(0, dp(12), 0, dp(12));
        t.addView(g, new LinearLayout.LayoutParams(-1, dp(62)));
        TextView l = new TextView(this);
        l.setText(label); l.setTextSize(12); l.setTextColor(Color.WHITE); l.setGravity(Gravity.CENTER); l.setSingleLine(true);
        t.addView(l);
        t.setOnClickListener(v -> act.go());
        leftList.addView(t, new LinearLayout.LayoutParams(-1, -2));
    }

    private View quickGrid() {
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        grid.setPadding(0, dp(6), dp(6), 0);
        boolean rot = rotateOn();
        boolean auto = autoBright();
        Object[][] q = {
                {"\uD83D\uDD04", "Auto rotate", rot, (Act) () -> { toggleRotate(); rebuild(); }},
                {"\uD83D\uDD05", "Auto light", auto, (Act) () -> { toggleAutoBright(); rebuild(); }},
                {"\uD83D\uDD15", "No notification", dndOn(), (Act) () -> { toggleDnd(); rebuild(); }},
                {"\uD83D\uDCF6", "Wifi", true, (Act) this::openWifi},
                {"\u26A1", currentHz() + "Hz", true, (Act) () -> toast("Refresh rate is set in Settings > Display")},
                {"\uD83D\uDE80", "Booster", turbo, (Act) () -> { turboBoost(); toast(prefs().getString("gs_last", "Boosted")); }},
                {"\uD83C\uDF19", "Do Not Disturb", dndOn(), (Act) () -> { toggleDnd(); rebuild(); }},
                {"\uD83E\uDDF9", "Clear", false, (Act) () -> toast(cleanRam())}};
        for (int i = 0; i < q.length; i += 2) {
            LinearLayout row = new LinearLayout(this);
            for (int k = i; k < i + 2 && k < q.length; k++) {
                final Act act = (Act) q[k][3];
                LinearLayout c = new LinearLayout(this);
                c.setOrientation(LinearLayout.VERTICAL);
                c.setGravity(Gravity.CENTER);
                TextView g = new TextView(this);
                g.setText((String) q[k][0]); g.setTextSize(24); g.setGravity(Gravity.CENTER); g.setTextColor(Color.WHITE);
                g.setBackground(round((Boolean) q[k][2] ? TILE_ON : TILE, dp(10)));
                c.addView(g, new LinearLayout.LayoutParams(dp(62), dp(56)));
                TextView l = new TextView(this);
                l.setText((String) q[k][1]); l.setTextSize(10); l.setTextColor(Color.WHITE); l.setGravity(Gravity.CENTER); l.setSingleLine(true);
                c.addView(l, new LinearLayout.LayoutParams(dp(74), -2));
                c.setOnClickListener(v -> act.go());
                row.addView(c, new LinearLayout.LayoutParams(dp(76), -2));
            }
            grid.addView(row);
        }
        return grid;
    }

    private FrameLayout.LayoutParams gridParams() {
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(-2, -2, Gravity.END | Gravity.TOP);
        p.topMargin = dp(62);
        return p;
    }

    // ------------------------------------------------------------ sliders
    private View slider(final boolean bright) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        final AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        SeekBar sb = new SeekBar(this);
        sb.setRotation(-90f);
        sb.getProgressDrawable().setTint(RED_HI);
        sb.getThumb().setTint(Color.WHITE);
        int max = bright ? 255 : am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        sb.setMax(max);
        sb.setProgress(bright ? getBrightness() : am.getStreamVolume(AudioManager.STREAM_MUSIC));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (!user) return;
                if (bright) setBrightness(Math.max(5, p)); else am.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0);
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        box.addView(sb, new LinearLayout.LayoutParams(dp(200), dp(40)));
        TextView ic = new TextView(this);
        ic.setText(bright ? "\u2600" : "\uD83D\uDD0A");
        ic.setTextColor(Color.WHITE);
        ic.setTextSize(18);
        ic.setGravity(Gravity.CENTER);
        FrameLayout wrap = new FrameLayout(this);
        wrap.addView(box, new FrameLayout.LayoutParams(dp(40), dp(200), Gravity.CENTER));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.addView(wrap, new LinearLayout.LayoutParams(dp(40), dp(200)));
        col.addView(ic);
        return col;
    }

    private FrameLayout.LayoutParams sliderParams(int g, int margin) {
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(dp(40), dp(250), g | Gravity.BOTTOM);
        if (g == Gravity.START) p.leftMargin = margin; else p.rightMargin = margin;
        p.bottomMargin = dp(10);
        return p;
    }

    // ------------------------------------------------------------ gauge view
    static final class Gauge extends View {
        final String label;
        String big = "--", unit = "";
        float frac = 0f;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Gauge(Context c, String label) { super(c); this.label = label; }
        void set(String big, String unit, float frac) { this.big = big; this.unit = unit; this.frac = Math.max(0f, Math.min(1f, frac)); invalidate(); }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.WHITE);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTypeface(Typeface.DEFAULT);
            p.setTextSize(h * 0.30f);
            c.drawText(big, w / 2, h * 0.38f, p);
            p.setTextSize(h * 0.11f);
            c.drawText(unit, w / 2, h * 0.52f, p);
            // glowing ring
            p.setStyle(Paint.Style.STROKE);
            RectF r = new RectF(w * 0.06f, h * 0.50f, w * 0.94f, h * 0.84f);
            p.setStrokeWidth(h * 0.07f);
            p.setColor(0x55B00000);
            c.drawOval(r, p);
            p.setColor(0xFFFF1E2D);
            c.drawArc(r, 90f, 360f * Math.max(0.12f, frac), false, p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFFF1E2D);
            p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC));
            p.setTextSize(h * 0.10f);
            c.drawText(label, w / 2, h * 0.97f, p);
        }
    }

    // ------------------------------------------------------------ live data
    @Override
    public void run() {
        if (!running) return;
        tick++;
        if (panel != null) refresh();
        if ((panel != null || infoWin != null) && tick % 4 == 0) pingNow(false);
        h.postDelayed(this, 1000);
    }

    private void refresh() {
        if (panel == null) return;
        long now = System.currentTimeMillis();
        long rx = TrafficStats.getTotalRxBytes();
        double kbs = 0;
        if (lastRx >= 0 && now > lastT) kbs = (rx - lastRx) / 1024.0 / ((now - lastT) / 1000.0);
        lastRx = rx; lastT = now;
        Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        int lvl = b == null ? 0 : b.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
        float temp = b == null ? 0 : b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f;
        double ghz = cpuGhz();
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ((ActivityManager) getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(mi);
        float usedFrac = 1f - (float) mi.availMem / mi.totalMem;
        boolean stats = prefs().getBoolean("gs_stats", true);
        int vis = stats ? View.VISIBLE : View.GONE;
        sTime.setText("\u23F0 " + clock.format(new Date()));
        sHz.setText("\u25A0 " + currentHz() + " Hz");
        sCpu.setText(String.format(Locale.US, "\u2699 %.2fGHz", ghz));
        sPing.setText(pingMs < 0 ? "\u25C9 -- ms" : "\u25C9 " + pingMs + " ms");
        sNet.setText(String.format(Locale.US, "\u2B07 %.0f KB/s", kbs));
        sBat.setText("\uD83D\uDD0B " + lvl + "%");
        for (TextView t : new TextView[]{sHz, sCpu, sPing, sNet}) t.setVisibility(vis);
        cpuGauge.set(ghz > 0 ? String.format(Locale.US, "%.2f", ghz) : "--", "GHz", (float) (ghz / 4.2));
        ramGauge.set(Math.round(usedFrac * 100) + "%", "used", usedFrac);
        tickerLeft.setText(String.format(Locale.US, "RAM %.1f GB free  %.1f\u00B0C  %s", mi.availMem / 1073741824.0, temp, Boost.thermal(this)));
    }

    /** Highest current core frequency in GHz (0 if Android does not let apps read it). */
    private double cpuGhz() {
        long best = 0;
        for (int i = 0; i < 16; i++) {
            try (BufferedReader r = new BufferedReader(new FileReader("/sys/devices/system/cpu/cpu" + i + "/cpufreq/scaling_cur_freq"))) {
                best = Math.max(best, Long.parseLong(r.readLine().trim()));
            } catch (Exception ignored) { }
        }
        return best / 1000000.0;
    }

    private int currentHz() {
        try {
            Display d = ((WindowManager) getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
            return Math.round(d.getRefreshRate());
        } catch (Exception e) { return 0; }
    }

    private void pingNow(final boolean toastIt) {
        new Thread(() -> {
            long t0 = System.nanoTime();
            long v = -1;
            try (Socket s = new Socket()) {
                s.connect(new InetSocketAddress("1.1.1.1", 443), 1500);
                v = (System.nanoTime() - t0) / 1000000L;
            } catch (Exception ignored) { }
            pingMs = v;
            if (toastIt) {
                final String msg = v < 0 ? "No connection" : "Latency " + v + " ms";
                h.post(() -> toast(msg));
            }
        }).start();
    }

    // ------------------------------------------------------------ actions
    private android.content.SharedPreferences prefs() { return Store.sp(this); }

    private void toast(String s) { HubUi.toast(this, s); }

    private String cleanRam() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        long before = mi.availMem;
        String game = prefs().getString("boost_game", "");
        String ime = Settings.Secure.getString(getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
        for (android.content.pm.ApplicationInfo ai : getPackageManager().getInstalledApplications(0)) {
            if ((ai.flags & android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0) continue;
            if (ai.packageName.equals(getPackageName()) || ai.packageName.equals(game)) continue;
            if (ime != null && ime.startsWith(ai.packageName)) continue;
            am.killBackgroundProcesses(ai.packageName);
        }
        am.getMemoryInfo(mi);
        long freed = Math.max(0, (mi.availMem - before) / 1048576L);
        String s = "Asked background apps to close, freed about " + freed + " MB";
        prefs().edit().putString("gs_last", s).apply();
        return s;
    }

    private void turboBoost() {
        StringBuilder sb = new StringBuilder(cleanRam());
        try { if (!dndOn()) toggleDnd(); sb.append("\nDo Not Disturb on"); } catch (Exception ignored) { }
        try { setBrightness(255); sb.append("\nBrightness maxed"); } catch (Exception ignored) { }
        prefs().edit().putString("gs_last", sb.toString()).apply();
        toast(sb.toString());
    }

    private boolean dndOn() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        return nm.getCurrentInterruptionFilter() != NotificationManager.INTERRUPTION_FILTER_ALL
                && nm.getCurrentInterruptionFilter() != NotificationManager.INTERRUPTION_FILTER_UNKNOWN;
    }

    private void toggleDnd() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (!nm.isNotificationPolicyAccessGranted()) { toast("Grant Do Not Disturb access in Booster first"); return; }
        nm.setInterruptionFilter(dndOn() ? NotificationManager.INTERRUPTION_FILTER_ALL : NotificationManager.INTERRUPTION_FILTER_PRIORITY);
    }

    private int getBrightness() {
        try { return Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 128); } catch (Exception e) { return 128; }
    }

    private void setBrightness(int v) {
        if (!Settings.System.canWrite(this)) { toast("Grant 'Modify system settings' in Booster first"); return; }
        Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
        Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, v);
    }

    private boolean autoBright() {
        try { return Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE) == Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC; }
        catch (Exception e) { return false; }
    }

    private void toggleAutoBright() {
        if (!Settings.System.canWrite(this)) { toast("Grant 'Modify system settings' in Booster first"); return; }
        Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE,
                autoBright() ? Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL : Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC);
    }

    private boolean rotateOn() {
        try { return Settings.System.getInt(getContentResolver(), Settings.System.ACCELEROMETER_ROTATION) == 1; } catch (Exception e) { return false; }
    }

    private void toggleRotate() {
        if (!Settings.System.canWrite(this)) { toast("Grant 'Modify system settings' in Booster first"); return; }
        Settings.System.putInt(getContentResolver(), Settings.System.ACCELEROMETER_ROTATION, rotateOn() ? 0 : 1);
    }

    private void goHome() {
        closePanel();
        startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
    }

    private void openSettings() {
        closePanel();
        startActivity(new Intent(this, GameHubActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
    }

    private void openWifi() {
        closePanel();
        try {
            startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception ignored) { }
    }

    private void launchGame() {
        String g = prefs().getString("boost_game", "");
        Intent li = g.length() == 0 ? null : getPackageManager().getLaunchIntentForPackage(g);
        closePanel();
        if (li == null) toast("Pick a game in Game Hub > Booster first");
        else { GameCenters.recordLaunch(this, g); startActivity(li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
    }

    // ------------------------------------------------------------ floating tool windows
    private View clockWin, infoWin;
    private TextView swText, swLaps, tmText;
    private boolean swRun = false;
    private long swStart = 0, swAccum = 0, timerEnd = 0, timerLeftPaused = 0;
    private final java.util.ArrayList<String> laps = new java.util.ArrayList<>();
    private final Runnable clockTick = new Runnable() {
        @Override public void run() {
            updateClock();
            if (timerEnd > 0 && System.currentTimeMillis() >= timerEnd) timerDone();
            if (clockWin != null || swRun || timerEnd > 0) h.postDelayed(this, 200);
        }
    };

    private WindowManager.LayoutParams floatParams() {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(-2, -2,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = dp(24); lp.y = dp(24);
        return lp;
    }

    /** Title bar that drags the window and closes it. */
    private View titleBar(String title, final View win, final WindowManager.LayoutParams lp, final Runnable onClose) {
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = new TextView(this);
        t.setText(title); t.setTextColor(RED_HI); t.setTextSize(12); t.setTypeface(Typeface.DEFAULT_BOLD);
        bar.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView x = new TextView(this);
        x.setText("\u2715"); x.setTextColor(Color.WHITE); x.setTextSize(18); x.setPadding(dp(14), dp(6), dp(4), dp(6));
        x.setOnClickListener(v -> onClose.run());
        bar.addView(x);
        bar.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) { dx = lp.x - e.getRawX(); dy = lp.y - e.getRawY(); return true; }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    lp.x = (int) (e.getRawX() + dx); lp.y = (int) (e.getRawY() + dy);
                    try { wm.updateViewLayout(win, lp); } catch (Exception ignored) { }
                    return true;
                }
                return false;
            }
        });
        return bar;
    }

    private TextView winBtn(String label, View.OnClickListener l) {
        TextView b = new TextView(this);
        b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(12); b.setGravity(Gravity.CENTER);
        b.setBackground(round(TILE, dp(8)));
        b.setPadding(dp(10), dp(8), dp(10), dp(8));
        b.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
        p.setMargins(dp(3), dp(6), dp(3), 0);
        b.setLayoutParams(p);
        return b;
    }

    private void showClock() {
        if (clockWin != null) return;
        final LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(8), dp(12), dp(12));
        box.setBackground(round(0xF0141417, dp(14)));
        final WindowManager.LayoutParams lp = floatParams();
        box.addView(titleBar("STOPWATCH & TIMER  (drag here)", box, lp, this::closeClock));

        swText = new TextView(this);
        swText.setTextColor(Color.WHITE); swText.setTextSize(30); swText.setTypeface(Typeface.MONOSPACE); swText.setGravity(Gravity.CENTER);
        box.addView(swText);
        LinearLayout r1 = new LinearLayout(this);
        r1.addView(winBtn("START / PAUSE", v -> {
            if (swRun) { swAccum += System.currentTimeMillis() - swStart; swRun = false; }
            else { swStart = System.currentTimeMillis(); swRun = true; h.removeCallbacks(clockTick); h.post(clockTick); }
            updateClock();
        }));
        r1.addView(winBtn("LAP", v -> {
            if (swElapsed() > 0) { laps.add(0, fmt(swElapsed())); while (laps.size() > 5) laps.remove(laps.size() - 1); updateClock(); }
        }));
        r1.addView(winBtn("RESET", v -> { swRun = false; swAccum = 0; laps.clear(); updateClock(); }));
        box.addView(r1);
        swLaps = new TextView(this);
        swLaps.setTextColor(0xAAFFFFFF); swLaps.setTextSize(11);
        box.addView(swLaps);

        tmText = new TextView(this);
        tmText.setTextColor(Color.WHITE); tmText.setTextSize(26); tmText.setTypeface(Typeface.MONOSPACE); tmText.setGravity(Gravity.CENTER);
        tmText.setPadding(0, dp(10), 0, 0);
        box.addView(tmText);
        LinearLayout r2 = new LinearLayout(this);
        for (final int m : new int[]{1, 3, 5, 10}) r2.addView(winBtn(m + " min", v -> startTimer(m * 60000L)));
        box.addView(r2);
        LinearLayout r3 = new LinearLayout(this);
        r3.addView(winBtn("+1 MIN", v -> {
            if (timerEnd > 0) timerEnd += 60000L; else if (timerLeftPaused > 0) timerLeftPaused += 60000L; else startTimer(60000L);
            updateClock();
        }));
        r3.addView(winBtn("PAUSE / RESUME", v -> {
            if (timerEnd > 0) { timerLeftPaused = timerEnd - System.currentTimeMillis(); timerEnd = 0; }
            else if (timerLeftPaused > 0) { timerEnd = System.currentTimeMillis() + timerLeftPaused; timerLeftPaused = 0; h.removeCallbacks(clockTick); h.post(clockTick); }
            updateClock();
        }));
        r3.addView(winBtn("CLEAR", v -> { timerEnd = 0; timerLeftPaused = 0; updateClock(); }));
        box.addView(r3);

        try { wm.addView(box, lp); clockWin = box; } catch (Exception e) { toast("Could not show the window"); return; }
        updateClock();
        h.removeCallbacks(clockTick);
        h.post(clockTick);
    }

    private void closeClock() {
        try { if (clockWin != null) wm.removeView(clockWin); } catch (Exception ignored) { }
        clockWin = null;
    }

    private long swElapsed() { return swAccum + (swRun ? System.currentTimeMillis() - swStart : 0); }

    private static String fmt(long ms) {
        long s = ms / 1000;
        return String.format(Locale.US, "%02d:%02d.%d", s / 60, s % 60, (ms % 1000) / 100);
    }

    private void startTimer(long ms) {
        timerLeftPaused = 0;
        timerEnd = System.currentTimeMillis() + ms;
        h.removeCallbacks(clockTick);
        h.post(clockTick);
    }

    private void updateClock() {
        if (clockWin == null) return;
        swText.setText(fmt(swElapsed()));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < laps.size(); i++) sb.append("Lap ").append(laps.size() - i).append("  ").append(laps.get(i)).append('\n');
        swLaps.setText(sb.toString().trim());
        long left = timerEnd > 0 ? Math.max(0, timerEnd - System.currentTimeMillis()) : timerLeftPaused;
        tmText.setText(left > 0 ? "\u23F3 " + fmt(left) + (timerEnd == 0 ? "  (paused)" : "") : "Timer: pick a duration");
    }

    private void timerDone() {
        timerEnd = 0; timerLeftPaused = 0;
        try {
            android.os.Vibrator v = (android.os.Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null) v.vibrate(android.os.VibrationEffect.createWaveform(new long[]{0, 300, 150, 300, 150, 300}, -1));
        } catch (Exception ignored) { }
        try {
            final android.media.ToneGenerator tg = new android.media.ToneGenerator(AudioManager.STREAM_ALARM, 80);
            tg.startTone(android.media.ToneGenerator.TONE_PROP_BEEP2, 700);
            h.postDelayed(tg::release, 1200);
        } catch (Exception ignored) { }
        toast("Timer finished");
        updateClock();
    }

    private String networkText() {
        StringBuilder sb = new StringBuilder();
        for (GameCenters.Row r : GameCenters.network(this)) {
            if (r.k.startsWith("Wi-Fi name") || r.k.equals("Local IP") || r.k.startsWith("Link speed")) continue;
            sb.append(r.k).append(": ").append(r.v).append('\n');
        }
        sb.append("Latency (last probe to 1.1.1.1): ").append(pingMs < 0 ? "unavailable" : pingMs + " ms").append('\n');
        long now = System.currentTimeMillis(), rx = TrafficStats.getTotalRxBytes();
        if (rx != TrafficStats.UNSUPPORTED && infoRx >= 0 && now > infoT)
            infoKbs = (rx - infoRx) / 1024.0 / ((now - infoT) / 1000.0);
        infoRx = rx; infoT = now;
        sb.append("Download: ").append(rx == TrafficStats.UNSUPPORTED ? "N/A" : String.format(Locale.US, "%.0f KB/s", infoKbs));
        return sb.toString();
    }

    private String coolingText() {
        StringBuilder sb = new StringBuilder();
        for (GameCenters.Row r : GameCenters.cooling(this)) {
            if (r.k.equals("Battery temperature") || r.k.equals("Thermal status") || r.k.startsWith("Thermal headroom")
                    || r.k.equals("Battery level") || r.k.equals("Charging source") || r.k.equals("Recommendation"))
                sb.append(r.k).append(": ").append(r.v).append('\n');
        }
        return sb.toString().trim();
    }

    /** Small floating readout that refreshes once a second while it is on screen. */
    private void showInfo(String title, final java.util.function.Supplier<String> body) {
        closeInfo();
        final LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(8), dp(12), dp(12));
        box.setBackground(round(0xF0141417, dp(14)));
        final WindowManager.LayoutParams lp = floatParams();
        box.addView(titleBar(title + "  (drag here)", box, lp, this::closeInfo));
        final TextView tv = new TextView(this);
        tv.setTextColor(Color.WHITE); tv.setTextSize(12);
        box.addView(tv);
        try { wm.addView(box, lp); infoWin = box; } catch (Exception e) { toast("Could not show the window"); return; }
        infoRx = -1;
        pingNow(false);
        final Runnable r = new Runnable() {
            @Override public void run() {
                if (infoWin != box) return;
                tv.setText(body.get());
                h.postDelayed(this, 1000);
            }
        };
        r.run();
    }

    private void closeInfo() {
        try { if (infoWin != null) wm.removeView(infoWin); } catch (Exception ignored) { }
        infoWin = null;
    }

    @Override
    public void onDestroy() {
        closeClock();
        closeInfo();
        running = false;
        h.removeCallbacksAndMessages(null);
        try { if (panel != null) wm.removeView(panel); } catch (Exception ignored) { }
        try { if (handle != null) wm.removeView(handle); } catch (Exception ignored) { }
        super.onDestroy();
    }
}
