package com.antonyhern16.lowhealth;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

import java.util.Locale;

/** Minimal line chart with min/max labels, an average line and point markers. */
final class ChartView extends View {
    private float[] v = new float[0];
    private String caption = "";
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG), dot = new Paint(Paint.ANTI_ALIAS_FLAG),
            grid = new Paint(Paint.ANTI_ALIAS_FLAG), txt = new Paint(Paint.ANTI_ALIAS_FLAG);

    ChartView(Context c) {
        super(c);
        float d = c.getResources().getDisplayMetrics().density;
        line.setColor(HubUi.ACCENT);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(2.5f * d);
        dot.setColor(HubUi.ACCENT);
        grid.setColor(0xFF2E2E38);
        grid.setStrokeWidth(1f * d);
        txt.setColor(HubUi.DIM);
        txt.setTextSize(11 * d);
    }

    void set(float[] values, String caption) {
        this.v = values == null ? new float[0] : values;
        this.caption = caption == null ? "" : caption;
        invalidate();
    }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension(MeasureSpec.getSize(w), HubUi.dp(getContext(), 150));
    }

    @Override
    protected void onDraw(Canvas c) {
        float d = getResources().getDisplayMetrics().density;
        float left = 44 * d, top = 14 * d, right = getWidth() - 8 * d, bottom = getHeight() - 18 * d;
        c.drawText(caption, 0, 11 * d, txt);
        if (v.length == 0) {
            c.drawText("No data yet", left, (top + bottom) / 2, txt);
            return;
        }
        float mn = v[0], mx = v[0], sum = 0;
        for (float f : v) {
            mn = Math.min(mn, f);
            mx = Math.max(mx, f);
            sum += f;
        }
        if (mx - mn < 0.0001f) {
            mx += 1;
            mn -= 1;
        }
        float pad = (mx - mn) * 0.1f;
        mn -= pad;
        mx += pad;
        c.drawLine(left, top, right, top, grid);
        c.drawLine(left, bottom, right, bottom, grid);
        c.drawText(fmt(mx), 0, top + 4 * d, txt);
        c.drawText(fmt(mn), 0, bottom, txt);
        float avg = sum / v.length;
        float ay = bottom - (avg - mn) / (mx - mn) * (bottom - top);
        c.drawLine(left, ay, right, ay, grid);
        c.drawText("avg " + fmt(avg), left, bottom + 14 * d, txt);
        Path p = new Path();
        for (int i = 0; i < v.length; i++) {
            float x = v.length == 1 ? (left + right) / 2 : left + i * (right - left) / (v.length - 1);
            float y = bottom - (v[i] - mn) / (mx - mn) * (bottom - top);
            if (i == 0) p.moveTo(x, y);
            else p.lineTo(x, y);
            c.drawCircle(x, y, 3 * d, dot);
        }
        c.drawPath(p, line);
    }

    private static String fmt(float f) {
        return Math.abs(f) >= 100 ? String.format(Locale.US, "%.0f", f) : String.format(Locale.US, "%.1f", f);
    }
}
