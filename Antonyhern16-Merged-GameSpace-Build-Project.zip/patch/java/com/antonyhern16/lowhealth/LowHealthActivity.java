package com.antonyhern16.lowhealth;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** Settings screen for the passive low-health alert. Shows up as its own launcher icon. */
public class LowHealthActivity extends Activity {
    private static final int REQ_CAPTURE = 4201;
    private static final int BG = 0xFF0B0B0E, CARD = 0xFF17171C, ACCENT = 0xFFFF2D4B, DIM = 0xFF9A9AA6;

    private EditText eL, eT, eR, eB, eColor;
    private SeekBar sbTol, sbFrac;
    private TextView tvTol, tvFrac;
    private Switch swHaptic, swFlash, swDebug;
    private Cfg cfg;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        cfg = Cfg.load(this);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        int p = dp(16);
        col.setPadding(p, p * 2, p, p);
        sv.addView(col);

        col.addView(text("LOW-HEALTH ALERT", 22, Color.WHITE, true));
        col.addView(text("Passive only. It watches a box on screen and tells you with a vibration or a red edge glow. It never taps or touches the screen for you.", 13, DIM, false));

        LinearLayout reg = card(col);
        reg.addView(text("WATCH BOX (% of screen)", 12, ACCENT, true));
        LinearLayout r1 = row(reg);
        eL = field(r1, "Left", fmt(cfg.l));
        eR = field(r1, "Right", fmt(cfg.r));
        LinearLayout r2 = row(reg);
        eT = field(r2, "Top", fmt(cfg.t));
        eB = field(r2, "Bottom", fmt(cfg.b));
        reg.addView(text("Example: a health bar near the bottom-left is about Left 8, Right 30, Top 88, Bottom 92. Turn on \"Show match %\" below and adjust until the number is high when the bar is low.", 12, DIM, false));

        LinearLayout colr = card(col);
        colr.addView(text("TARGET COLOR", 12, ACCENT, true));
        eColor = new EditText(this);
        eColor.setText(String.format("%06X", cfg.rgb));
        eColor.setTextColor(Color.WHITE);
        eColor.setSingleLine(true);
        eColor.setHint("RRGGBB");
        eColor.setHintTextColor(DIM);
        colr.addView(eColor);
        LinearLayout presets = row(colr);
        preset(presets, "Red", "D32F2F");
        preset(presets, "Dark red", "8B0000");
        preset(presets, "Grey", "5A5A5A");
        preset(presets, "Orange", "F57C00");
        tvTol = text("", 13, Color.WHITE, false);
        colr.addView(tvTol);
        sbTol = new SeekBar(this);
        sbTol.setMax(150);
        sbTol.setProgress(cfg.tol);
        colr.addView(sbTol);
        tvFrac = text("", 13, Color.WHITE, false);
        colr.addView(tvFrac);
        sbFrac = new SeekBar(this);
        sbFrac.setMax(95);
        sbFrac.setProgress(cfg.frac);
        colr.addView(sbFrac);
        SeekBar.OnSeekBarChangeListener sl = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                refreshLabels();
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        };
        sbTol.setOnSeekBarChangeListener(sl);
        sbFrac.setOnSeekBarChangeListener(sl);
        refreshLabels();

        LinearLayout al = card(col);
        al.addView(text("ALERT STYLE", 12, ACCENT, true));
        swHaptic = sw(al, "Vibrate", cfg.haptic);
        swFlash = sw(al, "Flash screen edges (needs \"Display over other apps\")", cfg.flash);
        swDebug = sw(al, "Show match % in the notification (for tuning)", cfg.debug);

        col.addView(button("Start watching", true, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                start();
            }
        }));
        col.addView(button("Stop", false, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startService(new Intent(LowHealthActivity.this, LowHealthService.class).setAction(LowHealthService.ACTION_STOP));
            }
        }));
        col.addView(text("Android shows a screen-capture permission box each time you press Start. Apps that block screen capture will not work.", 12, DIM, false));
        setContentView(sv);
    }

    private void refreshLabels() {
        tvTol.setText("Color tolerance: " + sbTol.getProgress() + "  (higher = accepts more shades)");
        tvFrac.setText("Alert when " + sbFrac.getProgress() + "% of the box matches");
    }

    private boolean readCfg() {
        try {
            cfg.l = Float.parseFloat(eL.getText().toString().trim());
            cfg.r = Float.parseFloat(eR.getText().toString().trim());
            cfg.t = Float.parseFloat(eT.getText().toString().trim());
            cfg.b = Float.parseFloat(eB.getText().toString().trim());
            cfg.rgb = Integer.parseInt(eColor.getText().toString().trim().replace("#", ""), 16) & 0xFFFFFF;
        } catch (NumberFormatException e) {
            toast("Check the numbers and the color (6 hex digits like D32F2F)");
            return false;
        }
        cfg.tol = sbTol.getProgress();
        cfg.frac = Math.max(1, sbFrac.getProgress());
        cfg.haptic = swHaptic.isChecked();
        cfg.flash = swFlash.isChecked();
        cfg.debug = swDebug.isChecked();
        if (!cfg.valid()) {
            toast("Box must be inside 0-100 and Right > Left, Bottom > Top");
            return false;
        }
        cfg.save(this);
        return true;
    }

    private void start() {
        if (!readCfg()) return;
        if (cfg.flash && !Settings.canDrawOverlays(this)) {
            toast("Allow \"Display over other apps\", then press Start again");
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_CAPTURE) {
            if (res == RESULT_OK && data != null) {
                Intent i = new Intent(this, LowHealthService.class).setAction(LowHealthService.ACTION_START)
                        .putExtra(LowHealthService.EXTRA_CODE, res).putExtra(LowHealthService.EXTRA_DATA, data);
                startForegroundService(i);
                toast("Watching. Open your game. Use the notification to stop.");
            } else {
                toast("Screen capture was not allowed");
            }
        }
    }

    // ---- small UI helpers
    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(14), dp(14), dp(14), dp(14));
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(16));
        l.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(12);
        parent.addView(l, lp);
        return l;
    }

    private LinearLayout row(LinearLayout parent) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        parent.addView(l, new LinearLayout.LayoutParams(-1, -2));
        return l;
    }

    private EditText field(LinearLayout row, String label, String value) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.addView(text(label, 12, DIM, false));
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setText(value);
        e.setTextColor(Color.WHITE);
        e.setSingleLine(true);
        c.addView(e);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.rightMargin = dp(8);
        row.addView(c, lp);
        return e;
    }

    private void preset(LinearLayout row, String name, final String hex) {
        Button b = new Button(this);
        b.setText(name);
        b.setAllCaps(false);
        b.setTextSize(11);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                eColor.setText(hex);
            }
        });
        row.addView(b, new LinearLayout.LayoutParams(0, -2, 1f));
    }

    private Switch sw(LinearLayout parent, String label, boolean on) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setTextColor(Color.WHITE);
        s.setChecked(on);
        s.setPadding(0, dp(6), 0, dp(6));
        parent.addView(s);
        return s;
    }

    private Button button(String label, boolean primary, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        GradientDrawable g = new GradientDrawable();
        g.setColor(primary ? ACCENT : CARD);
        g.setCornerRadius(dp(14));
        b.setBackground(g);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(50));
        lp.topMargin = dp(12);
        b.setLayoutParams(lp);
        return b;
    }

    private static String fmt(float f) {
        return f == (int) f ? String.valueOf((int) f) : String.valueOf(f);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }
}
