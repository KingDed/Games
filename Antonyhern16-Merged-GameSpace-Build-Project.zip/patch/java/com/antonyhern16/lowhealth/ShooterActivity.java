package com.antonyhern16.lowhealth;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.List;
import java.util.Locale;

/**
 * Pro Aim & Shooter Center. Real training tools, real sensitivity storage, real Android optimizations.
 * Every trainer is a simulation inside this app; nothing here touches another game.
 */
public class ShooterActivity extends Activity {
    private static final String[] SCOPES = {"Hipfire", "ADS", "Red dot", "2x scope", "3x scope", "4x scope", "6x scope", "8x scope", "Sniper"};
    private static final String[] SCOPE_KEYS = {"cam", "ads", "red", "x2", "x3", "x4", "x6", "x8", "sniper"};
    private static final String[] WEAPONS = {"Assault rifle", "SMG", "LMG", "Custom"};
    private static final float[][] WEAPON_KICK = {{7f, 2f}, {5f, 3.5f}, {9f, 1.5f}};
    private static int sessionHigh = 0;

    private final Handler h = new Handler(Looper.getMainLooper());
    private LinearLayout shell, content;
    private TextView live;
    private TrainerView trainer;
    private TouchTestView touch;
    private final PerfInfo.Fps fps = new PerfInfo.Fps();
    private SharedPreferences sp;
    private String screen = "home";
    private long sessionStart;

    // setup state
    private String mode = "Precision", profName = "";
    private int diff = 1, scope = 1, speedIdx = 1, dirIdx = 2, weapon = 0;
    private float customV = 7f, customH = 2f;
    private boolean gyroAssist = false, invX = false, invY = false;
    private String selProfile = "";

    // performance screen widgets
    private GameSpaceService.Gauge gCpu, gRam, gPing;
    private TextView perfText;
    private TextView homeStatus;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        sp = Store.sp(this);
        SensProfiles.ensureDefault(this);
        sessionStart = System.currentTimeMillis();
        PerfInfo.startPing();
        fps.start();
        shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(HubUi.BG);
        shell.setPadding(dp(16), dp(22), dp(16), 0);
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = HubUi.text(this, "\u2039", 30, Color.WHITE, true);
        back.setPadding(dp(4), 0, dp(16), 0);
        back.setOnClickListener(v -> onBackPressed());
        head.addView(back);
        TextView title = HubUi.text(this, "SHOOTER CENTER", 22, Color.WHITE, true);
        head.addView(title);
        TextView sub = HubUi.text(this, "   Training, sensitivity and Android tuning. Nothing here plays for you.", 11, HubUi.DIM, false);
        head.addView(sub);
        shell.addView(head);
        live = HubUi.text(this, "", 11, 0xFFFF6B7F, false);
        shell.addView(live);
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(4), 0, dp(24));
        sv.addView(content);
        shell.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(shell);
        String act = sp.getString("active_profile", "");
        profName = SensProfiles.find(this, act) != null ? act : SensProfiles.names(this).get(0);
        selProfile = profName;
        go("home");
        tick.run();
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (isFinishing()) return;
            long ping = PerfInfo.pingMs;
            double ghz = PerfInfo.cpuGhz();
            int mins = (int) ((System.currentTimeMillis() - sessionStart) / 60000);
            live.setText(String.format(Locale.US, "%d Hz  |  Ping %s  |  RAM %d%% used  |  CPU %s  |  Battery %d%%  |  App FPS %.0f  |  Session %d min",
                    PerfInfo.hz(ShooterActivity.this), ping < 0 ? "--" : ping + " ms", Math.round(PerfInfo.ramUsedFrac(ShooterActivity.this) * 100),
                    ghz > 0 ? String.format(Locale.US, "%.2f GHz", ghz) : "n/a", PerfInfo.battery(ShooterActivity.this), fps.fps, mins));
            if (screen.equals("perf") && gCpu != null) {
                gCpu.set(ghz > 0 ? String.format(Locale.US, "%.2f", ghz) : "--", "GHz", (float) (ghz / 4.2));
                float u = PerfInfo.ramUsedFrac(ShooterActivity.this);
                gRam.set(Math.round(u * 100) + "%", "used", u);
                gPing.set(ping < 0 ? "--" : String.valueOf(ping), "ms", ping < 0 ? 0f : Math.min(1f, ping / 150f));
                perfText.setText(Boost.statsLine(ShooterActivity.this, "Now"));
            }
            h.postDelayed(this, 1000);
        }
    };

    @Override protected void onDestroy() {
        super.onDestroy();
        fps.stop();
        if (!GameSpaceService.isRunning()) PerfInfo.stopPing();
        h.removeCallbacksAndMessages(null);
    }

    @Override public void onBackPressed() {
        if (trainer != null) { trainer.stop(); trainer = null; setContentView(shell); return; }
        if (touch != null) { touch = null; setContentView(shell); return; }
        if (!screen.equals("home")) go("home"); else finish();
    }

    private int dp(float v) { return HubUi.dp(this, v); }

    // ------------------------------------------------------------ navigation + helpers
    private void go(String s) {
        screen = s;
        content.removeAllViews();
        gCpu = null;
        switch (s) {
            case "aim": aimScreen(); break;
            case "recoil": recoilScreen(); break;
            case "sens": sensScreen(); break;
            case "gyro": gyroScreen(); break;
            case "react": reactScreen(); break;
            case "games": gamesScreen(); break;
            case "perf": perfScreen(); break;
            default: homeScreen();
        }
        content.setAlpha(0f);
        content.setTranslationX(dp(40));
        content.animate().alpha(1f).translationX(0).setDuration(180).start();
    }

    private LinearLayout section(String title) {
        LinearLayout c = HubUi.card(this, content);
        c.addView(HubUi.text(this, title, 12, HubUi.ACCENT, true));
        return c;
    }

    private void chips(LinearLayout p, String[] labels, int sel, final IntPick pick) {
        HubUi.chips(this, p, labels, labels[Math.max(0, Math.min(labels.length - 1, sel))], v -> {
            for (int i = 0; i < labels.length; i++) if (labels[i].equals(v)) pick.on(i);
        });
    }

    private interface IntPick { void on(int i); }

    private void ask(String title, String initial, final HubUi.Pick ok) {
        final EditText e = new EditText(this);
        e.setText(initial);
        new AlertDialog.Builder(this).setTitle(title).setView(e)
                .setPositiveButton("OK", (d, w) -> ok.on(e.getText().toString()))
                .setNegativeButton("Cancel", null).show();
    }

    private void profileChips(LinearLayout p) {
        List<String> n = SensProfiles.names(this);
        chips(p, n.toArray(new String[0]), Math.max(0, n.indexOf(profName)), i -> { profName = n.get(i); go(screen); });
    }

    private float scopeSens(JSONObject prof) { return SensProfiles.get(prof, indexOf(SensProfiles.KEYS, SCOPE_KEYS[scope])); }

    private static int indexOf(String[] a, String k) {
        for (int i = 0; i < a.length; i++) if (a[i].equals(k)) return i;
        return 0;
    }

    private void commonOptions(boolean withScope) {
        LinearLayout c = section("DIFFICULTY");
        chips(c, TrainerView.DIFFS, diff, i -> { diff = i; go(screen); });
        LinearLayout pc = section("SENSITIVITY PROFILE (used by the trainer)");
        profileChips(pc);
        if (withScope) {
            pc.addView(HubUi.text(this, "Scope: picks which of the profile's values is used", 11, HubUi.DIM, false));
            chips(pc, SCOPES, scope, i -> { scope = i; go(screen); });
        }
    }

    private void startTrainer() {
        JSONObject prof = SensProfiles.find(this, profName);
        TrainerView.Params p = new TrainerView.Params();
        p.mode = mode; p.diff = diff;
        float v = scopeSens(prof);
        p.touchSens = Math.max(0.1f, v / 100f * 1.2f);
        int gi = indexOf(SensProfiles.KEYS, scope == 0 ? "gyro" : "adsGyro");
        p.gyroSens = SensProfiles.get(prof, gi);
        p.vmult = SensProfiles.get(prof, 11);
        float[] sp2 = {0.5f, 1f, 1.5f, 2f};
        p.speedMul = sp2[speedIdx]; p.dir = dirIdx;
        if (mode.equals("Recoil")) {
            if (weapon < 3) { p.recV = WEAPON_KICK[weapon][0]; p.recH = WEAPON_KICK[weapon][1]; }
            else { p.recV = customV; p.recH = customH; }
        }
        p.gyroAssist = gyroAssist; p.invX = invX; p.invY = invY;
        p.label = (mode.equals("Gyro") ? "Gyro" : SCOPES[scope]) + " | " + profName;
        final TrainerView t = new TrainerView(this, p, new TrainerView.Callback() {
            @Override public void finished(TrainerView.Result r) { trainer = null; setContentView(shell); resultScreen(r); }
            @Override public void exit() { trainer = null; setContentView(shell); }
        });
        if (t.needsGyroButMissing()) { HubUi.toast(this, "This device has no gyroscope sensor."); return; }
        trainer = t;
        setContentView(t);
    }

    // ------------------------------------------------------------ home
    private void homeScreen() {
        LinearLayout c = section("QUICK ACCESS");
        String[][] tiles = {
                {"\uD83C\uDFAF", "SHOOTER MODE", "Real optimizations"}, {"\uD83D\uDD34", "AIM TRAINER", "Simulation"},
                {"\uD83D\uDD2B", "RECOIL TRAINER", "Simulation"}, {"\uD83C\uDF9A", "SENSITIVITY", "Saved profiles"},
                {"\uD83D\uDCF1", "GYRO TRAINER", "Simulation"}, {"\u26A1", "REACTION TEST", "Measured"},
                {"\uD83C\uDFAE", "GAME PROFILES", "Link + launch"}, {"\uD83D\uDCCA", "PERFORMANCE", "Live device data"}};
        String[] dest = {"shooter", "aim", "recoil", "sens", "gyro", "react", "games", "perf"};
        for (int r = 0; r < 2; r++) {
            LinearLayout row = new LinearLayout(this);
            for (int k = 0; k < 4; k++) {
                final int i = r * 4 + k;
                LinearLayout t = new LinearLayout(this);
                t.setOrientation(LinearLayout.VERTICAL);
                t.setGravity(Gravity.CENTER);
                t.setPadding(dp(6), dp(14), dp(6), dp(14));
                GradientDrawable g = new GradientDrawable();
                g.setColor(i == 0 ? 0xFFB00020 : HubUi.FIELD);
                g.setCornerRadius(dp(16));
                t.setBackground(g);
                TextView ic = HubUi.text(this, tiles[i][0], 28, Color.WHITE, false);
                ic.setGravity(Gravity.CENTER);
                t.addView(ic);
                TextView tt = HubUi.text(this, tiles[i][1], 13, Color.WHITE, true);
                tt.setGravity(Gravity.CENTER);
                t.addView(tt);
                TextView ss = HubUi.text(this, tiles[i][2], 10, i == 0 ? 0xFFFFD0D6 : HubUi.DIM, false);
                ss.setGravity(Gravity.CENTER);
                t.addView(ss);
                t.setOnTouchListener((v, e) -> {
                    if (e.getAction() == android.view.MotionEvent.ACTION_DOWN) v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(80).start();
                    else if (e.getAction() == android.view.MotionEvent.ACTION_UP || e.getAction() == android.view.MotionEvent.ACTION_CANCEL) v.animate().scaleX(1f).scaleY(1f).setDuration(80).start();
                    return false;
                });
                t.setOnClickListener(v -> { if (dest[i].equals("shooter")) runShooterMode(); else go(dest[i]); });
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(110), 1f);
                lp.setMargins(dp(4), dp(4), dp(4), dp(4));
                row.addView(t, lp);
            }
            c.addView(row);
        }
        LinearLayout st = section("SHOOTER MODE STATUS");
        homeStatus = HubUi.text(this, sp.getString("shooter_last", "Not run yet. Tap SHOOTER MODE: loads your game's profile, frees RAM, enables Do Not Disturb, applies your brightness, starts ping monitoring and keeps the Game Space edge panel available."), 12, HubUi.DIM, false);
        st.addView(homeStatus);
        content.addView(HubUi.button(this, "OPEN COMPLETE GAME SPACE FEATURE CENTER", false, v -> startActivity(new Intent(this, FeatureCenterActivity.class))));
        LinearLayout ov = section("GAME SPACE EDGE PANEL");
        final boolean on = GameSpaceService.isRunning();
        ov.addView(HubUi.button(this, on ? "Turn edge panel OFF" : "Turn edge panel ON", !on, v -> {
            if (on) startService(new Intent(this, GameSpaceService.class).setAction(GameSpaceService.ACTION_STOP));
            else if (!Settings.canDrawOverlays(this)) PermGate.request(this, "overlay");
            else startForegroundService(new Intent(this, GameSpaceService.class).setAction(GameSpaceService.ACTION_START));
            h.postDelayed(() -> go("home"), 500);
        }));
    }

    private void runShooterMode() {
        homeStatus.setText("Applying...");
        ShooterMode.apply(this, log -> { if (homeStatus != null) homeStatus.setText(log); HubUi.toast(this, "Shooter Mode applied"); });
    }

    // ------------------------------------------------------------ aim trainer
    private void aimScreen() {
        String[] modes = {"Precision", "Tracking", "Flick", "Crosshair"};
        if (indexOf(modes, mode) == 0 && !mode.equals("Precision")) mode = "Precision";
        LinearLayout c = section("AIM TRAINER");
        c.addView(HubUi.text(this, "Simulation. Precision = small still targets. Tracking = moving target. Flick = targets that vanish. Crosshair = keep your crosshair at head height. Drag to aim, tap FIRE.", 12, HubUi.DIM, false));
        chips(c, modes, indexOf(modes, mode), i -> { mode = modes[i]; go("aim"); });
        if (mode.equals("Tracking")) {
            c.addView(HubUi.text(this, "Target speed", 11, HubUi.DIM, false));
            chips(c, new String[]{"0.5x", "1x", "1.5x", "2x"}, speedIdx, i -> { speedIdx = i; go("aim"); });
            c.addView(HubUi.text(this, "Direction", 11, HubUi.DIM, false));
            chips(c, new String[]{"Horizontal", "Vertical", "Free"}, dirIdx, i -> { dirIdx = i; go("aim"); });
        } else if (mode.equals("Crosshair")) {
            c.addView(HubUi.text(this, "Targets run along a head-height band; your score is how long your crosshair stays inside it.", 11, HubUi.DIM, false));
            c.addView(HubUi.text(this, "Target speed", 11, HubUi.DIM, false));
            chips(c, new String[]{"0.5x", "1x", "1.5x", "2x"}, speedIdx, i -> { speedIdx = i; go("aim"); });
        }
        commonOptions(true);
        recordLine(mode);
        content.addView(HubUi.button(this, "START " + mode.toUpperCase(Locale.US), true, v -> startTrainer()));
    }

    // ------------------------------------------------------------ recoil
    private void recoilScreen() {
        mode = "Recoil";
        LinearLayout c = section("RECOIL TRAINER");
        c.addView(HubUi.text(this, "Simulation. Hold FIRE: a 30-round magazine kicks your crosshair up and sideways. Pull it back with your finger (or gyro assist) to keep shots on the target. Nothing compensates for you.", 12, HubUi.DIM, false));
        chips(c, WEAPONS, weapon, i -> { weapon = i; go("recoil"); });
        if (weapon == 3) {
            slider(c, "Vertical kick", customV, 15f, v -> customV = v);
            slider(c, "Horizontal drift", customH, 8f, v -> customH = v);
        } else {
            c.addView(HubUi.text(this, String.format(Locale.US, "Pattern: vertical %.1f, horizontal %.1f (before difficulty)", WEAPON_KICK[weapon][0], WEAPON_KICK[weapon][1]), 11, HubUi.DIM, false));
        }
        chips(c, new String[]{"Touch only", "Touch + gyro"}, gyroAssist ? 1 : 0, i -> { gyroAssist = i == 1; go("recoil"); });
        commonOptions(true);
        recordLine("Recoil");
        content.addView(HubUi.button(this, "START RECOIL DRILL", true, v -> startTrainer()));
    }

    // ------------------------------------------------------------ gyro
    private void gyroScreen() {
        mode = "Gyro";
        LinearLayout c = section("GYRO TRAINER");
        c.addView(HubUi.text(this, "Simulation. Aim only by tilting and turning the phone; tap FIRE on each target. If a direction feels backwards, flip it below.", 12, HubUi.DIM, false));
        chips(c, new String[]{"Turn: normal", "Turn: inverted"}, invX ? 1 : 0, i -> { invX = i == 1; go("gyro"); });
        chips(c, new String[]{"Tilt: normal", "Tilt: inverted"}, invY ? 1 : 0, i -> { invY = i == 1; go("gyro"); });
        commonOptions(true);
        recordLine("Gyro");
        content.addView(HubUi.button(this, "START GYRO DRILL", true, v -> startTrainer()));
    }

    // ------------------------------------------------------------ reaction + touch
    private void reactScreen() {
        mode = "Reaction";
        LinearLayout c = section("REACTION TEST");
        c.addView(HubUi.text(this, "Measured. 10 targets appear after random delays. Your time is from the frame the target appears until your FIRE tap lands on it.", 12, HubUi.DIM, false));
        commonOptions(false);
        float best = sp.getFloat("pr_react_best", 0f);
        content.addView(HubUi.text(this, best > 0 ? String.format(Locale.US, "Personal record (best average): %.0f ms", best) : "No record yet.", 12, HubUi.GOOD, false));
        content.addView(HubUi.button(this, "START REACTION TEST", true, v -> startTrainer()));
        LinearLayout t = section("TOUCH RESPONSE TEST");
        float tb = sp.getFloat("pr_touch_best", 0f);
        t.addView(HubUi.text(this, "Measures your touch reaction and how many touch samples your screen delivers per second." + (tb > 0 && tb < 99999 ? String.format(Locale.US, "  Best touch time: %.0f ms", tb) : ""), 12, HubUi.DIM, false));
        t.addView(HubUi.button(this, "START TOUCH TEST", false, v -> {
            touch = new TouchTestView(this, new TouchTestView.Done() {
                @Override public void finished(String s) { touch = null; setContentView(shell); textResult("TOUCH RESPONSE RESULT", s); }
                @Override public void exit() { touch = null; setContentView(shell); }
            });
            setContentView(touch);
        }));
    }

    private void textResult(String title, String body) {
        content.removeAllViews();
        LinearLayout c = section(title);
        c.addView(HubUi.text(this, body, 14, Color.WHITE, false));
        content.addView(HubUi.button(this, "Back", false, v -> go("react")));
    }

    private void recordLine(String m) {
        int best = sp.getInt("pr_" + m + "_" + diff, 0);
        content.addView(HubUi.text(this, best > 0 ? "Personal best on " + TrainerView.DIFFS[diff] + ": " + best + "   |   Session high: " + sessionHigh
                : "No record yet on " + TrainerView.DIFFS[diff] + "   |   Session high: " + sessionHigh, 12, HubUi.GOOD, false));
    }

    // ------------------------------------------------------------ results
    private void resultScreen(final TrainerView.Result r) {
        screen = "result";
        content.removeAllViews();
        boolean pb = false;
        String key = "pr_" + r.mode + "_" + r.diff;
        if (r.score > sp.getInt(key, 0)) { sp.edit().putInt(key, r.score).apply(); pb = true; }
        if (r.relevantReact && r.mode.equals("Reaction")) {
            float old = sp.getFloat("pr_react_best", 0f);
            if (old == 0 || r.reactMs < old) { sp.edit().putFloat("pr_react_best", r.reactMs).apply(); pb = true; }
        }
        if (r.score > sessionHigh) sessionHigh = r.score;
        LinearLayout c = section(r.mode.toUpperCase(Locale.US) + " RESULT  |  " + TrainerView.DIFFS[r.diff]);
        c.addView(HubUi.text(this, "Score " + r.score + (pb ? "   NEW PERSONAL BEST" : ""), 26, pb ? HubUi.GOOD : Color.WHITE, true));
        c.addView(HubUi.text(this, "Session high score: " + sessionHigh + "   |   " + r.label, 12, HubUi.DIM, false));
        LinearLayout s = section("MEASURED FROM YOUR PLAY");
        String na = "n/a in this mode";
        String[] rows = {
                String.format(Locale.US, "Accuracy: %.1f%%", r.accuracy),
                "Shots fired: " + r.shots,
                "Shots on target: " + r.hits,
                String.format(Locale.US, "Average distance from center: %.1f dp", r.avgDistDp),
                "Reaction time: " + (r.relevantReact ? String.format(Locale.US, "%.0f ms average", r.reactMs) : na),
                "Recoil-control score: " + (r.relevantRecoil ? String.format(Locale.US, "%.0f / 100", r.recoilScore) : na),
                "Tracking score: " + (r.relevantTrack ? String.format(Locale.US, "%.0f%% of time on target", r.trackScore) : na),
                String.format(Locale.US, "Time: %.0f s%s", r.seconds, r.expired > 0 ? "   |   Targets missed (expired): " + r.expired : "")};
        for (String line : rows) s.addView(HubUi.text(this, line, 14, Color.WHITE, false));
        s.addView(HubUi.text(this, "Score = (hits x 100 + tracking% x 5 + recoil score x 5) x difficulty bonus x accuracy factor.", 11, HubUi.DIM, false));
        content.addView(HubUi.button(this, "Retry", true, v -> startTrainer()));
        final String back = r.mode.equals("Recoil") ? "recoil" : r.mode.equals("Gyro") ? "gyro" : r.mode.equals("Reaction") ? "react" : "aim";
        content.addView(HubUi.button(this, "Back", false, v -> go(back)));
    }

    // ------------------------------------------------------------ sensitivity center
    private interface FloatPick { void on(float v); }

    private void slider(LinearLayout p, final String label, float val, final float max, final FloatPick pick) {
        final TextView t = HubUi.text(this, String.format(Locale.US, "%s: %.1f", label, val), 13, Color.WHITE, false);
        p.addView(t);
        SeekBar sb = new SeekBar(this);
        sb.setMax(1000);
        sb.setProgress(Math.round(val / max * 1000));
        sb.getProgressDrawable().setTint(HubUi.ACCENT);
        sb.getThumb().setTint(Color.WHITE);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int pr, boolean u) {
                float v = pr * max / 1000f;
                t.setText(String.format(Locale.US, "%s: %.1f", label, v));
                if (u) pick.on(v);
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        p.addView(sb, new LinearLayout.LayoutParams(-1, dp(40)));
    }

    private void sensScreen() {
        final String cur = selProfile.length() > 0 && SensProfiles.find(this, selProfile) != null ? selProfile : SensProfiles.names(this).get(0);
        selProfile = cur;
        LinearLayout c = section("PROFILES (saved on this phone)");
        List<String> n = SensProfiles.names(this);
        chips(c, n.toArray(new String[0]), Math.max(0, n.indexOf(cur)), i -> { selProfile = n.get(i); go("sens"); });
        LinearLayout row = new LinearLayout(this);
        row.addView(small("New", v -> ask("New profile name", "", s -> { selProfile = SensProfiles.add(this, s, currentGameLabel()); go("sens"); })));
        row.addView(small("Duplicate", v -> { selProfile = SensProfiles.duplicate(this, cur); go("sens"); }));
        row.addView(small("Rename", v -> ask("Rename profile", cur, s -> { selProfile = SensProfiles.rename(this, cur, s); go("sens"); })));
        row.addView(small("Reset", v -> new AlertDialog.Builder(this).setTitle("Reset \"" + cur + "\" to defaults?")
                .setPositiveButton("Reset", (d, w) -> { SensProfiles.reset(this, cur); go("sens"); }).setNegativeButton("Cancel", null).show()));
        row.addView(small("Delete", v -> {
            if (SensProfiles.names(this).size() <= 1) { HubUi.toast(this, "Keep at least one profile."); return; }
            new AlertDialog.Builder(this).setTitle("Delete \"" + cur + "\"?").setPositiveButton("Delete", (d, w) -> {
                SensProfiles.delete(this, cur); selProfile = SensProfiles.names(this).get(0); go("sens"); }).setNegativeButton("Cancel", null).show();
        }));
        c.addView(row);
        LinearLayout row2 = new LinearLayout(this);
        row2.addView(small("Export (copy + share)", v -> {
            String json = SensProfiles.export(this);
            ((ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("profiles", json));
            Intent si = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, json);
            startActivity(Intent.createChooser(si, "Export profiles"));
        }));
        row2.addView(small("Import (paste)", v -> {
            final EditText e = new EditText(this);
            e.setHint("Paste exported profiles here");
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0 && cm.getPrimaryClip().getItemAt(0).getText() != null)
                e.setText(cm.getPrimaryClip().getItemAt(0).getText());
            new AlertDialog.Builder(this).setTitle("Import profiles").setView(e).setPositiveButton("Import", (d, w) -> {
                int k = SensProfiles.importJson(this, e.getText().toString());
                HubUi.toast(this, k > 0 ? "Imported " + k + " profile(s)" : "Nothing imported: that text is not a profile export.");
                go("sens");
            }).setNegativeButton("Cancel", null).show();
        }));
        c.addView(row2);

        LinearLayout g = section("GAME THIS PROFILE IS FOR");
        String[] games = {"CODM", "PUBG Mobile", "BGMI", "Free Fire", "Standoff 2", "Other"};
        JSONObject prof = SensProfiles.find(this, cur);
        String pg = prof == null ? "CODM" : prof.optString("game", "CODM");
        chips(g, games, indexOf(games, pg), i -> { SensProfiles.setGame(this, cur, games[i]); go("sens"); });

        LinearLayout v = section("VALUES");
        v.addView(HubUi.text(this, "These are your own reference values. Type them into the game's settings; the trainers here use them too.", 11, HubUi.DIM, false));
        for (int i = 0; i < SensProfiles.KEYS.length; i++) {
            final int idx = i;
            slider(v, SensProfiles.LABELS[i], SensProfiles.get(prof, i), SensProfiles.MAX[i], val -> SensProfiles.setVal(this, cur, idx, val));
        }
    }

    private String currentGameLabel() { return "CODM"; }

    private TextView small(String label, View.OnClickListener l) {
        TextView t = HubUi.text(this, label, 12, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(10), dp(12), dp(10), dp(12));
        GradientDrawable g = new GradientDrawable();
        g.setColor(HubUi.FIELD);
        g.setCornerRadius(dp(12));
        t.setBackground(g);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(3), dp(8), dp(3), 0);
        t.setLayoutParams(lp);
        return t;
    }

    // ------------------------------------------------------------ game profiles
    private void gamesScreen() {
        LinearLayout c = section("INSTALLED SHOOTING GAMES");
        final List<String[]> inst = Boost.installedGames(this);
        if (inst.isEmpty()) {
            c.addView(HubUi.text(this, "No supported game found (CODM, PUBG Mobile, BGMI, Free Fire, Standoff 2).", 12, HubUi.WARN, false));
        } else {
            String curPkg = sp.getString("boost_game", inst.get(0)[1]);
            String[] labels = new String[inst.size()];
            int sel = 0;
            for (int i = 0; i < inst.size(); i++) { labels[i] = inst.get(i)[0]; if (inst.get(i)[1].equals(curPkg)) sel = i; }
            final int fsel = sel;
            sp.edit().putString("boost_game", inst.get(fsel)[1]).apply();
            chips(c, labels, sel, i -> { sp.edit().putString("boost_game", inst.get(i)[1]).apply(); go("games"); });
            final String pkg = inst.get(fsel)[1];
            LinearLayout pc = section("PROFILE LINKED TO " + inst.get(fsel)[0].toUpperCase(Locale.US));
            List<String> n = SensProfiles.names(this);
            String act = SensProfiles.activeFor(this, pkg);
            pc.addView(HubUi.text(this, act.length() == 0 ? "None linked yet." : "Linked: " + act, 12, HubUi.GOOD, false));
            chips(pc, n.toArray(new String[0]), Math.max(0, n.indexOf(act)), i -> { SensProfiles.setActive(this, pkg, n.get(i)); go("games"); });
        }
        LinearLayout b = section("PREFERRED BRIGHTNESS FOR GAMING");
        int pb = sp.getInt("pref_bright", 0);
        b.addView(HubUi.text(this, "0 = use maximum. Applied by BOOST & LAUNCH and Shooter Mode (needs 'Modify system settings').", 11, HubUi.DIM, false));
        slider(b, "Brightness (0-255)", pb, 255f, v -> sp.edit().putInt("pref_bright", Math.round(v)).apply());
        LinearLayout l = section("BOOST & LAUNCH");
        l.addView(HubUi.text(this, "Loads the linked profile, frees RAM, Do Not Disturb, your brightness, starts ping monitoring, launches the game and keeps the edge panel available.", 11, HubUi.DIM, false));
        final TextView out = HubUi.text(this, sp.getString("boost_last", ""), 12, HubUi.DIM, false);
        l.addView(HubUi.button(this, "BOOST & LAUNCH", true, v -> {
            Boost.runBoost(this, out, true);
            if (Settings.canDrawOverlays(this) && !GameSpaceService.isRunning())
                startForegroundService(new Intent(this, GameSpaceService.class).setAction(GameSpaceService.ACTION_START));
        }));
        l.addView(out);
    }

    // ------------------------------------------------------------ performance
    private void perfScreen() {
        LinearLayout c = section("LIVE PERFORMANCE (real device readings)");
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        gCpu = new GameSpaceService.Gauge(this, "CPU");
        gRam = new GameSpaceService.Gauge(this, "RAM");
        gPing = new GameSpaceService.Gauge(this, "PING");
        for (GameSpaceService.Gauge g : new GameSpaceService.Gauge[]{gCpu, gRam, gPing}) row.addView(g, new LinearLayout.LayoutParams(0, dp(150), 1f));
        c.addView(row);
        perfText = HubUi.text(this, "", 13, Color.WHITE, false);
        c.addView(perfText);
        c.addView(HubUi.text(this, "CPU shows 'n/a' on phones that block reading frequency. 'App FPS' above is this app's own rendered frame rate; Android does not let any app read another game's FPS, so none is shown for games. The trainers show their own Training FPS.", 11, HubUi.DIM, false));
        LinearLayout t = section("TRAINING BESTS");
        String[] ms = {"Precision", "Tracking", "Flick", "Recoil", "Gyro", "Crosshair", "Reaction"};
        for (String m : ms) {
            StringBuilder sb = new StringBuilder(m + ":  ");
            for (int d = 0; d < 4; d++) sb.append(TrainerView.DIFFS[d].charAt(0)).append(' ').append(sp.getInt("pr_" + m + "_" + d, 0)).append("   ");
            t.addView(HubUi.text(this, sb.toString(), 12, Color.WHITE, false));
        }
    }
}
