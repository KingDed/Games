package com.antonyhern16.lowhealth;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;

import java.util.Locale;
import java.util.Random;

/**
 * Touch Response Test: 10 targets (reaction + accuracy of your touch), then a 3 second drag that counts
 * how many touch samples Android really delivers per second. All numbers are measured, none are made up.
 */
final class TouchTestView extends View {
    interface Done { void finished(String summary); void exit(); }

    private final Done done;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rnd = new Random();
    private final Handler h = new Handler(Looper.getMainLooper());
    private final float d;
    private int round = 0, misses = 0, phase = 0;   // 0 rounds, 1 drag, 2 done
    private boolean showing = false, needStamp = false;
    private float x, y, r;
    private long appearAt;
    private final float[] lat = new float[10], err = new float[10];
    private long dragStart = 0;
    private int samples = 0;
    private String summary = "";

    TouchTestView(Context c, Done done) {
        super(c);
        this.done = done;
        this.d = c.getResources().getDisplayMetrics().density;
        this.r = 42 * d;
        scheduleNext();
    }

    private void scheduleNext() {
        showing = false;
        h.postDelayed(() -> {
            if (getWidth() == 0) { scheduleNext(); return; }
            x = r + rnd.nextFloat() * (getWidth() - 2 * r);
            y = 90 * d + r + rnd.nextFloat() * (getHeight() - 180 * d - 2 * r);
            showing = true; needStamp = true;
            invalidate();
        }, 600 + rnd.nextInt(1500));
    }

    @Override protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        h.removeCallbacksAndMessages(null);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN && e.getX() < 70 * d && e.getY() < 70 * d) { done.exit(); return true; }
        if (phase == 0 && a == MotionEvent.ACTION_DOWN) {
            if (!showing) { misses++; return true; }          // touched too early
            float dist = (float) Math.hypot(e.getX() - x, e.getY() - y);
            if (dist > r * 1.6f) { misses++; return true; }
            lat[round] = e.getEventTime() - appearAt;
            err[round] = dist / d;
            round++;
            showing = false;
            if (round >= 10) { phase = 1; dragStart = 0; } else scheduleNext();
            invalidate();
        } else if (phase == 1) {
            if (a == MotionEvent.ACTION_DOWN && dragStart == 0) { dragStart = e.getEventTime(); samples = 0; }
            if (dragStart != 0 && (a == MotionEvent.ACTION_MOVE || a == MotionEvent.ACTION_DOWN)) {
                samples += e.getHistorySize() + 1;
                long span = e.getEventTime() - dragStart;
                if (span >= 3000) finishDrag(span);
            }
            invalidate();
        }
        return true;
    }

    private void finishDrag(long span) {
        phase = 2;
        float sum = 0, best = Float.MAX_VALUE, es = 0;
        for (int i = 0; i < 10; i++) { sum += lat[i]; best = Math.min(best, lat[i]); es += err[i]; }
        float hz = samples * 1000f / span;
        summary = String.format(Locale.US, "Touch reaction: %.0f ms average, %.0f ms best\nTouch accuracy: %.1f dp average from center\nEarly/missed touches: %d\nTouch sampling: about %.0f samples/s while dragging",
                sum / 10, best, es / 10, misses, hz);
        Store.sp(getContext()).edit().putFloat("pr_touch_best", Math.min(Store.sp(getContext()).getFloat("pr_touch_best", 99999f), best)).apply();
        done.finished(summary);
    }

    @Override protected void onDraw(Canvas c) {
        c.drawColor(0xFF08080B);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.WHITE);
        p.setTextSize(22 * d);
        c.drawText("\u2715", 28 * d, 38 * d, p);
        p.setTextSize(15 * d);
        p.setColor(0xFFFF6B7F);
        String t = phase == 0 ? "TOUCH RESPONSE TEST  " + Math.min(round + 1, 10) + "/10  (touch each dot the moment it appears)"
                : "Now drag your finger around the screen for 3 seconds to measure touch sampling";
        c.drawText(t, getWidth() / 2f, 40 * d, p);
        if (phase == 0 && showing) {
            if (needStamp) { appearAt = SystemClock.uptimeMillis(); needStamp = false; }
            p.setColor(0x33FF2D4B); c.drawCircle(x, y, r * 1.4f, p);
            p.setColor(0xFFFF2D4B); c.drawCircle(x, y, r, p);
            p.setColor(Color.WHITE); c.drawCircle(x, y, r * 0.3f, p);
        }
        if (phase == 1 && dragStart != 0) {
            p.setColor(Color.WHITE); p.setTextSize(28 * d);
            c.drawText(samples + " samples", getWidth() / 2f, getHeight() / 2f, p);
        }
    }
}
