package com.antonyhern16.lowhealth;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

/** Local persistence for Game Hub. Everything lives in the "gamehub" SharedPreferences file as JSON. */
final class Store {
    private Store() {}

    static SharedPreferences sp(Context c) { return c.getSharedPreferences("gamehub", Context.MODE_PRIVATE); }

    static JSONArray arr(Context c, String key) {
        try {
            return new JSONArray(sp(c).getString(key, "[]"));
        } catch (Exception e) {
            return new JSONArray();   // corrupt data never crashes the app
        }
    }

    static boolean put(Context c, String key, JSONArray a) {
        try {
            sp(c).edit().putString(key, a.toString()).apply();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Appends one record, keeping only the newest {@code max}. */
    static boolean append(Context c, String key, JSONObject o, int max) {
        JSONArray a = arr(c, key);
        a.put(o);
        if (a.length() > max) {
            JSONArray n = new JSONArray();
            for (int i = a.length() - max; i < a.length(); i++) n.put(a.opt(i));
            a = n;
        }
        return put(c, key, a);
    }

    static boolean removeAt(Context c, String key, int index) {
        JSONArray cur = arr(c, key);
        JSONArray n = new JSONArray();
        for (int i = 0; i < cur.length(); i++) if (i != index) n.put(cur.opt(i));
        return put(c, key, n);
    }

    static boolean lowerBetter(String mode) { return "reaction".equals(mode) || "switch".equals(mode); }

    static String modeName(String mode) {
        if ("reaction".equals(mode)) return "Reaction time";
        if ("switch".equals(mode)) return "Target switching";
        return "Tracking";
    }

    static String unit(String mode) { return "track".equals(mode) ? "%" : " ms"; }

    /** Personal best score for a drill, or null if none yet. */
    static Double best(Context c, String game, String mode) {
        JSONArray a = arr(c, "train");
        Double b = null;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null || !game.equals(o.optString("game")) || !mode.equals(o.optString("mode"))) continue;
            double s = o.optDouble("score", Double.NaN);
            if (Double.isNaN(s)) continue;
            if (b == null || (lowerBetter(mode) ? s < b : s > b)) b = s;
        }
        return b;
    }

    /** Average drill score in the time window [from, to), or null if there are none. */
    static Double avgTrain(Context c, String game, String mode, long from, long to) {
        JSONArray a = arr(c, "train");
        double sum = 0;
        int n = 0;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null || !game.equals(o.optString("game")) || !mode.equals(o.optString("mode"))) continue;
            long t = o.optLong("t");
            double s = o.optDouble("score", Double.NaN);
            if (t >= from && t < to && !Double.isNaN(s)) {
                sum += s;
                n++;
            }
        }
        return n == 0 ? null : sum / n;
    }

    /** K/D (kills / max(1, deaths)) over matches in the window, or null. */
    static Double kd(Context c, String game, long from, long to) {
        JSONArray a = arr(c, "matches");
        int k = 0, d = 0, n = 0;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null || !game.equals(o.optString("game"))) continue;
            long t = o.optLong("t");
            if (t >= from && t < to) {
                k += o.optInt("k");
                d += o.optInt("d");
                n++;
            }
        }
        return n == 0 ? null : (double) k / Math.max(1, d);
    }
}
