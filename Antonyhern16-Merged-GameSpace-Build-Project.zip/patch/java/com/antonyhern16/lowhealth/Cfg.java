package com.antonyhern16.lowhealth;

import android.content.Context;
import android.content.SharedPreferences;

/** Settings. Region values are PERCENT of the screen (0-100), so they work in any orientation/resolution. */
final class Cfg {
    static final String PREFS = "lowhealth_cfg";
    float l = 8f, t = 88f, r = 30f, b = 92f;
    int rgb = 0xD32F2F;
    int tol = 60;       // max RGB distance for a pixel to count (0..441)
    int frac = 30;      // percent of sampled pixels that must match
    boolean haptic = true, flash = true, debug = false;
    long intervalMs = 250, cooldownMs = 3000;

    static Cfg load(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        Cfg g = new Cfg();
        g.l = p.getFloat("l", g.l);
        g.t = p.getFloat("t", g.t);
        g.r = p.getFloat("r", g.r);
        g.b = p.getFloat("b", g.b);
        g.rgb = p.getInt("rgb", g.rgb);
        g.tol = p.getInt("tol", g.tol);
        g.frac = p.getInt("frac", g.frac);
        g.haptic = p.getBoolean("haptic", g.haptic);
        g.flash = p.getBoolean("flash", g.flash);
        g.debug = p.getBoolean("debug", g.debug);
        return g;
    }

    void save(Context c) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putFloat("l", l).putFloat("t", t).putFloat("r", r).putFloat("b", b)
                .putInt("rgb", rgb).putInt("tol", tol).putInt("frac", frac)
                .putBoolean("haptic", haptic).putBoolean("flash", flash).putBoolean("debug", debug)
                .apply();
    }

    boolean valid() {
        return r > l && b > t && l >= 0 && t >= 0 && r <= 100 && b <= 100;
    }

    boolean matches(int pr, int pg, int pb) {
        int dr = pr - ((rgb >> 16) & 0xFF);
        int dg = pg - ((rgb >> 8) & 0xFF);
        int db = pb - (rgb & 0xFF);
        return Math.sqrt(dr * dr + dg * dg + db * db) <= tol;
    }
}
