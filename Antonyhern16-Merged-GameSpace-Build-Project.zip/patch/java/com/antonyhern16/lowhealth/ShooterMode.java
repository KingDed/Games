package com.antonyhern16.lowhealth;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;

import org.json.JSONObject;

/**
 * SHOOTER MODE: the strongest legitimate setup Android allows with the permissions you granted.
 * It does not touch the game: no code injection, no memory access, no aim or fire automation.
 */
final class ShooterMode {
    interface Done { void on(String log); }

    private ShooterMode() {}

    static String loadProfile(Context c, String game) {
        String name = game.length() == 0 ? "" : SensProfiles.activeFor(c, game);
        JSONObject p = name.length() == 0 ? null : SensProfiles.find(c, name);
        if (p == null) return "Profile: none linked to this game (Shooter Center > Game Profiles).";
        Store.sp(c).edit().putString("active_profile", name).apply();
        return String.format(java.util.Locale.US, "Profile loaded: %s (camera %.0f, ADS %.0f, gyro %.0f). Copy these values into the game's own settings; this app cannot change the game for you.",
                name, SensProfiles.get(p, 0), SensProfiles.get(p, 1), SensProfiles.get(p, 2));
    }

    /** Preferred brightness (Game Profiles) or maximum when none is set. */
    static String brightness(Context c) {
        int v = Store.sp(c).getInt("pref_bright", 0);
        String s = Boost.setBrightness(c, true);
        if (v > 0 && s.startsWith("Brightness: maxed")) {
            try {
                Settings.System.putInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, v);
                return "Brightness: your preferred level (" + v + "/255).";
            } catch (Exception e) { return "Brightness: could not apply preferred level."; }
        }
        return s;
    }

    static void apply(final Context c, final Done done) {
        final Handler main = new Handler(Looper.getMainLooper());
        final String game = Store.sp(c).getString("boost_game", "");
        new Thread(() -> {
            StringBuilder log = new StringBuilder();
            try {
                log.append(loadProfile(c, game)).append('\n');
                log.append(Boost.cleanRam(c, game)).append('\n');
                log.append(Boost.setDnd(c, true)).append('\n');
                log.append(brightness(c)).append('\n');
            } catch (Exception e) {
                log.append("Some steps failed: ").append(e.getClass().getSimpleName()).append('\n');
            }
            PerfInfo.startPing();
            log.append("Network and performance monitoring: on.\n");
            try {
                if (Settings.canDrawOverlays(c) && !GameSpaceService.isRunning()) {
                    c.startForegroundService(new Intent(c, GameSpaceService.class).setAction(GameSpaceService.ACTION_START));
                }
                log.append(Settings.canDrawOverlays(c) ? "Game Space edge panel: available." : "Game Space edge panel: needs 'Display over other apps'.");
            } catch (Exception ignored) { }
            final String out = log.toString().trim();
            Store.sp(c).edit().putString("shooter_last", out).apply();
            main.post(() -> done.on(out));
        }).start();
    }
}
