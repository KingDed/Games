package com.antonyhern16.lowhealth;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Small, touch-through stats strip (time, free RAM, battery, temperature, thermal) drawn over the game. */
public class BoostOverlayService extends Service implements Runnable {
    public static final String ACTION_START = "com.antonyhern16.lowhealth.OVERLAY_START";
    public static final String ACTION_STOP = "com.antonyhern16.lowhealth.OVERLAY_STOP";
    private static final String CHANNEL = "boost_overlay";
    private static volatile boolean running = false;

    private WindowManager wm;
    private TextView view;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final SimpleDateFormat clock = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());

    static boolean isRunning() { return running; }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent i, int flags, int id) {
        if (i != null && ACTION_STOP.equals(i.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (running) return START_STICKY;
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startAsForeground();
        try {
            wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            view = new TextView(this);
            view.setTextColor(Color.WHITE);
            view.setBackgroundColor(0x99000000);
            view.setTextSize(11);
            view.setPadding(14, 6, 14, 6);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            wm.addView(view, lp);
            running = true;
            h.post(this);
        } catch (Exception e) {
            stopSelf();
        }
        return START_STICKY;
    }

    private void startAsForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Booster overlay", NotificationManager.IMPORTANCE_LOW));
        Intent stop = new Intent(this, BoostOverlayService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("Booster stats overlay is on")
                .setContentText("Tap to turn it off")
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(4301, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(4301, n);
    }

    @Override
    public void run() {
        if (!running || view == null) return;
        view.setText(Boost.statsLine(this, clock.format(new Date())));
        h.postDelayed(this, 1000);
    }

    @Override
    public void onDestroy() {
        running = false;
        h.removeCallbacksAndMessages(null);
        try {
            if (wm != null && view != null) wm.removeView(view);
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }
}
