package com.antonyhern16.lowhealth;

import android.app.*; import android.content.*; import android.content.pm.*; import android.hardware.*; import android.hardware.display.DisplayManager; import android.media.AudioManager; import android.net.*; import android.os.*; import android.provider.Settings; import android.view.*; import java.util.*;

/** Runtime capability matrix. Never turns an unavailable OEM feature into a fake success. */
public final class CapabilityMatrix {
 public enum State { SUPPORTED, PARTIALLY_SUPPORTED, PERMISSION_REQUIRED, ROOT_REQUIRED, VENDOR_API_REQUIRED, HARDWARE_REQUIRED, UNSUPPORTED }
 public static final class Cap { public final String name; public final State state; public final String detail; Cap(String n, State s, String d){name=n;state=s;detail=d;} }
 private CapabilityMatrix(){}
 public static List<Cap> scan(Context c){ ArrayList<Cap> a=new ArrayList<>(); PackageManager pm=c.getPackageManager();
  a.add(new Cap("Game Space overlay", Settings.canDrawOverlays(c)?State.SUPPORTED:State.PERMISSION_REQUIRED,"Android overlay permission"));
  a.add(new Cap("DND control", ((android.app.NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).isNotificationPolicyAccessGranted()?State.SUPPORTED:State.PERMISSION_REQUIRED,"Notification policy access"));
  a.add(new Cap("Brightness control", Settings.System.canWrite(c)?State.SUPPORTED:State.PERMISSION_REQUIRED,"Modify system settings"));
  a.add(new Cap("Gyroscope", pm.hasSystemFeature(PackageManager.FEATURE_SENSOR_GYROSCOPE)?State.SUPPORTED:State.HARDWARE_REQUIRED,"Used only by in-app trainers"));
  a.add(new Cap("Accelerometer / motion", pm.hasSystemFeature(PackageManager.FEATURE_SENSOR_ACCELEROMETER)?State.SUPPORTED:State.HARDWARE_REQUIRED,"Android SensorManager"));
  a.add(new Cap("Screen recording", Build.VERSION.SDK_INT>=21?State.PERMISSION_REQUIRED:State.UNSUPPORTED,"MediaProjection requires user consent each capture session"));
  a.add(new Cap("Microphone recording", pm.hasSystemFeature(PackageManager.FEATURE_MICROPHONE)?State.PERMISSION_REQUIRED:State.HARDWARE_REQUIRED,"Runtime permission required"));
  a.add(new Cap("Network telemetry", State.SUPPORTED,"ConnectivityManager + measured latency"));
  a.add(new Cap("Thermal status", Build.VERSION.SDK_INT>=29?State.SUPPORTED:State.UNSUPPORTED,"PowerManager thermal API; sensor detail varies by OEM"));
  DisplayManager dm=(DisplayManager)c.getSystemService(Context.DISPLAY_SERVICE); Display[] ds=dm.getDisplays();
  a.add(new Cap("External display", ds.length>1?State.SUPPORTED:State.HARDWARE_REQUIRED,ds.length>1?(ds.length-1)+" external display(s) detected":"No external display detected"));
  boolean pad=false,kb=false,mouse=false; for(int id:InputDevice.getDeviceIds()){InputDevice d=InputDevice.getDevice(id); if(d==null)continue; int s=d.getSources(); pad|=(s&InputDevice.SOURCE_GAMEPAD)==InputDevice.SOURCE_GAMEPAD||(s&InputDevice.SOURCE_JOYSTICK)==InputDevice.SOURCE_JOYSTICK; kb|=(s&InputDevice.SOURCE_KEYBOARD)==InputDevice.SOURCE_KEYBOARD; mouse|=(s&InputDevice.SOURCE_MOUSE)==InputDevice.SOURCE_MOUSE;}
  a.add(new Cap("Controller center", pad?State.SUPPORTED:State.HARDWARE_REQUIRED,pad?"Android gamepad detected":"No gamepad detected")); a.add(new Cap("Keyboard / mouse",(kb||mouse)?State.SUPPORTED:State.HARDWARE_REQUIRED,(kb?"Keyboard ":"")+(mouse?"Mouse":"")));
  a.add(new Cap("Touch profiles", State.PARTIALLY_SUPPORTED,"Affects Antonyhern16 trainers/overlays; Android does not expose global touch-controller tuning"));
  a.add(new Cap("Graphics overrides", State.PARTIALLY_SUPPORTED,"Device/API info is real; another game's private renderer cannot be overridden"));
  a.add(new Cap("Other-game FPS", State.UNSUPPORTED,"No reliable public Android API for arbitrary third-party game FPS; app FPS remains available"));
  a.add(new Cap("CPU/GPU overclock", State.ROOT_REQUIRED,"Requires kernel/root or OEM interfaces; never simulated"));
  a.add(new Cap("Cooling fan", State.VENDOR_API_REQUIRED,"Requires compatible fan hardware and documented/vendor integration"));
  a.add(new Cap("Bypass charging", State.VENDOR_API_REQUIRED,"Requires compatible charging hardware/vendor support"));
  a.add(new Cap("RGB lighting", State.VENDOR_API_REQUIRED,"Requires compatible lighting hardware/vendor API"));
  a.add(new Cap("Shoulder triggers", State.HARDWARE_REQUIRED,"Requires supported gaming-phone hardware/vendor API; external controllers use Android input APIs"));
  a.add(new Cap("Frame interpolation", State.VENDOR_API_REQUIRED,"Only available through supported device/graphics hardware APIs"));
  return a; }
 public static String deviceSummary(Context c){ ActivityManager am=(ActivityManager)c.getSystemService(Context.ACTIVITY_SERVICE); ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo();am.getMemoryInfo(mi); Display d=((WindowManager)c.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay(); return Build.MANUFACTURER+" "+Build.MODEL+" • Android "+Build.VERSION.RELEASE+" • "+Math.round(mi.totalMem/1073741824f)+" GB RAM • "+d.getMode().getPhysicalWidth()+"×"+d.getMode().getPhysicalHeight()+" @ "+Math.round(d.getRefreshRate())+" Hz"; }
}
