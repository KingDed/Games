package com.antonyhern16.lowhealth;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import java.nio.ByteBuffer;

/**
 * PASSIVE low-health style alert. Reads pixels in a user-defined rectangle and, when enough of them
 * match a target colour, vibrates and/or flashes the screen edges.
 * It never injects touches, taps or gestures and does not use an AccessibilityService.
 */
public class LowHealthService extends Service implements Runnable {
    public static final String ACTION_START = "com.antonyhern16.lowhealth.START";
    public static final String ACTION_STOP = "com.antonyhern16.lowhealth.STOP";
    public static final String EXTRA_CODE = "code";
    public static final String EXTRA_DATA = "data";
    private static final String CHANNEL = "lowhealth";
    private static final int NOTIF_ID = 4202;

    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private HandlerThread thread;
    private Handler worker;
    private final Handler main = new Handler(Looper.getMainLooper());
    private EdgeFlashView flashView;
    private Cfg cfg;
    private volatile boolean running = false;
    private long lastAlert = 0, lastDebug = 0;

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent == null || !ACTION_START.equals(intent.getAction())) return START_NOT_STICKY;

        // Must be a foreground service of type mediaProjection BEFORE getMediaProjection() on Android 14+.
        startAsForeground("Starting...");
        cfg = Cfg.load(this);
        if (!cfg.valid()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        Intent data = intent.getParcelableExtra(EXTRA_DATA);
        int code = intent.getIntExtra(EXTRA_CODE, 0);
        if (data == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        projection = mpm.getMediaProjection(code, data);
        if (projection == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        projection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        stopSelf();
                    }
                });
            }
        }, main);
        startCapture();
        return START_NOT_STICKY;
    }

    private void startCapture() {
        WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        thread = new HandlerThread("lowhealth-sampler");
        thread.start();
        worker = new Handler(thread.getLooper());
        reader = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2);
        display = projection.createVirtualDisplay("lowhealth", dm.widthPixels, dm.heightPixels,
                dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, null);
        running = true;
        worker.post(this);
    }

    @Override
    public void run() {
        if (!running) return;
        try {
            sample();
        } catch (Exception ignored) {
            // a bad frame must never crash the service
        }
        if (worker != null) worker.postDelayed(this, cfg.intervalMs);
    }

    private void sample() {
        Image img = reader.acquireLatestImage();
        if (img == null) return;
        try {
            Image.Plane pl = img.getPlanes()[0];
            ByteBuffer buf = pl.getBuffer();
            int rowStride = pl.getRowStride(), px = pl.getPixelStride();
            int w = img.getWidth(), h = img.getHeight();
            int l = clamp((int) (cfg.l / 100f * w), 0, w - 1);
            int r = clamp((int) (cfg.r / 100f * w), l + 1, w);
            int t = clamp((int) (cfg.t / 100f * h), 0, h - 1);
            int b = clamp((int) (cfg.b / 100f * h), t + 1, h);
            int step = Math.max(2, Math.min(r - l, b - t) / 24);
            int total = 0, hit = 0;
            for (int y = t; y < b; y += step) {
                for (int x = l; x < r; x += step) {
                    int o = y * rowStride + x * px;
                    int red = buf.get(o) & 0xFF, green = buf.get(o + 1) & 0xFF, blue = buf.get(o + 2) & 0xFF;
                    total++;
                    if (cfg.matches(red, green, blue)) hit++;
                }
            }
            if (total == 0) return;
            int pct = hit * 100 / total;
            long now = SystemClock.elapsedRealtime();
            if (cfg.debug && now - lastDebug > 1000) {
                lastDebug = now;
                final String s = "Match " + pct + "% (alert at " + cfg.frac + "%)";
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE))
                                .notify(NOTIF_ID, buildNotification(s));
                    }
                });
            }
            if (pct >= cfg.frac && now - lastAlert >= cfg.cooldownMs) {
                lastAlert = now;
                if (cfg.haptic) vibrate();
                if (cfg.flash) main.post(new Runnable() {
                    @Override
                    public void run() {
                        showFlash();
                    }
                });
            }
        } finally {
            img.close();
        }
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private void vibrate() {
        Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if (v != null && v.hasVibrator()) {
            v.vibrate(VibrationEffect.createWaveform(new long[]{0, 90, 70, 90}, -1));
        }
    }

    private void showFlash() {
        if (flashView != null) return;
        WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        EdgeFlashView v = new EdgeFlashView(this, 0xFFFF1744);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                // NOT_TOUCHABLE: touches pass straight through to the game. Display-only overlay.
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        try {
            wm.addView(v, lp);
        } catch (Exception e) {
            return;
        }
        flashView = v;
        v.flash(3, new Runnable() {
            @Override
            public void run() {
                removeFlash();
            }
        });
    }

    private void removeFlash() {
        if (flashView == null) return;
        EdgeFlashView v = flashView;
        flashView = null;
        try {
            ((WindowManager) getSystemService(Context.WINDOW_SERVICE)).removeView(v);
        } catch (Exception ignored) {
        }
    }

    private Notification buildNotification(String text) {
        PendingIntent stop = PendingIntent.getService(this, 0,
                new Intent(this, LowHealthService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("Low-health alert is watching")
                .setContentText(text)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "Stop", stop).build())
                .build();
    }

    private void startAsForeground(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Low-health alert", NotificationManager.IMPORTANCE_LOW));
        Notification n = buildNotification(text);
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        if (worker != null) worker.removeCallbacksAndMessages(null);
        if (thread != null) thread.quitSafely();
        if (display != null) display.release();
        if (reader != null) reader.close();
        if (projection != null) projection.stop();
        main.post(new Runnable() {
            @Override
            public void run() {
                removeFlash();
            }
        });
        super.onDestroy();
    }
}
