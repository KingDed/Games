package com.antonyhern16.lowhealth;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.os.Vibrator;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Game Hub: working, offline, fair-play tools. Nothing here automates gameplay.
 * Tabs: Sessions, Notes, Reminders, Devices, Backup, Privacy, Checks.
 */
public class GameHubActivity extends Activity {
    private static final int BG = 0xFF0B0B0E, CARD = 0xFF17171C, ACCENT = 0xFFFF2D4B, DIM = 0xFF9A9AA6;
    private static final String[] TABS = {"Booster", "Dashboard", "Profiles", "Train", "Matches", "Sessions", "Energy", "Notes", "Reminders", "Devices", "Backup", "Privacy", "Checks"};
    private static final int REQ_EXPORT = 11, REQ_IMPORT = 12;
    private static final String[] GAMES = {"CODM", "PUBG Mobile", "Other"};

    private SharedPreferences sp;
    private LinearLayout body;
    private int tab = 0;
    private String game = "CODM";
    private String noteKey = "CODM";
    private final SimpleDateFormat fmt = new SimpleDateFormat("MMM d, HH:mm", Locale.getDefault());

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("gamehub", MODE_PRIVATE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(14), dp(34), dp(14), 0);
        root.addView(text("GAME HUB", 24, Color.WHITE, true));
        root.addView(text("Your own sessions, notes, reminders and settings. Nothing here plays the game for you.", 12, DIM, false));
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        final LinearLayout bar = new LinearLayout(this);
        hs.addView(bar);
        root.addView(hs);
        ScrollView sv = new ScrollView(this);
        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(0, dp(8), 0, dp(24));
        sv.addView(body);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            Button t = pill(TABS[i], i == 0);
            t.setOnClickListener(v -> {
                tab = idx;
                for (int k = 0; k < bar.getChildCount(); k++) style((Button) bar.getChildAt(k), k == idx);
                render();
            });
            bar.addView(t);
        }
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (body != null) {
            if (tab == 0) render();   // permissions may have changed in Settings
            PermGate.onOpen(this);
        }
        if (body != null && (tab == 3 || tab == 4 || tab == 2)) render();   // refresh after returning from a drill
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveNoteIfAny();
    }

    private EditText noteBox;

    private void saveNoteIfAny() {
        if (noteBox != null) sp.edit().putString("note_" + noteKey, noteBox.getText().toString()).apply();
    }

    private void render() {
        saveNoteIfAny();
        noteBox = null;
        body.removeAllViews();
        switch (tab) {
            case 0: Boost.panel(this, body, () -> render()); break;
            case 1: Sections.dashboard(this, body, () -> render()); break;
            case 2: Sections.profiles(this, body, () -> render()); break;
            case 3: Sections.train(this, body, () -> render()); break;
            case 4: Sections.matches(this, body, () -> render()); break;
            case 5: sessions(); break;
            case 6: energy(); break;
            case 7: notes(); break;
            case 8: reminders(); break;
            case 9: devices(); break;
            case 10: backup(); break;
            case 11: privacy(); break;
            default: checks();
        }
    }

    // ------------------------------------------------------------ Sessions
    private void sessions() {
        LinearLayout c = card();
        c.addView(text("GAME", 12, ACCENT, true));
        LinearLayout row = new LinearLayout(this);
        for (final String g : GAMES) {
            Button p = pill(g, g.equals(game));
            p.setOnClickListener(v -> {
                game = g;
                render();
            });
            row.addView(p);
        }
        c.addView(row);
        long start = sp.getLong("sess_start", 0);
        if (start > 0) {
            c.addView(text("Running: " + sp.getString("sess_game", "?") + " since " + fmt.format(new Date(start)) + " (" + dur(System.currentTimeMillis() - start) + ")", 14, Color.WHITE, false));
            c.addView(button("Stop session and add a note", true, v -> stopSession()));
        } else {
            c.addView(button("Start session", true, v -> {
                sp.edit().putLong("sess_start", System.currentTimeMillis()).putString("sess_game", game).apply();
                render();
            }));
        }
        LinearLayout h = card();
        h.addView(text("HISTORY", 12, ACCENT, true));
        JSONArray arr = arr("sessions");
        long total = 0;
        int n = Math.min(arr.length(), 40);
        for (int i = arr.length() - 1; i >= arr.length() - n; i--) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            total += o.optLong("dur");
            String line = fmt.format(new Date(o.optLong("start"))) + "  ·  " + o.optString("game") + "  ·  " + dur(o.optLong("dur"));
            h.addView(text(line, 14, Color.WHITE, false));
            String note = o.optString("note");
            if (note.length() > 0) h.addView(text("   " + note, 12, DIM, false));
        }
        if (arr.length() == 0) h.addView(text("No sessions yet.", 13, DIM, false));
        else h.addView(text("Total in list: " + dur(total) + " over " + n + " sessions", 12, DIM, false));
        h.addView(button("Clear history", false, v -> confirm("Delete all session history?", () -> {
            sp.edit().remove("sessions").apply();
            render();
        })));
    }

    private void stopSession() {
        final long start = sp.getLong("sess_start", 0);
        final String g = sp.getString("sess_game", game);
        final EditText e = new EditText(this);
        e.setHint("Match note (optional)");
        new AlertDialog.Builder(this).setTitle("Session finished").setView(e)
                .setPositiveButton("Save", (d, w) -> {
                    try {
                        JSONArray a = arr("sessions");
                        JSONObject o = new JSONObject();
                        o.put("game", g).put("start", start).put("dur", System.currentTimeMillis() - start).put("note", e.getText().toString());
                        a.put(o);
                        sp.edit().putString("sessions", a.toString()).remove("sess_start").apply();
                    } catch (Exception ex) {
                        toast("Could not save");
                    }
                    render();
                }).setNegativeButton("Discard", (d, w) -> {
                    sp.edit().remove("sess_start").apply();
                    render();
                }).show();
    }

    // ------------------------------------------------------------ Energy
    private void energy() {
        LinearLayout c = card();
        c.addView(text("BATTERY AND HEAT LOG", 12, ACCENT, true));
        c.addView(text("Take a reading before, during and after a match to see how much battery and heat a session costs. Readings are only what Android reports.", 13, Color.WHITE, false));
        c.addView(button("Take a reading now", true, v -> {
            Intent b = registerReceiver(null, new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (b == null) { toast("Battery info unavailable"); return; }
            try {
                int lvl = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) * 100 / Math.max(1, b.getIntExtra(BatteryManager.EXTRA_SCALE, 100));
                int t = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
                int st = b.getIntExtra(BatteryManager.EXTRA_STATUS, 0);
                int th = -1;
                if (Build.VERSION.SDK_INT >= 29) th = ((PowerManager) getSystemService(Context.POWER_SERVICE)).getCurrentThermalStatus();
                JSONArray a = arr("energy");
                a.put(new JSONObject().put("t", System.currentTimeMillis()).put("lvl", lvl).put("temp", t / 10.0).put("chg", st == BatteryManager.BATTERY_STATUS_CHARGING).put("th", th));
                sp.edit().putString("energy", a.toString()).apply();
            } catch (Exception e) { toast("Could not read"); }
            render();
        }));
        LinearLayout h = card();
        h.addView(text("READINGS", 12, ACCENT, true));
        JSONArray a = arr("energy");
        JSONObject first = null, last = null;
        for (int i = a.length() - 1; i >= 0 && i >= a.length() - 40; i--) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            if (last == null) last = o;
            first = o;
            h.addView(text(fmt.format(new Date(o.optLong("t"))) + "  " + o.optInt("lvl") + "%  " + o.optDouble("temp") + "\u00b0C" + (o.optBoolean("chg") ? "  charging" : "") + (o.optInt("th", -1) > 0 ? "  thermal " + o.optInt("th") : ""), 13, Color.WHITE, false));
        }
        if (a.length() == 0) h.addView(text("No readings yet.", 13, DIM, false));
        else if (first != null && last != null && first != last) {
            double mins = Math.max(1, (last.optLong("t") - first.optLong("t")) / 60000.0);
            int drop = first.optInt("lvl") - last.optInt("lvl");
            h.addView(text("Between oldest and newest shown: " + drop + "% in " + Math.round(mins) + " min (" + String.format(Locale.US, "%.2f", drop / mins * 60) + "% per hour), heat change " + String.format(Locale.US, "%+.1f", last.optDouble("temp") - first.optDouble("temp")) + "\u00b0C", 12, DIM, false));
        }
        h.addView(button("Clear readings", false, v -> { sp.edit().remove("energy").apply(); render(); }));
    }

    // ------------------------------------------------------------ Notes
    private void notes() {
        LinearLayout c = card();
        c.addView(text("NOTEBOOK", 12, ACCENT, true));
        LinearLayout row = new LinearLayout(this);
        for (final String g : new String[]{"CODM", "PUBG", "Trigger layout"}) {
            Button p = pill(g, g.equals(noteKey));
            p.setOnClickListener(v -> {
                noteKey = g;
                render();
            });
            row.addView(p);
        }
        c.addView(row);
        noteBox = new EditText(this);
        noteBox.setMinLines(10);
        noteBox.setGravity(android.view.Gravity.TOP);
        noteBox.setTextColor(Color.WHITE);
        noteBox.setHint("Loadouts, sensitivity values, map callouts, trigger layout description...");
        noteBox.setHintTextColor(DIM);
        noteBox.setText(sp.getString("note_" + noteKey, ""));
        c.addView(noteBox);
        c.addView(text("Saved automatically when you leave this screen.", 12, DIM, false));
    }

    // ------------------------------------------------------------ Reminders
    private void reminders() {
        LinearLayout c = card();
        c.addView(text("SET A REMINDER", 12, ACCENT, true));
        c.addView(text("Break", 13, Color.WHITE, true));
        c.addView(remRow("Break", "Time to rest your thumbs and eyes.", 1, 30, 45, 60));
        c.addView(text("Charging check", 13, Color.WHITE, true));
        c.addView(remRow("Charging", "Check the battery and charger before the next match.", 2, 30, 60, 90));
        c.addView(text("Session end", 13, Color.WHITE, true));
        c.addView(remRow("Session end", "Your planned session time is up.", 3, 60, 90, 120));
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            c.addView(button("Allow notifications (needed to show reminders)", false, v -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1)));
        }
        LinearLayout p = card();
        p.addView(text("PENDING", 12, ACCENT, true));
        boolean any = false;
        for (int id = 1; id <= 3; id++) {
            String r = sp.getString("rem_" + id, null);
            if (r != null) {
                any = true;
                p.addView(text(r, 14, Color.WHITE, false));
            }
        }
        if (!any) p.addView(text("Nothing scheduled.", 13, DIM, false));
        p.addView(button("Cancel all reminders", false, v -> {
            for (int id = 1; id <= 3; id++) cancelReminder(id);
            render();
        }));
    }

    private LinearLayout remRow(final String title, final String text, final int id, int... mins) {
        LinearLayout r = new LinearLayout(this);
        for (final int m : mins) {
            Button b = pill("in " + m + " min", false);
            b.setOnClickListener(v -> {
                setReminder(id, title, text, m);
                render();
            });
            r.addView(b);
        }
        return r;
    }

    private PendingIntent remIntent(int id, String title, String text) {
        Intent i = new Intent(this, ReminderReceiver.class).putExtra("id", id).putExtra("title", title).putExtra("text", text);
        return PendingIntent.getBroadcast(this, id, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private void setReminder(int id, String title, String text, int minutes) {
        long due = System.currentTimeMillis() + minutes * 60000L;
        AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, due, remIntent(id, title, text));
        sp.edit().putString("rem_" + id, title + " at " + new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(due))).apply();
        toast(title + " reminder set for " + minutes + " min");
    }

    private void cancelReminder(int id) {
        AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        am.cancel(remIntent(id, "", ""));
        sp.edit().remove("rem_" + id).apply();
    }

    // ------------------------------------------------------------ Devices
    private void devices() {
        final LinearLayout c = card();
        c.addView(text("YOUR PERIPHERALS", 12, ACCENT, true));
        JSONArray a = arr("devices");
        for (int i = 0; i < a.length(); i++) {
            final int idx = i;
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            TextView t = text(o.optString("type") + "  ·  " + o.optString("name") + "   (tap to remove)", 14, Color.WHITE, false);
            t.setOnClickListener(v -> confirm("Remove this device?", () -> {
                JSONArray cur = arr("devices");
                JSONArray n = new JSONArray();
                for (int k = 0; k < cur.length(); k++) if (k != idx) n.put(cur.opt(k));
                sp.edit().putString("devices", n.toString()).apply();
                render();
            }));
            c.addView(t);
        }
        if (a.length() == 0) c.addView(text("No devices saved.", 13, DIM, false));
        final EditText name = new EditText(this);
        name.setHint("Device name (e.g. Xbox controller)");
        name.setHintTextColor(DIM);
        name.setTextColor(Color.WHITE);
        c.addView(name);
        LinearLayout row = new LinearLayout(this);
        for (final String type : new String[]{"Controller", "Cooler", "Audio"}) {
            Button b = pill("Add " + type, false);
            b.setOnClickListener(v -> {
                String s = name.getText().toString().trim();
                if (s.length() == 0) {
                    toast("Type a name first");
                    return;
                }
                try {
                    JSONArray cur = arr("devices");
                    cur.put(new JSONObject().put("type", type).put("name", s));
                    sp.edit().putString("devices", cur.toString()).apply();
                } catch (Exception ignored) {
                }
                render();
            });
            row.addView(b);
        }
        c.addView(row);
        c.addView(button("Open Bluetooth settings", false, v -> open(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS))));
    }

    // ------------------------------------------------------------ Backup
    private void backup() {
        LinearLayout c = card();
        c.addView(text("BACKUP AND RESTORE", 12, ACCENT, true));
        c.addView(text("Saves your Game Hub data and low-health alert settings into one file you choose, and restores them later.", 13, Color.WHITE, false));
        c.addView(button("Export settings file", true, v -> {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json")
                    .putExtra(Intent.EXTRA_TITLE, "gamespace_backup.json");
            startActivityForResult(i, REQ_EXPORT);
        }));
        c.addView(button("Restore from file", false, v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
            startActivityForResult(i, REQ_IMPORT);
        }));
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        try {
            if (req == REQ_EXPORT) {
                saveNoteIfAny();
                JSONObject all = new JSONObject();
                for (String f : new String[]{"gamehub", "lowhealth_cfg"}) {
                    JSONObject o = new JSONObject();
                    for (Map.Entry<String, ?> e : getSharedPreferences(f, MODE_PRIVATE).getAll().entrySet()) {
                        Object v = e.getValue();
                        String t = v instanceof Boolean ? "b" : v instanceof Integer ? "i" : v instanceof Long ? "l" : v instanceof Float ? "f" : "s";
                        o.put(e.getKey(), new JSONObject().put("t", t).put("v", v instanceof Float ? (double) (Float) v : v));
                    }
                    all.put(f, o);
                }
                OutputStream os = getContentResolver().openOutputStream(u);
                os.write(all.toString(1).getBytes("UTF-8"));
                os.close();
                toast("Backup saved");
            } else if (req == REQ_IMPORT) {
                InputStream is = getContentResolver().openInputStream(u);
                byte[] buf = new byte[is.available() > 0 ? is.available() : 65536];
                int n = is.read(buf);
                is.close();
                JSONObject all = new JSONObject(new String(buf, 0, Math.max(n, 0), "UTF-8"));
                Iterator<String> files = all.keys();
                while (files.hasNext()) {
                    String f = files.next();
                    if (!f.equals("gamehub") && !f.equals("lowhealth_cfg")) continue;
                    JSONObject o = all.getJSONObject(f);
                    SharedPreferences.Editor ed = getSharedPreferences(f, MODE_PRIVATE).edit();
                    Iterator<String> keys = o.keys();
                    while (keys.hasNext()) {
                        String k = keys.next();
                        JSONObject e = o.getJSONObject(k);
                        switch (e.getString("t")) {
                            case "b": ed.putBoolean(k, e.getBoolean("v")); break;
                            case "i": ed.putInt(k, e.getInt("v")); break;
                            case "l": ed.putLong(k, e.getLong("v")); break;
                            case "f": ed.putFloat(k, (float) e.getDouble("v")); break;
                            default: ed.putString(k, e.getString("v"));
                        }
                    }
                    ed.apply();
                }
                toast("Settings restored");
                render();
            }
        } catch (Exception ex) {
            toast("That did not work: " + ex.getClass().getSimpleName());
        }
    }

    // ------------------------------------------------------------ Privacy
    private void privacy() {
        LinearLayout c = card();
        c.addView(text("PERMISSIONS THIS APP ASKS FOR", 12, ACCENT, true));
        try {
            PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_PERMISSIONS);
            if (pi.requestedPermissions != null) {
                for (int i = 0; i < pi.requestedPermissions.length; i++) {
                    String p = pi.requestedPermissions[i];
                    boolean granted = (pi.requestedPermissionsFlags[i] & PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0;
                    String shortName = p.substring(p.lastIndexOf('.') + 1);
                    c.addView(text((granted ? "✓ " : "✗ ") + shortName, 13, granted ? 0xFF35D07F : DIM, false));
                }
            }
        } catch (Exception e) {
            c.addView(text("Could not read permissions.", 13, DIM, false));
        }
        c.addView(text("✓ = currently granted. Special access (overlay, notification policy, system settings) is switched off in Android settings.", 12, DIM, false));
        c.addView(button("Open this app's permission settings", true, v ->
                open(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())))));
        c.addView(button("Open overlay access", false, v ->
                open(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())))));
        c.addView(button("Open Do Not Disturb access", false, v -> open(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))));
    }

    // ------------------------------------------------------------ Checks
    private void checks() {
        LinearLayout c = card();
        c.addView(text("WHAT THIS PHONE LETS THE APP DO", 12, ACCENT, true));
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        Vibrator vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        check(c, "Show over other apps (overlay)", Settings.canDrawOverlays(this), "needs your permission");
        check(c, "Modify system settings", Settings.System.canWrite(this), "needs your permission");
        check(c, "Do Not Disturb control", nm != null && nm.isNotificationPolicyAccessGranted(), "needs your permission");
        check(c, "Vibration motor", vib != null && vib.hasVibrator(), "not found");
        check(c, "Thermal status reading", Build.VERSION.SDK_INT >= 29, "needs Android 10+");
        check(c, "Screen capture", true, "");
        c.addView(text("   asks you every time (Android rule)", 11, DIM, false));
        Display d = getWindowManager().getDefaultDisplay();
        StringBuilder hz = new StringBuilder();
        List<Integer> seen = new ArrayList<>();
        for (Display.Mode m : d.getSupportedModes()) {
            int r = Math.round(m.getRefreshRate());
            if (!seen.contains(r)) {
                seen.add(r);
                hz.append(hz.length() > 0 ? ", " : "").append(r);
            }
        }
        c.addView(text("Display refresh rates: " + hz + " Hz", 13, Color.WHITE, false));
        try {
            android.content.Intent b = registerReceiver(null, new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            int t = b == null ? Integer.MIN_VALUE : b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
            c.addView(text(t == Integer.MIN_VALUE ? "Battery temperature: unavailable" : "Battery temperature: " + (t / 10f) + " °C", 13, Color.WHITE, false));
        } catch (Exception ignored) {
        }
        if (Build.VERSION.SDK_INT >= 29) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            c.addView(text("Thermal status code: " + pm.getCurrentThermalStatus() + " (0 = normal)", 13, Color.WHITE, false));
        }
        c.addView(text("Not possible for a normal app on any phone: changing the CPU/GPU, fan, proprietary performance modes, or shoulder-trigger hardware.", 12, DIM, false));
        c.addView(button("Open Low-health alert", false, v -> open(new Intent(this, LowHealthActivity.class))));
    }

    private void check(LinearLayout c, String label, boolean ok, String why) {
        c.addView(text((ok ? "✓ " : "✗ ") + label + (ok || why.length() == 0 ? "" : "  (" + why + ")"), 14, ok ? 0xFF35D07F : 0xFFFFB020, false));
    }

    // ------------------------------------------------------------ helpers
    private JSONArray arr(String key) {
        try {
            return new JSONArray(sp.getString(key, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private static String dur(long ms) {
        long m = ms / 60000, h = m / 60;
        return h > 0 ? h + "h " + (m % 60) + "m" : Math.max(m, 0) + "m";
    }

    private void confirm(String msg, final Runnable yes) {
        new AlertDialog.Builder(this).setMessage(msg).setPositiveButton("Yes", (d, w) -> yes.run()).setNegativeButton("No", null).show();
    }

    private void open(Intent i) {
        try {
            startActivity(i);
        } catch (Exception e) {
            toast("Not available on this phone");
        }
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(14), dp(14), dp(14), dp(14));
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(16));
        l.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(10);
        body.addView(l, lp);
        return l;
    }

    private Button pill(String label, boolean on) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        style(b, on);
        return b;
    }

    private void style(Button b, boolean on) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(on ? ACCENT : 0xFF22222A);
        g.setCornerRadius(dp(18));
        b.setBackground(g);
        b.setTextColor(Color.WHITE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40));
        lp.rightMargin = dp(6);
        lp.topMargin = dp(8);
        b.setLayoutParams(lp);
    }

    private Button button(String label, boolean primary, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        GradientDrawable g = new GradientDrawable();
        g.setColor(primary ? ACCENT : 0xFF22222A);
        g.setCornerRadius(dp(14));
        b.setBackground(g);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(48));
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }
}
