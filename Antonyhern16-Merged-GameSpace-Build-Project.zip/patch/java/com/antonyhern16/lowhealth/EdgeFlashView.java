package com.antonyhern16.lowhealth;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.view.View;

/** Pulsing translucent border on the screen edges. Draw-only: it never handles touch. */
final class EdgeFlashView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int color;
    private final float thickness;
    private float pulse = 0f;

    EdgeFlashView(Context c, int color) {
        super(c);
        this.color = color;
        this.thickness = c.getResources().getDisplayMetrics().density * 28f;
        setClickable(false);
        setFocusable(false);
    }

    void flash(int times, final Runnable done) {
        ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
        a.setDuration(220);
        a.setRepeatCount(times * 2 - 1);
        a.setRepeatMode(ValueAnimator.REVERSE);
        a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator va) {
                pulse = (Float) va.getAnimatedValue();
                invalidate();
            }
        });
        a.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                done.run();
            }
        });
        a.start();
    }

    private int alpha(int c, int a) {
        a = Math.max(0, Math.min(255, a));
        return (c & 0x00FFFFFF) | (a << 24);
    }

    private void edge(Canvas cv, float x0, float y0, float x1, float y1, float l, float t, float r, float b) {
        paint.setShader(new LinearGradient(x0, y0, x1, y1,
                alpha(color, (int) (150 * pulse)), alpha(color, 0), Shader.TileMode.CLAMP));
        cv.drawRect(l, t, r, b, paint);
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        edge(cv, 0, 0, 0, thickness, 0, 0, w, thickness);
        edge(cv, 0, h, 0, h - thickness, 0, h - thickness, w, h);
        edge(cv, 0, 0, thickness, 0, 0, 0, thickness, h);
        edge(cv, w, 0, w - thickness, 0, w - thickness, 0, w, h);
    }
}
