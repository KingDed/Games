package com.antonyhern16.lowhealth;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.Choreographer;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;

import java.util.Locale;
import java.util.Random;

/**
 * Antonyhern16's own aim-training arena. Everything is simulated inside this view: you aim with your
 * finger or the gyroscope and press FIRE yourself. Every stat is measured from what you actually do.
 */
final class TrainerView extends View implements Choreographer.FrameCallback, SensorEventListener {
    static final String[] MODES = {"Precision", "Tracking", "Flick", "Reaction", "Recoil", "Gyro", "Crosshair"};
    static final String[] DIFFS = {"Beginner", "Normal", "Advanced", "Extreme"};
    static final float[] RADIUS_DP = {36, 26, 18, 11};
    static final float[] SPEED_DP = {120, 220, 340, 520};
    static final float[] LIFE_S = {2.5f, 1.6f, 1.0f, 0.65f};
    static final float[] RECOIL_MUL = {0.6f, 1f, 1.4f, 1.9f};
    private static final float ROUND_S = 30f;
    private static final int MAG = 30;

    static final class Params {
        String mode = "Precision";
        int diff = 1;
        float touchSens = 1.2f;     // multiplier on finger movement
        float gyroSens = 200f;      // profile gyro value
        float vmult = 1f;
        float speedMul = 1f;
        int dir = 2;                // 0 horizontal, 1 vertical, 2 free
        float recV = 7f, recH = 2f; // recoil kick per shot in dp
        boolean gyroAssist = false, invX = false, invY = false;
        String label = "";          // shown in HUD: scope + profile
    }

    static final class Result {
        String mode, label;
        int diff, shots, hits, expired, score;
        float accuracy, avgDistDp, reactMs, recoilScore, trackScore, seconds;
        boolean relevantReact, relevantRecoil, relevantTrack;
    }

    interface Callback { void finished(Result r); void exit(); }

    private final Params prm;
    private final Callback cb;
    private final Context ctx;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rnd = new Random();
    private final float d;
    private final boolean gyroOnly, gyroUsed;
    private SensorManager sm;
    private boolean hasGyro = true;

    private float W, H, cx, cy;
    private long last = 0;
    private float countdown = 3f, elapsed = 0f;
    private boolean running = false, over = false, attached = false;

    // target
    private boolean tOn = false;
    private float tx, ty, tr, tvx, tvy, tBorn, nextTurn, waitLeft = 1f, endDelay = 0f;
    private int spawned = 0;

    // metrics
    private int shots, hits, expired, frames, trackOn, trackFrames, reactN, recShot;
    private float distSum, shotDistSum, reactSum, recAcc;

    // input
    private boolean fireDown = false, fireEdge = false;
    private int firePtr = -1, aimPtr = -1;
    private float lx, ly, gRateX, gRateY;

    // own fps + hud
    private int fpsN = 0;
    private float fpsT = 0, fps = 0, hudT = 0;
    private String hud = "";
    private String flash = "";
    private float flashT = 0;

    TrainerView(Context c, Params p, Callback cb) {
        super(c);
        this.ctx = c;
        this.prm = p;
        this.cb = cb;
        this.d = c.getResources().getDisplayMetrics().density;
        this.gyroOnly = p.mode.equals("Gyro");
        this.gyroUsed = gyroOnly || p.gyroAssist;
        this.tr = RADIUS_DP[p.diff] * d;
        setKeepScreenOn(true);
    }

    boolean needsGyroButMissing() {
        return gyroUsed && ((SensorManager) ctx.getSystemService(Context.SENSOR_SERVICE)).getDefaultSensor(Sensor.TYPE_GYROSCOPE) == null;
    }

    void stop() {
        over = true;
        Choreographer.getInstance().removeFrameCallback(this);
        if (sm != null) sm.unregisterListener(this);
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        attached = true;
        if (gyroUsed) {
            sm = (SensorManager) ctx.getSystemService(Context.SENSOR_SERVICE);
            Sensor g = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
            if (g == null) hasGyro = false; else sm.registerListener(this, g, SensorManager.SENSOR_DELAY_GAME);
        }
        Choreographer.getInstance().postFrameCallback(this);
    }

    @Override protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        attached = false;
        stop();
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        W = w; H = h;
        cx = W / 2f;
        cy = prm.mode.equals("Recoil") ? H * 0.4f : H * 0.5f;
    }

    // ------------------------------------------------------------ gyro
    @Override public void onSensorChanged(SensorEvent e) {
        int rot = ((WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRotation();
        float rx = e.values[0], ry = e.values[1];
        if (rot == Surface.ROTATION_270) { rx = -rx; ry = -ry; }
        gRateX = prm.invX ? -rx : rx;    // turning the phone left/right
        gRateY = prm.invY ? -ry : ry;    // tilting the phone up/down
    }

    @Override public void onAccuracyChanged(Sensor s, int a) { }

    // ------------------------------------------------------------ loop
    @Override public void doFrame(long nanos) {
        if (over) return;
        float dt = last == 0 ? 0f : Math.min(0.05f, (nanos - last) / 1e9f);
        last = nanos;
        fpsN++; fpsT += dt;
        if (fpsT >= 0.5f) { fps = fpsN / fpsT; fpsN = 0; fpsT = 0; }
        update(dt);
        invalidate();
        if (!over) Choreographer.getInstance().postFrameCallback(this);
    }

    private void startRun() {
        running = true;
        elapsed = 0; shots = hits = expired = frames = trackOn = trackFrames = reactN = recShot = 0;
        distSum = shotDistSum = reactSum = recAcc = 0;
        fireEdge = false; spawned = 0; tOn = false;
        waitLeft = 0.8f + rnd.nextFloat() * 1.7f;
        if (prm.mode.equals("Recoil")) {
            tx = W / 2f; ty = H * 0.4f; tr = Math.max(tr, 22 * d); tOn = true;
            cx = tx; cy = ty;
        } else if (prm.mode.equals("Tracking") || prm.mode.equals("Crosshair")) {
            spawnMover();
        }
    }

    private void update(float dt) {
        if (countdown > 0) {
            countdown -= dt;
            if (countdown <= 0) startRun();
            return;
        }
        if (!running) return;
        elapsed += dt;
        if (gyroUsed && hasGyro) {
            float k = 350f * d * prm.gyroSens / 200f;
            cx += gRateX * dt * k;
            cy += gRateY * dt * k * prm.vmult;
        }
        cx = Math.max(0, Math.min(W, cx));
        cy = Math.max(0, Math.min(H, cy));

        String m = prm.mode;
        if (m.equals("Precision") || m.equals("Gyro")) {
            if (!tOn) spawnStatic(0.8f);
            if (elapsed >= ROUND_S) finish();
        } else if (m.equals("Flick")) {
            if (!tOn) spawnStatic(1f);
            else if (elapsed - tBorn > LIFE_S[prm.diff]) { expired++; tOn = false; }
            if (elapsed >= ROUND_S) finish();
        } else if (m.equals("Reaction")) {
            if (!tOn) {
                waitLeft -= dt;
                if (waitLeft <= 0) { spawnStatic(1f); spawned++; }
            }
            if (reactN >= 10) finish();
        } else if (m.equals("Tracking") || m.equals("Crosshair")) {
            moveTarget(dt);
            if (elapsed >= ROUND_S) finish();
        } else if (m.equals("Recoil")) {
            if (recShot >= MAG) {
                endDelay += dt;
                if (endDelay > 0.5f) finish();
            } else if (fireDown) {
                recAcc += dt;
                while (recAcc >= 0.1f && recShot < MAG) { recAcc -= 0.1f; shoot(); kick(); }
            } else recAcc = 0.1f;
        }
        if (!m.equals("Recoil") && fireEdge) { fireEdge = false; shoot(); }

        if (tOn && running) {
            float dist = (float) Math.hypot(cx - tx, cy - ty);
            distSum += dist; frames++;
            if (m.equals("Tracking") || m.equals("Crosshair")) {
                trackFrames++;
                boolean on = m.equals("Crosshair") ? Math.abs(cy - ty) <= tr : dist <= tr;
                if (on) trackOn++;
            }
        }
        hudT -= dt;
        if (hudT <= 0) { hudT = 0.5f; buildHud(); }
        if (flashT > 0) flashT -= dt;
    }

    private void spawnStatic(float sizeMul) {
        float r = tr * sizeMul;
        float x, y;
        int guard = 0;
        do {
            x = r + rnd.nextFloat() * (W - 2 * r);
            y = H * 0.18f + r + rnd.nextFloat() * (H * 0.62f - 2 * r);
            guard++;
        } while (guard < 20 && Math.hypot(x - cx, y - cy) < W * 0.2f);
        tx = x; ty = y; tOn = true; tBorn = elapsed;
        curR = r;
    }

    private float curR = 0;

    private void spawnMover() {
        float sp = SPEED_DP[prm.diff] * d * prm.speedMul;
        tx = W / 2f; ty = prm.mode.equals("Crosshair") ? H * 0.4f : H * 0.45f;
        tOn = true; tBorn = elapsed; curR = tr;
        double ang = prm.dir == 1 ? Math.PI / 2 : prm.dir == 0 ? 0 : rnd.nextDouble() * Math.PI * 2;
        tvx = (float) Math.cos(ang) * sp; tvy = (float) Math.sin(ang) * sp;
        if (prm.mode.equals("Crosshair")) tvy = 0;
        nextTurn = elapsed + 0.8f + rnd.nextFloat() * 0.9f;
    }

    private void moveTarget(float dt) {
        float sp = SPEED_DP[prm.diff] * d * prm.speedMul;
        if (elapsed >= nextTurn) {
            nextTurn = elapsed + 0.7f + rnd.nextFloat() * 1.0f;
            if (prm.dir == 0 || prm.mode.equals("Crosshair")) tvx = (rnd.nextBoolean() ? 1 : -1) * sp;
            else if (prm.dir == 1) tvy = (rnd.nextBoolean() ? 1 : -1) * sp;
            else {
                double a = rnd.nextDouble() * Math.PI * 2;
                tvx = (float) Math.cos(a) * sp; tvy = (float) Math.sin(a) * sp;
            }
        }
        tx += tvx * dt; ty += tvy * dt;
        float top = H * 0.16f + curR, bot = H * 0.8f - curR;
        if (tx < curR) { tx = curR; tvx = Math.abs(tvx); }
        if (tx > W - curR) { tx = W - curR; tvx = -Math.abs(tvx); }
        if (ty < top) { ty = top; tvy = Math.abs(tvy); }
        if (ty > bot) { ty = bot; tvy = -Math.abs(tvy); }
    }

    private float radiusNow() { return prm.mode.equals("Recoil") ? tr : (curR > 0 ? curR : tr); }

    private void shoot() {
        shots++;
        if (!tOn) return;
        float dist = (float) Math.hypot(cx - tx, cy - ty);
        shotDistSum += dist;
        if (prm.mode.equals("Recoil")) recShot++;
        float r = radiusNow();
        boolean hit = prm.mode.equals("Crosshair") ? dist <= r : dist <= r;
        if (hit) {
            hits++;
            flash = "HIT"; flashT = 0.25f;
            String m = prm.mode;
            if (m.equals("Precision") || m.equals("Gyro") || m.equals("Flick") || m.equals("Reaction")) {
                reactSum += (elapsed - tBorn) * 1000f; reactN++;
                tOn = false;
                waitLeft = 0.8f + rnd.nextFloat() * 1.7f;
            }
        } else { flash = "MISS"; flashT = 0.2f; }
    }

    /** Simulated weapon kick: the crosshair is pushed away and YOU must pull it back. */
    private void kick() {
        int i = recShot - 1;
        float mul = RECOIL_MUL[prm.diff] * d;
        float vy = prm.recV * mul * (i < 20 ? 1f : 0.4f) * (1f + 0.12f * (float) Math.sin(i * 0.35));
        float hx = prm.recH * mul * (float) Math.sin(i * 0.55);
        cy -= vy; cx += hx;
        cx = Math.max(0, Math.min(W, cx));
        cy = Math.max(0, Math.min(H, cy));
    }

    private void finish() {
        if (over) return;
        over = true;
        running = false;
        Result r = new Result();
        r.mode = prm.mode; r.diff = prm.diff; r.label = prm.label;
        r.shots = shots; r.hits = hits; r.expired = expired; r.seconds = elapsed;
        r.accuracy = shots > 0 ? 100f * hits / shots : 0f;
        r.avgDistDp = frames > 0 ? distSum / frames / d : 0f;
        r.relevantReact = reactN > 0;
        r.reactMs = reactN > 0 ? reactSum / reactN : 0f;
        r.relevantTrack = prm.mode.equals("Tracking") || prm.mode.equals("Crosshair");
        r.trackScore = trackFrames > 0 ? 100f * trackOn / trackFrames : 0f;
        r.relevantRecoil = prm.mode.equals("Recoil");
        r.recoilScore = r.relevantRecoil && shots > 0
                ? Math.max(0f, Math.min(100f, 100f * (1f - (shotDistSum / shots) / (tr * 5f)))) : 0f;
        float mult = 0.8f + 0.4f * prm.diff;
        float accF = shots > 0 ? 0.5f + r.accuracy / 200f : 1f;
        r.score = Math.round((hits * 100f + r.trackScore * 5f + r.recoilScore * 5f) * mult * accF);
        stop();
        cb.finished(r);
    }

    private void buildHud() {
        int sec = (int) elapsed;
        float acc = shots > 0 ? 100f * hits / shots : 0f;
        String react = reactN > 0 ? String.format(Locale.US, "%.0f ms", reactSum / reactN) : "--";
        long ping = PerfInfo.pingMs;
        double ghz = PerfInfo.cpuGhz();
        hud = String.format(Locale.US, "Train FPS %.0f  |  %d Hz  |  Ping %s  |  RAM %d%%  |  CPU %s  |  Bat %d%%  |  %d:%02d  |  Acc %.0f%%  |  React %s",
                fps, PerfInfo.hz(ctx), ping < 0 ? "--" : ping + " ms", Math.round(PerfInfo.ramUsedFrac(ctx) * 100),
                ghz > 0 ? String.format(Locale.US, "%.2fGHz", ghz) : "n/a", PerfInfo.battery(ctx), sec / 60, sec % 60, acc, react);
    }

    // ------------------------------------------------------------ input
    private boolean inFire(float x, float y) {
        return Math.hypot(x - (W - 90 * d), y - (H - 90 * d)) < 70 * d;
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN) {
            int i = e.getActionIndex();
            int id = e.getPointerId(i);
            float x = e.getX(i), y = e.getY(i);
            if (x < 70 * d && y < 70 * d) { stop(); cb.exit(); return true; }
            if (inFire(x, y)) { firePtr = id; fireDown = true; fireEdge = true; }
            else if (aimPtr < 0) { aimPtr = id; lx = x; ly = y; }
        } else if (a == MotionEvent.ACTION_MOVE) {
            for (int i = 0; i < e.getPointerCount(); i++) {
                if (e.getPointerId(i) != aimPtr) continue;
                float x = e.getX(i), y = e.getY(i);
                if (running && !gyroOnly) {
                    float k = prm.touchSens;
                    cx += (x - lx) * k;
                    cy += (y - ly) * k * prm.vmult;
                }
                lx = x; ly = y;
            }
        } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_POINTER_UP || a == MotionEvent.ACTION_CANCEL) {
            int id = e.getPointerId(e.getActionIndex());
            if (id == firePtr) { firePtr = -1; fireDown = false; }
            if (id == aimPtr) aimPtr = -1;
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) { firePtr = -1; aimPtr = -1; fireDown = false; }
        }
        return true;
    }

    // ------------------------------------------------------------ drawing
    @Override protected void onDraw(Canvas c) {
        c.drawColor(0xFF08080B);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1f);
        p.setColor(0x22FF2D4B);
        for (float x = 0; x < W; x += 60 * d) c.drawLine(x, 0, x, H, p);
        for (float y = 0; y < H; y += 60 * d) c.drawLine(0, y, W, y, p);

        String m = prm.mode;
        if (m.equals("Crosshair") && running) {
            p.setColor(0x55FFB020);
            p.setStrokeWidth(2f);
            c.drawLine(0, ty - tr, W, ty - tr, p);
            c.drawLine(0, ty + tr, W, ty + tr, p);
        }
        if (tOn) {
            float r = radiusNow();
            p.setStyle(Paint.Style.FILL);
            p.setColor(0x33FF2D4B);
            c.drawCircle(tx, ty, r * 1.35f, p);
            p.setColor(0xFFFF2D4B);
            c.drawCircle(tx, ty, r, p);
            p.setColor(Color.WHITE);
            c.drawCircle(tx, ty, r * 0.62f, p);
            p.setColor(0xFFFF2D4B);
            c.drawCircle(tx, ty, r * 0.28f, p);
            if (m.equals("Flick")) {
                float left = 1f - (elapsed - tBorn) / LIFE_S[prm.diff];
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4 * d); p.setColor(0xFFFFB020);
                c.drawArc(tx - r * 1.5f, ty - r * 1.5f, tx + r * 1.5f, ty + r * 1.5f, -90, 360f * Math.max(0, left), false, p);
            }
        }
        // crosshair (the training one, drawn only inside this arena)
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.5f * d); p.setColor(0xFF35D07F);
        float g = 7 * d, l = 20 * d;
        c.drawLine(cx - l, cy, cx - g, cy, p); c.drawLine(cx + g, cy, cx + l, cy, p);
        c.drawLine(cx, cy - l, cx, cy - g, p); c.drawLine(cx, cy + g, cx, cy + l, p);

        // fire button
        float fx = W - 90 * d, fy = H - 90 * d;
        p.setStyle(Paint.Style.FILL);
        p.setColor(fireDown ? 0xFFFF2D4B : 0x88B00000);
        c.drawCircle(fx, fy, 62 * d, p);
        p.setStyle(Paint.Style.STROKE); p.setColor(0xFFFF2D4B); p.setStrokeWidth(3 * d);
        c.drawCircle(fx, fy, 62 * d, p);
        p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE); p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(18 * d);
        c.drawText("FIRE", fx, fy + 6 * d, p);

        // exit
        p.setTextSize(22 * d); p.setTextAlign(Paint.Align.LEFT);
        c.drawText("\u2715", 20 * d, 38 * d, p);

        // HUD
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(11 * d); p.setColor(0xFFCCCCD4);
        c.drawText(hud, 58 * d, 22 * d, p);
        p.setColor(0xFFFF6B7F); p.setTextSize(12 * d);
        String info = m.toUpperCase(Locale.US) + " TRAINING  |  " + DIFFS[prm.diff] + "  |  " + prm.label;
        if (m.equals("Recoil")) info += String.format(Locale.US, "  |  Mag %d/%d", Math.min(recShot, MAG), MAG);
        else if (m.equals("Reaction")) info += String.format(Locale.US, "  |  Target %d/10", Math.min(reactN + 1, 10));
        else info += String.format(Locale.US, "  |  %.0fs left", Math.max(0, ROUND_S - elapsed));
        c.drawText(info, 58 * d, 42 * d, p);
        p.setColor(Color.WHITE);
        c.drawText(String.format(Locale.US, "Shots %d   On target %d", shots, hits), 58 * d, 60 * d, p);

        p.setTextAlign(Paint.Align.CENTER);
        if (countdown > 0) {
            p.setTextSize(64 * d); p.setColor(0xFFFF2D4B);
            c.drawText(String.valueOf((int) Math.ceil(countdown)), W / 2, H / 2, p);
            p.setTextSize(13 * d); p.setColor(0xFFCCCCD4);
            c.drawText(hint(), W / 2, H / 2 + 34 * d, p);
        } else if (flashT > 0) {
            p.setTextSize(20 * d); p.setColor(flash.equals("HIT") ? 0xFF35D07F : 0xFFFF6B7F);
            c.drawText(flash, W / 2, H * 0.88f, p);
        }
        if (gyroUsed && !hasGyro) {
            p.setTextSize(16 * d); p.setColor(0xFFFFB020);
            c.drawText("No gyroscope sensor found on this device", W / 2, H / 2 + 70 * d, p);
        }
    }

    private String hint() {
        switch (prm.mode) {
            case "Recoil": return "Hold FIRE. The weapon kicks the crosshair; drag to pull it back onto the target.";
            case "Gyro": return "Tilt and turn the phone to aim. Tap FIRE on the target.";
            case "Reaction": return "Wait for the target, then aim and tap FIRE as fast as you can.";
            case "Tracking": return "Keep the crosshair on the moving target.";
            case "Crosshair": return "Keep the crosshair inside the head-height band as the target moves.";
            case "Flick": return "Targets vanish quickly. Flick to each one and tap FIRE.";
            default: return "Drag to aim, tap FIRE on the target.";
        }
    }
}
