package com.antonyhern16.lowhealth;

import android.Manifest;
import android.app.Activity;
import android.app.AppOpsManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.PowerManager;
import android.provider.Settings;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Permission gate for the Booster panel. Android never lets an app switch "special access" on by
 * itself, so when the panel opens this walks through every missing permission, opening the exact
 * system screen (or dialog) for each one. It asks once per permission per app launch and
 * continues with the next one when you come back.
 */
final class PermGate {
    static final int REQ_NOTIF = 77;
    private static final Set<String> asked = new HashSet<>();

    static final class Item {
        final String key, name, why;
        final boolean granted;
        Item(String k, String n, String w, boolean g) { key = k; name = n; why = w; granted = g; }
    }

    private PermGate() {}

    static boolean autoOn(Context c) { return Store.sp(c).getBoolean("auto_perm", true); }

    static boolean has(Context c, String key) {
        try {
            switch (key) {
                case "notif":
                    return c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
                case "overlay":
                    return Settings.canDrawOverlays(c);
                case "dnd":
                    return ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).isNotificationPolicyAccessGranted();
                case "write":
                    return Settings.System.canWrite(c);
                case "usage": {
                    AppOpsManager ao = (AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
                    return ao.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                            android.os.Process.myUid(), c.getPackageName()) == AppOpsManager.MODE_ALLOWED;
                }
                case "battery":
                    return ((PowerManager) c.getSystemService(Context.POWER_SERVICE)).isIgnoringBatteryOptimizations(c.getPackageName());
                default:
                    return true;
            }
        } catch (Exception e) {
            return false;
        }
    }

    static List<Item> items(Context c) {
        List<Item> l = new ArrayList<>();
        l.add(new Item("notif", "Notifications", "Boost / overlay status notification", has(c, "notif")));
        l.add(new Item("overlay", "Display over other apps", "Live stats overlay on top of your game", has(c, "overlay")));
        l.add(new Item("dnd", "Do Not Disturb access", "Silence popups while you play", has(c, "dnd")));
        l.add(new Item("write", "Modify system settings", "Max brightness while gaming", has(c, "write")));
        l.add(new Item("usage", "App usage data", "Know which game is in the foreground", has(c, "usage")));
        l.add(new Item("battery", "Ignore battery optimisation", "Keeps the overlay alive in the background", has(c, "battery")));
        return l;
    }

    static int missing(Context c) {
        int n = 0;
        for (Item i : items(c)) if (!i.granted) n++;
        return n;
    }

    /** Opens the system screen / dialog for one permission. */
    static void request(Activity a, String key) {
        String pkg = a.getPackageName();
        Uri u = Uri.parse("package:" + pkg);
        try {
            switch (key) {
                case "notif":
                    a.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
                    return;
                case "overlay":
                    a.startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, u));
                    return;
                case "dnd":
                    a.startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
                    return;
                case "write":
                    a.startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, u));
                    return;
                case "usage":
                    a.startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
                    return;
                case "battery":
                    a.startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, u));
                    return;
                default:
            }
        } catch (Exception e) {
            try {
                a.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, u));
            } catch (Exception ignored) {
            }
        }
    }

    /** Called every time the Booster panel comes to the front. Asks for the next missing permission. */
    static void onOpen(Activity a) {
        if (!autoOn(a)) return;
        for (Item i : items(a)) {
            if (i.granted || asked.contains(i.key)) continue;
            asked.add(i.key);
            request(a, i.key);
            return;     // one at a time; onResume brings us back for the next one
        }
    }

    /** "Grant all missing": forget what was asked this launch and start the chain again. */
    static void restart(Activity a) {
        asked.clear();
        onOpenForce(a);
    }

    private static void onOpenForce(Activity a) {
        for (Item i : items(a)) {
            if (i.granted) continue;
            asked.add(i.key);
            request(a, i.key);
            return;
        }
    }
}
