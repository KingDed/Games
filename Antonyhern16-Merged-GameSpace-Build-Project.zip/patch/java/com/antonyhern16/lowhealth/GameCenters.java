package com.antonyhern16.lowhealth;

import android.app.ActivityManager;
import android.app.AppOpsManager;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.hardware.BatteryState;
import android.hardware.display.DisplayManager;
import android.net.ConnectivityManager;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLSurface;
import android.opengl.GLES20;
import android.os.BatteryManager;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Process;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.InputDevice;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeSet;

/**
 * Data providers for the Game Space centers. Every value comes from a public Android API.
 * When Android does not expose a value the row says so (N/A, Permission required, Vendor restricted)
 * instead of showing a made-up number.
 */
final class GameCenters {
    static final int OK = 0, WARN = 1, NA = 2;

    static final class Row {
        final String k, v;
        final int s;
        Row(String k, String v, int s) { this.k = k; this.v = v; this.s = s; }
    }

    static final String[][] GAMES = {
            {"com.activision.callofduty.shooter", "Call of Duty: Mobile"},
            {"com.tencent.ig", "PUBG Mobile"},
            {"com.pubg.imobile", "BGMI"},
            {"com.dts.freefireth", "Free Fire"},
            {"com.axlebolt.standoff2", "Standoff 2"}};

    private GameCenters() {}

    // ------------------------------------------------------------------ cooling / thermal / charging
    static String thermalName(int s) {
        switch (s) {
            case 0: return "None";
            case 1: return "Light";
            case 2: return "Moderate";
            case 3: return "Severe";
            case 4: return "Critical";
            case 5: return "Emergency";
            case 6: return "Shutdown";
            default: return "Unknown";
        }
    }

    static List<Row> cooling(Context c) {
        ArrayList<Row> r = new ArrayList<>();
        Intent b = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        float temp = -1f;
        int lvl = -1, plugged = 0, volt = 0;
        if (b != null) {
            int t = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
            if (t != Integer.MIN_VALUE) temp = t / 10f;
            lvl = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            plugged = b.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
            volt = b.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0);
        }
        r.add(new Row("Battery temperature", temp < 0 ? "N/A" : String.format(Locale.US, "%.1f \u00B0C", temp),
                temp < 0 ? NA : (temp >= 42f ? WARN : OK)));
        r.add(new Row("Battery level", lvl < 0 ? "N/A" : lvl + "%", lvl < 0 ? NA : OK));
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        int ts = PowerManager.THERMAL_STATUS_NONE;
        try { ts = pm.getCurrentThermalStatus(); } catch (Exception ignored) { }
        r.add(new Row("Thermal status", thermalName(ts), ts >= PowerManager.THERMAL_STATUS_MODERATE ? WARN : OK));
        float hr = Float.NaN;
        try { hr = pm.getThermalHeadroom(10); } catch (Exception ignored) { }
        r.add(new Row("Thermal headroom (10 s forecast)",
                Float.isNaN(hr) ? "N/A (this device does not report it)"
                        : String.format(Locale.US, "%.2f  (1.00 = throttling limit)", hr),
                Float.isNaN(hr) ? NA : (hr >= 0.9f ? WARN : OK)));
        r.add(new Row("CPU / GPU temperature", "Vendor restricted (Android exposes thermal status only)", NA));
        r.add(new Row("Throttling", ts >= PowerManager.THERMAL_STATUS_MODERATE
                ? "Android reports thermal throttling is active or imminent" : "Not reported", ts >= 2 ? WARN : OK));

        String src = plugged == 0 ? "On battery" : plugged == BatteryManager.BATTERY_PLUGGED_AC ? "AC charger"
                : plugged == BatteryManager.BATTERY_PLUGGED_USB ? "USB"
                : plugged == BatteryManager.BATTERY_PLUGGED_WIRELESS ? "Wireless" : "Docked / other";
        r.add(new Row("Charging source", src, OK));
        r.add(new Row("Battery voltage", volt > 0 ? volt + " mV" : "N/A", volt > 0 ? OK : NA));
        long cur = Long.MIN_VALUE;
        try { cur = ((BatteryManager) c.getSystemService(Context.BATTERY_SERVICE)).getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW); }
        catch (Exception ignored) { }
        r.add(new Row("Battery current", (cur == Long.MIN_VALUE || cur == 0) ? "N/A"
                : Math.round(cur / 1000.0) + " mA  (sign and units vary by manufacturer)", (cur == Long.MIN_VALUE || cur == 0) ? NA : OK));
        r.add(new Row("Cooling fan", "Hardware not detected (no public Android API; needs vendor support)", NA));
        r.add(new Row("Bypass charging", "Requires compatible hardware/vendor support, not detected", NA));

        String rec;
        if (ts >= PowerManager.THERMAL_STATUS_SEVERE) rec = "Device is hot. Pause the game, lower in-game graphics and unplug the charger.";
        else if (ts >= PowerManager.THERMAL_STATUS_MODERATE || temp >= 42f) rec = "Getting warm. Lower brightness and graphics, remove the case.";
        else if (plugged != 0 && temp >= 38f) rec = "Charging while gaming adds heat. Unplug if the phone keeps warming up.";
        else rec = "Temperature looks normal.";
        r.add(new Row("Recommendation", rec, (ts >= 2 || temp >= 42f) ? WARN : OK));
        return r;
    }

    // ------------------------------------------------------------------ network
    static List<Row> network(Context c) {
        ArrayList<Row> r = new ArrayList<>();
        ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
        Network n = cm.getActiveNetwork();
        NetworkCapabilities nc = n == null ? null : cm.getNetworkCapabilities(n);
        if (nc == null) {
            r.add(new Row("Connection", "Offline", WARN));
            return r;
        }
        String type = nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ? "Wi-Fi"
                : nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ? "Mobile data"
                : nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ? "Ethernet"
                : nc.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH) ? "Bluetooth" : "Other";
        if (nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) type += " + VPN";
        r.add(new Row("Connection type", type, OK));
        boolean valid = nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
        r.add(new Row("Internet validated by Android", valid ? "Yes" : "No", valid ? OK : WARN));
        boolean metered = !nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED);
        r.add(new Row("Metered", metered ? "Yes (data charges may apply)" : "No", metered ? WARN : OK));
        int ss = nc.getSignalStrength();
        r.add(new Row("Signal strength", ss == NetworkCapabilities.SIGNAL_STRENGTH_UNSPECIFIED ? "N/A" : ss + " (as reported by Android)",
                ss == NetworkCapabilities.SIGNAL_STRENGTH_UNSPECIFIED ? NA : OK));
        r.add(new Row("Link speed estimate", nc.getLinkDownstreamBandwidthKbps() / 1000 + " Mbps down / "
                + nc.getLinkUpstreamBandwidthKbps() / 1000 + " Mbps up (estimate, not measured)", OK));
        r.add(new Row("Wi-Fi name (SSID)", nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                ? "Permission required (Android hides it without location access)" : "Not on Wi-Fi", NA));
        LinkProperties lp = cm.getLinkProperties(n);
        String ip = "N/A";
        if (lp != null) {
            for (LinkAddress la : lp.getLinkAddresses()) {
                if (la.getAddress() != null && !la.getAddress().isLoopbackAddress() && !la.getAddress().isLinkLocalAddress()) {
                    ip = la.getAddress().getHostAddress();
                    break;
                }
            }
        }
        r.add(new Row("Local IP", ip, "N/A".equals(ip) ? NA : OK));
        return r;
    }

    interface ProbeDone { void done(String summary, boolean ok); }

    /** Measures TCP connect time to 1.1.1.1:443. Reports min/avg/max, jitter and loss. Runs off the main thread. */
    static void probe(final int count, final ProbeDone cb) {
        final Handler main = new Handler(Looper.getMainLooper());
        new Thread(() -> {
            long[] us = new long[count];
            int ok = 0;
            for (int i = 0; i < count; i++) {
                long t0 = System.nanoTime();
                try (Socket s = new Socket()) {
                    s.connect(new InetSocketAddress("1.1.1.1", 443), 1500);
                    us[ok++] = (System.nanoTime() - t0) / 1000L;
                } catch (Exception ignored) { }
                try { Thread.sleep(150); } catch (InterruptedException e) { break; }
            }
            final String res = summarize(us, ok, count);
            final boolean good = ok > 0;
            main.post(() -> cb.done(res, good));
        }, "gs-probe").start();
    }

    private static String summarize(long[] us, int ok, int count) {
        if (ok == 0) return "All " + count + " probes failed: no usable connection (100% loss)";
        long min = Long.MAX_VALUE, max = 0, sum = 0, dsum = 0;
        for (int i = 0; i < ok; i++) {
            min = Math.min(min, us[i]);
            max = Math.max(max, us[i]);
            sum += us[i];
            if (i > 0) dsum += Math.abs(us[i] - us[i - 1]);
        }
        double avg = sum / (double) ok / 1000.0;
        double jit = ok > 1 ? dsum / (double) (ok - 1) / 1000.0 : 0;
        int loss = Math.round(100f * (count - ok) / count);
        return String.format(Locale.US, "TCP connect to 1.1.1.1:443, %d probes\nMin %.0f ms  Avg %.0f ms  Max %.0f ms\nJitter %.1f ms  Packet loss %d%%",
                count, min / 1000.0, avg, max / 1000.0, jit, loss);
    }

    // ------------------------------------------------------------------ display / external displays
    static List<Row> display(Context c) {
        ArrayList<Row> r = new ArrayList<>();
        DisplayManager dm = (DisplayManager) c.getSystemService(Context.DISPLAY_SERVICE);
        Display d = dm.getDisplay(Display.DEFAULT_DISPLAY);
        if (d == null) { r.add(new Row("Display", "N/A", NA)); return r; }
        Display.Mode m = d.getMode();
        r.add(new Row("Current mode", m.getPhysicalWidth() + " x " + m.getPhysicalHeight() + " @ "
                + String.format(Locale.US, "%.0f", d.getRefreshRate()) + " Hz", OK));
        TreeSet<Integer> rates = new TreeSet<>();
        for (Display.Mode x : d.getSupportedModes()) {
            if (x.getPhysicalWidth() == m.getPhysicalWidth() && x.getPhysicalHeight() == m.getPhysicalHeight())
                rates.add(Math.round(x.getRefreshRate()));
        }
        StringBuilder sb = new StringBuilder();
        for (int hz : rates) sb.append(sb.length() == 0 ? "" : " / ").append(hz);
        r.add(new Row("Supported refresh rates (this resolution)", sb.length() == 0 ? "N/A" : sb + " Hz", sb.length() == 0 ? NA : OK));
        r.add(new Row("HDR", d.isHdr() ? "Supported" : "Not reported", OK));
        int to = -1;
        try { to = Settings.System.getInt(c.getContentResolver(), Settings.System.SCREEN_OFF_TIMEOUT); } catch (Exception ignored) { }
        r.add(new Row("Screen timeout", to < 0 ? "N/A" : (to / 1000) + " s", to < 0 ? NA : OK));
        r.add(new Row("Forcing a refresh rate", "Not possible for apps system-wide; set it in Android display settings", NA));
        int ext = 0;
        for (Display e : dm.getDisplays()) {
            if (e.getDisplayId() == Display.DEFAULT_DISPLAY) continue;
            ext++;
            Display.Mode em = e.getMode();
            r.add(new Row("External display: " + e.getName(), em.getPhysicalWidth() + " x " + em.getPhysicalHeight() + " @ "
                    + String.format(Locale.US, "%.0f", e.getRefreshRate()) + " Hz"
                    + ((e.getFlags() & Display.FLAG_PRESENTATION) != 0 ? "  (presentation capable)" : ""), OK));
        }
        if (ext == 0) r.add(new Row("External display", "None detected", NA));
        return r;
    }

    // ------------------------------------------------------------------ graphics info
    private static String[] gpuCache;
    private static boolean gpuTried;

    private static synchronized String[] gpuInfo() {
        if (gpuTried) return gpuCache;
        gpuTried = true;
        EGLDisplay dpy = null;
        EGLSurface sf = null;
        EGLContext ctx = null;
        try {
            dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
            int[] v = new int[2];
            if (!EGL14.eglInitialize(dpy, v, 0, v, 1)) return null;
            int[] attr = {EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT, EGL14.EGL_NONE};
            EGLConfig[] cfg = new EGLConfig[1];
            int[] n = new int[1];
            EGL14.eglChooseConfig(dpy, attr, 0, cfg, 0, 1, n, 0);
            if (n[0] < 1) return null;
            sf = EGL14.eglCreatePbufferSurface(dpy, cfg[0], new int[]{EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE}, 0);
            ctx = EGL14.eglCreateContext(dpy, cfg[0], EGL14.EGL_NO_CONTEXT, new int[]{EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE}, 0);
            if (!EGL14.eglMakeCurrent(dpy, sf, sf, ctx)) return null;
            gpuCache = new String[]{GLES20.glGetString(GLES20.GL_RENDERER), GLES20.glGetString(GLES20.GL_VENDOR), GLES20.glGetString(GLES20.GL_VERSION)};
            return gpuCache;
        } catch (Throwable t) {
            return null;
        } finally {
            try {
                if (dpy != null) {
                    EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT);
                    if (sf != null) EGL14.eglDestroySurface(dpy, sf);
                    if (ctx != null) EGL14.eglDestroyContext(dpy, ctx);
                    EGL14.eglTerminate(dpy);
                }
            } catch (Throwable ignored) { }
        }
    }

    static List<Row> graphics(Context c) {
        ArrayList<Row> r = new ArrayList<>();
        String[] g = gpuInfo();
        r.add(new Row("GPU", g == null || g[0] == null ? "N/A" : g[0], g == null ? NA : OK));
        r.add(new Row("GPU vendor", g == null || g[1] == null ? "N/A" : g[1], g == null ? NA : OK));
        r.add(new Row("OpenGL ES driver", g == null || g[2] == null ? "N/A" : g[2], g == null ? NA : OK));
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        int es = am.getDeviceConfigurationInfo().reqGlEsVersion;
        r.add(new Row("OpenGL ES version", (es >> 16) + "." + (es & 0xFFFF), OK));
        PackageManager pm = c.getPackageManager();
        int vk = 0, lvl = -1;
        for (android.content.pm.FeatureInfo f : pm.getSystemAvailableFeatures()) {
            if (f.name == null) continue;
            if (f.name.equals(PackageManager.FEATURE_VULKAN_HARDWARE_VERSION)) vk = f.version;
            if (f.name.equals(PackageManager.FEATURE_VULKAN_HARDWARE_LEVEL)) lvl = f.version;
        }
        r.add(new Row("Vulkan", vk == 0 ? "Not reported" : (vk >> 22) + "." + ((vk >> 12) & 0x3FF)
                + (lvl >= 0 ? "  (hardware level " + lvl + ")" : ""), vk == 0 ? NA : OK));
        DisplayMetrics dmx = c.getResources().getDisplayMetrics();
        r.add(new Row("Screen", dmx.widthPixels + " x " + dmx.heightPixels + " px, " + dmx.densityDpi + " dpi", OK));
        r.add(new Row("MSAA / texture filtering / render scale / VSync", "Game/engine support required. Android cannot override another game's renderer.", NA));
        r.add(new Row("Frame interpolation", "Vendor API required, not available to normal apps", NA));
        r.add(new Row("FPS of other games", "Unsupported: Android has no public API for it. Shooter Center shows its own training FPS only.", NA));
        return r;
    }

    // ------------------------------------------------------------------ controllers
    static List<Row> controllers(Context c) {
        ArrayList<Row> r = new ArrayList<>();
        for (int id : InputDevice.getDeviceIds()) {
            InputDevice d = InputDevice.getDevice(id);
            if (d == null || d.isVirtual()) continue;
            int s = d.getSources();
            boolean pad = (s & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD;
            boolean joy = (s & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK;
            boolean kb = (s & InputDevice.SOURCE_KEYBOARD) == InputDevice.SOURCE_KEYBOARD
                    && d.getKeyboardType() == InputDevice.KEYBOARD_TYPE_ALPHABETIC;
            boolean mouse = (s & InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE;
            if (!(pad || joy || kb || mouse)) continue;
            StringBuilder t = new StringBuilder();
            if (pad) t.append("Gamepad ");
            if (joy) t.append("Joystick ");
            if (kb) t.append("Keyboard ");
            if (mouse) t.append("Mouse ");
            t.append("\nAxes: ").append(d.getMotionRanges().size())
                    .append("  Vendor/Product: ").append(Integer.toHexString(d.getVendorId()))
                    .append("/").append(Integer.toHexString(d.getProductId()));
            try {
                BatteryState bs = d.getBatteryState();
                if (bs != null && bs.isPresent() && !Float.isNaN(bs.getCapacity()))
                    t.append("\nBattery: ").append(Math.round(bs.getCapacity() * 100)).append("%");
                else t.append("\nBattery: not exposed");
            } catch (Throwable ignored) { }
            r.add(new Row(d.getName(), t.toString(), OK));
        }
        if (r.isEmpty()) r.add(new Row("Controllers / keyboard / mouse", "None detected. Pair a Bluetooth or USB device and it appears here.", NA));
        return r;
    }

    // ------------------------------------------------------------------ launch stats / play time
    static void recordLaunch(Context c, String pkg) {
        try {
            JSONObject o = new JSONObject(Store.sp(c).getString("launch_stats", "{}"));
            JSONObject g = o.optJSONObject(pkg);
            if (g == null) g = new JSONObject();
            g.put("n", g.optInt("n") + 1);
            g.put("t", System.currentTimeMillis());
            o.put(pkg, g);
            Store.sp(c).edit().putString("launch_stats", o.toString()).apply();
        } catch (Exception ignored) { }
    }

    static boolean hasUsageAccess(Context c) {
        try {
            AppOpsManager a = (AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
            return a.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.getPackageName())
                    == AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) { return false; }
    }

    static List<Row> stats(Context c) {
        ArrayList<Row> r = new ArrayList<>();
        JSONObject launches;
        try { launches = new JSONObject(Store.sp(c).getString("launch_stats", "{}")); } catch (Exception e) { launches = new JSONObject(); }
        boolean usage = hasUsageAccess(c);
        Map<String, Long> fg = new HashMap<>();
        if (usage) {
            try {
                UsageStatsManager u = (UsageStatsManager) c.getSystemService(Context.USAGE_STATS_SERVICE);
                long now = System.currentTimeMillis();
                List<UsageStats> l = u.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 7L * 86400000L, now);
                if (l != null) for (UsageStats us : l) {
                    Long p = fg.get(us.getPackageName());
                    fg.put(us.getPackageName(), (p == null ? 0L : p) + us.getTotalTimeInForeground());
                }
            } catch (Exception ignored) { }
        }
        LinkedHashSet<String> pk = new LinkedHashSet<>();
        for (String[] g : GAMES) pk.add(g[0]);
        java.util.Iterator<String> it = launches.keys();
        while (it.hasNext()) pk.add(it.next());
        PackageManager pm = c.getPackageManager();
        SimpleDateFormat f = new SimpleDateFormat("MMM d, HH:mm", Locale.getDefault());
        int shown = 0, total = 0;
        for (String p : pk) {
            String name;
            try { name = pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString(); } catch (Exception e) { continue; }
            JSONObject g = launches.optJSONObject(p);
            int n = g == null ? 0 : g.optInt("n");
            total += n;
            StringBuilder v = new StringBuilder();
            v.append(n).append(n == 1 ? " launch" : " launches").append(" from Game Space");
            if (g != null && g.optLong("t") > 0) v.append(", last ").append(f.format(new Date(g.optLong("t"))));
            v.append("\n7-day play time: ");
            if (!usage) v.append("Permission required (Usage access)");
            else {
                long ms = fg.containsKey(p) ? fg.get(p) : 0L;
                v.append(ms / 3600000L).append("h ").append((ms / 60000L) % 60).append("m");
            }
            r.add(new Row(name, v.toString(), OK));
            shown++;
        }
        if (shown == 0) r.add(new Row("Games", "No supported games installed and nothing launched from Game Space yet", NA));
        r.add(new Row("Total launches from Game Space", String.valueOf(total), OK));
        r.add(new Row("Training sessions saved", String.valueOf(Store.arr(c, "train").length()), OK));
        r.add(new Row("FPS / temperature / latency history", "Not recorded. Only launches, play time and training are tracked.", NA));
        return r;
    }

    // ------------------------------------------------------------------ game notes
    static List<JSONObject> notes(Context c, String game) {
        JSONArray a = Store.arr(c, "gs_notes");
        ArrayList<JSONObject> out = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            String g = o.optString("g");
            if (g.length() == 0 || g.equals(game)) out.add(o);
        }
        java.util.Collections.sort(out, (x, y) -> {
            int p = Boolean.compare(y.optBoolean("p"), x.optBoolean("p"));
            return p != 0 ? p : Long.compare(y.optLong("t"), x.optLong("t"));
        });
        return out;
    }

    static void addNote(Context c, String game, String text) {
        try {
            JSONObject o = new JSONObject();
            long now = System.currentTimeMillis();
            o.put("id", now).put("t", now).put("g", game).put("x", text).put("p", false);
            Store.append(c, "gs_notes", o, 200);
        } catch (Exception ignored) { }
    }

    static void editNote(Context c, long id, boolean toggle, boolean delete) {
        JSONArray a = Store.arr(c, "gs_notes");
        JSONArray n = new JSONArray();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            if (o.optLong("id") == id) {
                if (delete) continue;
                try { if (toggle) o.put("p", !o.optBoolean("p")); } catch (Exception ignored) { }
            }
            n.put(o);
        }
        Store.put(c, "gs_notes", n);
    }
}
