package com.antonyhern16.lowhealth;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Small shared UI helpers for the Game Hub screens (dark, red-accent, REDMAGIC style). */
final class HubUi {
    static final int BG = 0xFF0B0B0E, CARD = 0xFF17171C, ACCENT = 0xFFFF2D4B, DIM = 0xFF9A9AA6,
            GOOD = 0xFF35D07F, WARN = 0xFFFFB020, FIELD = 0xFF22222A;

    interface Pick { void on(String value); }

    private HubUi() {}

    static int dp(Context c, float v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }

    static void toast(Context c, String s) { Toast.makeText(c, s, Toast.LENGTH_LONG).show(); }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(c, 4), 0, dp(c, 4));
        return t;
    }

    static LinearLayout card(Context c, LinearLayout parent) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(c, 14), dp(c, 14), dp(c, 14), dp(c, 14));
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(c, 16));
        l.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(c, 10);
        parent.addView(l, lp);
        return l;
    }

    static void styleChip(Context c, Button b, boolean on) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(on ? ACCENT : FIELD);
        g.setCornerRadius(dp(c, 18));
        b.setBackground(g);
        b.setTextColor(Color.WHITE);
    }

    static Button pill(Context c, String label, boolean on) {
        Button b = new Button(c);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        styleChip(c, b, on);
        return b;
    }

    /** A horizontally scrollable row of single-choice chips. */
    static void chips(final Context c, LinearLayout parent, final String[] labels, String selected, final Pick pick) {
        HorizontalScrollView hs = new HorizontalScrollView(c);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(c);
        for (final String s : labels) {
            Button b = pill(c, s, s.equals(selected));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(c, 40));
            lp.rightMargin = dp(c, 6);
            lp.topMargin = dp(c, 6);
            b.setOnClickListener(v -> pick.on(s));
            row.addView(b, lp);
        }
        hs.addView(row);
        parent.addView(hs);
    }

    static Button button(Context c, String label, boolean primary, View.OnClickListener l) {
        Button b = new Button(c);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        GradientDrawable g = new GradientDrawable();
        g.setColor(primary ? ACCENT : FIELD);
        g.setCornerRadius(dp(c, 14));
        b.setBackground(g);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(c, 48));
        lp.topMargin = dp(c, 10);
        b.setLayoutParams(lp);
        return b;
    }

    static EditText field(Context c, String hint, boolean numeric) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setHintTextColor(DIM);
        e.setTextColor(Color.WHITE);
        e.setSingleLine(true);
        if (numeric) e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        return e;
    }
}
