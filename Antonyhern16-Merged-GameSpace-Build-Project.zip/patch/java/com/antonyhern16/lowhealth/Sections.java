package com.antonyhern16.lowhealth;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.BatteryManager;
import android.os.Build;
import android.os.PowerManager;
import android.view.Choreographer;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Game Hub screens for profiles, training, matches and the performance dashboard.
 * Everything is stored locally (see Store). Nothing here reads or controls any game.
 */
final class Sections {
    private Sections() {}

    static final String[] GAMES = {"CODM", "PUBG"};
    private static final SimpleDateFormat DATE = new SimpleDateFormat("MMM d, HH:mm", Locale.getDefault());

    // field key, label
    private static final String[][] CODM_FIELDS = {
            {"cam", "Camera sensitivity (no scope)"}, {"fire", "Firing camera sensitivity"},
            {"ads_rd", "ADS: red dot / holographic"}, {"ads_mid", "ADS: 2x-4x scope"}, {"ads_hi", "ADS: 6x+ / sniper"},
            {"gy_cam", "Gyro: no scope"}, {"gy_ads", "Gyro: ADS"}, {"gy_scope", "Gyro: scoped"}};
    private static final String[][] PUBG_FIELDS = {
            {"cam", "Camera sensitivity (no scope)"}, {"ads", "ADS / red dot"},
            {"x2", "2x scope"}, {"x3", "3x scope"}, {"x4", "4x scope"}, {"x6", "6x scope"},
            {"gy_cam", "Gyro: no scope"}, {"gy_ads", "Gyro: ADS"}, {"gy_scope", "Gyro: scoped"}};
    private static final String[] GYRO_MODES = {"Off", "ADS only", "Always"};

    static String game(Context c) {
        String g = Store.sp(c).getString("ui_game", "CODM");
        return "PUBG".equals(g) ? "PUBG" : "CODM";
    }

    private static void setGame(Context c, String g) { Store.sp(c).edit().putString("ui_game", g).apply(); }

    private static Double num(String s, double min, double max) {
        if (s == null) return null;
        s = s.trim().replace(',', '.');
        if (s.length() == 0) return null;
        try {
            double v = Double.parseDouble(s);
            if (Double.isNaN(v) || Double.isInfinite(v) || v < min || v > max) return null;
            return v;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static String fmt(double v) {
        return v == Math.rint(v) ? String.valueOf((long) v) : String.format(Locale.US, "%.1f", v);
    }

    private static void gameChips(final Activity a, LinearLayout parent, final Runnable rerender) {
        HubUi.chips(a, parent, GAMES, game(a), s -> { setGame(a, s); rerender.run(); });
    }

    private static List<JSONObject> list(Context c, String key, String game) {
        JSONArray arr = Store.arr(c, key);
        List<JSONObject> out = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o != null && (game == null || game.equals(o.optString("game")))) out.add(o);
        }
        return out;
    }

    // =====================================================================================
    // PROFILES
    // =====================================================================================
    static void profiles(final Activity a, LinearLayout body, final Runnable rerender) {
        final String game = game(a);
        final String[][] fields = "PUBG".equals(game) ? PUBG_FIELDS : CODM_FIELDS;
        List<JSONObject> hist = list(a, "prof_hist", game);
        final JSONObject cur = hist.isEmpty() ? new JSONObject() : hist.get(hist.size() - 1).optJSONObject("vals");

        LinearLayout c = HubUi.card(a, body);
        c.addView(HubUi.text(a, "SENSITIVITY PROFILE", 12, HubUi.ACCENT, true));
        gameChips(a, c, rerender);
        c.addView(HubUi.text(a, "Type the numbers exactly as they appear in the game's own settings. Each save is kept, so you can compare before and after.", 12, HubUi.DIM, false));
        final List<EditText> boxes = new ArrayList<>();
        for (String[] f : fields) {
            c.addView(HubUi.text(a, f[1], 13, 0xFFFFFFFF, false));
            EditText e = HubUi.field(a, "number", true);
            if (cur != null && cur.has(f[0])) e.setText(cur.optString(f[0]));
            boxes.add(e);
            c.addView(e);
        }
        c.addView(HubUi.text(a, "Gyroscope", 13, 0xFFFFFFFF, false));
        final String[] gyro = {cur != null && cur.optString("gyro_mode").length() > 0 ? cur.optString("gyro_mode") : "Off"};
        final LinearLayout gyroHolder = new LinearLayout(a);
        gyroHolder.setOrientation(LinearLayout.VERTICAL);
        c.addView(gyroHolder);
        drawGyroChips(a, gyroHolder, gyro);
        c.addView(HubUi.text(a, "Why are you changing it? (optional)", 13, 0xFFFFFFFF, false));
        final EditText note = HubUi.field(a, "e.g. overshooting at close range", false);
        c.addView(note);
        c.addView(HubUi.button(a, "Save profile", true, v -> {
            JSONObject vals = new JSONObject();
            try {
                for (int i = 0; i < fields.length; i++) {
                    String raw = boxes.get(i).getText().toString().trim();
                    if (raw.length() == 0) continue;
                    Double n = num(raw, 0, 500);
                    if (n == null) {
                        HubUi.toast(a, fields[i][1] + ": enter a number from 0 to 500");
                        return;
                    }
                    vals.put(fields[i][0], fmt(n));
                }
                vals.put("gyro_mode", gyro[0]);
                if (cur != null && sameVals(cur, vals, fields)) {
                    HubUi.toast(a, "Nothing changed since the last save");
                    return;
                }
                JSONObject rec = new JSONObject();
                rec.put("t", System.currentTimeMillis()).put("game", game).put("vals", vals).put("note", note.getText().toString().trim());
                if (!Store.append(a, "prof_hist", rec, 200)) {
                    HubUi.toast(a, "Could not save. Check free storage and try again.");
                    return;
                }
                HubUi.toast(a, "Profile saved");
                rerender.run();
            } catch (Exception ex) {
                HubUi.toast(a, "Could not save: " + ex.getClass().getSimpleName());
            }
        }));

        compareCard(a, body, game, fields, hist, rerender);
    }

    private static void drawGyroChips(final Activity a, final LinearLayout holder, final String[] gyro) {
        holder.removeAllViews();
        HubUi.chips(a, holder, GYRO_MODES, gyro[0], s -> { gyro[0] = s; drawGyroChips(a, holder, gyro); });
    }

    private static boolean sameVals(JSONObject a, JSONObject b, String[][] fields) {
        for (String[] f : fields) if (!a.optString(f[0]).equals(b.optString(f[0]))) return false;
        return a.optString("gyro_mode").equals(b.optString("gyro_mode"));
    }

    private static int selChange = -1;

    private static void compareCard(final Activity a, LinearLayout body, final String game, final String[][] fields,
                                    final List<JSONObject> hist, final Runnable rerender) {
        LinearLayout c = HubUi.card(a, body);
        c.addView(HubUi.text(a, "BEFORE AND AFTER", 12, HubUi.ACCENT, true));
        if (hist.size() < 2) {
            c.addView(HubUi.text(a, "Save the profile once, change a value, then save again. The comparison appears here.", 13, HubUi.DIM, false));
            return;
        }
        // changes are hist[1..n-1]; pick one, default newest
        int idx = selChange >= 1 && selChange < hist.size() ? selChange : hist.size() - 1;
        String[] labels = new String[hist.size() - 1];
        for (int i = 1; i < hist.size(); i++) labels[i - 1] = "#" + i + " " + DATE.format(new Date(hist.get(i).optLong("t")));
        HubUi.chips(a, c, labels, labels[idx - 1], s -> {
            try {
                selChange = Integer.parseInt(s.substring(1, s.indexOf(' ')));
            } catch (Exception ignored) {
                selChange = -1;
            }
            rerender.run();
        });
        JSONObject before = hist.get(idx - 1).optJSONObject("vals"), after = hist.get(idx).optJSONObject("vals");
        if (before == null || after == null) {
            c.addView(HubUi.text(a, "This record is damaged and cannot be compared.", 13, HubUi.WARN, false));
            return;
        }
        boolean any = false;
        for (String[] f : fields) {
            String b = before.optString(f[0]), n = after.optString(f[0]);
            if (!b.equals(n)) {
                any = true;
                c.addView(HubUi.text(a, f[1] + ":  " + (b.length() == 0 ? "-" : b) + "  →  " + (n.length() == 0 ? "-" : n), 14, 0xFFFFFFFF, false));
            }
        }
        if (!before.optString("gyro_mode").equals(after.optString("gyro_mode"))) {
            any = true;
            c.addView(HubUi.text(a, "Gyroscope:  " + before.optString("gyro_mode") + "  →  " + after.optString("gyro_mode"), 14, 0xFFFFFFFF, false));
        }
        if (!any) c.addView(HubUi.text(a, "Only the note changed.", 13, HubUi.DIM, false));
        String why = hist.get(idx).optString("note");
        if (why.length() > 0) c.addView(HubUi.text(a, "Reason: " + why, 12, HubUi.DIM, false));

        long t0 = hist.get(idx - 1).optLong("t"), t1 = hist.get(idx).optLong("t");
        long t2 = idx + 1 < hist.size() ? hist.get(idx + 1).optLong("t") : Long.MAX_VALUE;
        c.addView(HubUi.text(a, "WHAT YOUR RESULTS DID", 11, HubUi.ACCENT, true));
        for (String m : new String[]{"reaction", "switch", "track"}) {
            Double x = Store.avgTrain(a, game, m, t0, t1), y = Store.avgTrain(a, game, m, t1, t2);
            c.addView(compareLine(a, Store.modeName(m), x, y, Store.unit(m), Store.lowerBetter(m)));
        }
        Double kx = Store.kd(a, game, t0, t1), ky = Store.kd(a, game, t1, t2);
        c.addView(compareLine(a, "K/D", kx, ky, "", false));
        c.addView(HubUi.text(a, "Averages over the time before vs after this change. With only a few drills or matches the difference can be luck, so repeat the drills before drawing conclusions.", 11, HubUi.DIM, false));
    }

    private static TextView compareLine(Context c, String name, Double x, Double y, String unit, boolean lowerBetter) {
        String s;
        int col = 0xFFFFFFFF;
        if (x == null || y == null) {
            s = name + ":  not enough data" + (x == null && y == null ? "" : x == null ? " before" : " after");
            col = HubUi.DIM;
        } else {
            s = name + ":  " + fmt(Math.round(x * 10) / 10.0) + unit + "  →  " + fmt(Math.round(y * 10) / 10.0) + unit;
            double diff = y - x;
            if (Math.abs(diff) > 0.0001) col = (lowerBetter ? diff < 0 : diff > 0) ? HubUi.GOOD : HubUi.WARN;
        }
        return HubUi.text(c, s, 13, col, false);
    }

    // =====================================================================================
    // TRAINING
    // =====================================================================================
    static void train(final Activity a, LinearLayout body, final Runnable rerender) {
        final String game = game(a);
        LinearLayout c = HubUi.card(a, body);
        c.addView(HubUi.text(a, "AIM TRAINING", 12, HubUi.ACCENT, true));
        gameChips(a, c, rerender);
        c.addView(HubUi.text(a, "Offline drills on practice targets drawn by this app. They never touch or read any game. Results are saved per game so you can track progress.", 12, HubUi.DIM, false));
        final String[] modes = {"reaction", "switch", "track"};
        final String[] desc = {"5 rounds. Tap when the screen turns green.", "Hit 20 targets that jump around the screen.", "Keep your finger on a moving target for 20 seconds."};
        for (int i = 0; i < modes.length; i++) {
            final String m = modes[i];
            LinearLayout k = HubUi.card(a, body);
            k.addView(HubUi.text(a, Store.modeName(m), 16, 0xFFFFFFFF, true));
            k.addView(HubUi.text(a, desc[i], 12, HubUi.DIM, false));
            Double best = Store.best(a, game, m);
            k.addView(HubUi.text(a, best == null ? "Personal best: none yet" : "Personal best: " + fmt(best) + Store.unit(m), 13, HubUi.GOOD, false));
            k.addView(HubUi.button(a, "Start", true, v -> {
                try {
                    a.startActivity(new Intent(a, TrainActivity.class).putExtra(TrainActivity.X_MODE, m).putExtra(TrainActivity.X_GAME, game));
                } catch (Exception e) {
                    HubUi.toast(a, "Could not open the drill");
                }
            }));
        }
        LinearLayout p = HubUi.card(a, body);
        p.addView(HubUi.text(a, "PROGRESS", 12, HubUi.ACCENT, true));
        for (String m : modes) {
            List<JSONObject> rows = new ArrayList<>();
            for (JSONObject o : list(a, "train", game)) if (m.equals(o.optString("mode"))) rows.add(o);
            int n = Math.min(rows.size(), 30);
            float[] v = new float[n];
            for (int i = 0; i < n; i++) v[i] = (float) rows.get(rows.size() - n + i).optDouble("score", 0);
            ChartView cv = new ChartView(a);
            cv.set(v, Store.modeName(m) + " (" + Store.unit(m).trim() + ", " + (Store.lowerBetter(m) ? "lower" : "higher") + " is better)");
            p.addView(cv);
            if (rows.size() >= 6) {
                double first = 0, last = 0;
                for (int i = 0; i < 3; i++) {
                    first += rows.get(i).optDouble("score", 0) / 3;
                    last += rows.get(rows.size() - 1 - i).optDouble("score", 0) / 3;
                }
                double diff = last - first;
                boolean good = Store.lowerBetter(m) ? diff < 0 : diff > 0;
                p.addView(HubUi.text(a, "First 3 vs latest 3: " + fmt(Math.round(first * 10) / 10.0) + " → " + fmt(Math.round(last * 10) / 10.0) + Store.unit(m), 12, good ? HubUi.GOOD : HubUi.DIM, false));
            }
        }
        p.addView(HubUi.button(a, "Clear training results for " + game, false, v -> confirm(a, "Delete all " + game + " training results?", () -> {
            JSONArray all = Store.arr(a, "train"), keep = new JSONArray();
            for (int i = 0; i < all.length(); i++) {
                JSONObject o = all.optJSONObject(i);
                if (o != null && !game.equals(o.optString("game"))) keep.put(o);
            }
            Store.put(a, "train", keep);
            rerender.run();
        })));
    }

    // =====================================================================================
    // MATCHES
    // =====================================================================================
    static void matches(final Activity a, LinearLayout body, final Runnable rerender) {
        final String game = game(a);
        LinearLayout c = HubUi.card(a, body);
        c.addView(HubUi.text(a, "LOG A MATCH", 12, HubUi.ACCENT, true));
        gameChips(a, c, rerender);
        final String[] mode = {"Multiplayer"}, result = {"Win"};
        final LinearLayout mh = new LinearLayout(a), rh = new LinearLayout(a);
        mh.setOrientation(LinearLayout.VERTICAL);
        rh.setOrientation(LinearLayout.VERTICAL);
        final String[] modes = "PUBG".equals(game) ? new String[]{"Classic", "TDM", "Arena"} : new String[]{"Multiplayer", "Battle Royale", "Ranked"};
        mode[0] = modes[0];
        drawChoice(a, mh, modes, mode);
        drawChoice(a, rh, new String[]{"Win", "Loss", "Draw"}, result);
        c.addView(mh);
        c.addView(rh);
        final EditText map = HubUi.field(a, "Map (optional)", false);
        final EditText kills = HubUi.field(a, "Kills", true), deaths = HubUi.field(a, "Deaths", true), assists = HubUi.field(a, "Assists (optional)", true);
        final EditText note = HubUi.field(a, "Note (optional)", false);
        c.addView(map);
        c.addView(kills);
        c.addView(deaths);
        c.addView(assists);
        c.addView(note);
        c.addView(HubUi.button(a, "Save match", true, v -> {
            Double k = num(kills.getText().toString(), 0, 999), d = num(deaths.getText().toString(), 0, 999);
            Double as = assists.getText().toString().trim().length() == 0 ? Double.valueOf(0) : num(assists.getText().toString(), 0, 999);
            if (k == null || d == null || as == null) {
                HubUi.toast(a, "Enter kills and deaths as whole numbers from 0 to 999");
                return;
            }
            try {
                JSONObject o = new JSONObject();
                o.put("t", System.currentTimeMillis()).put("game", game).put("mode", mode[0]).put("result", result[0])
                        .put("map", map.getText().toString().trim()).put("k", k.intValue()).put("d", d.intValue()).put("a", as.intValue())
                        .put("note", note.getText().toString().trim());
                if (Store.append(a, "matches", o, 1000)) {
                    HubUi.toast(a, "Match saved");
                    rerender.run();
                } else {
                    HubUi.toast(a, "Could not save. Check free storage and try again.");
                }
            } catch (Exception ex) {
                HubUi.toast(a, "Could not save: " + ex.getClass().getSimpleName());
            }
        }));

        final List<JSONObject> ms = list(a, "matches", game);
        LinearLayout s = HubUi.card(a, body);
        s.addView(HubUi.text(a, "PERFORMANCE", 12, HubUi.ACCENT, true));
        if (ms.isEmpty()) {
            s.addView(HubUi.text(a, "No " + game + " matches logged yet.", 13, HubUi.DIM, false));
            return;
        }
        int wins = 0, tk = 0, td = 0, bestK = 0;
        double bestKd = 0;
        for (JSONObject o : ms) {
            if ("Win".equals(o.optString("result"))) wins++;
            tk += o.optInt("k");
            td += o.optInt("d");
            bestK = Math.max(bestK, o.optInt("k"));
            bestKd = Math.max(bestKd, o.optInt("k") / (double) Math.max(1, o.optInt("d")));
        }
        s.addView(HubUi.text(a, ms.size() + " matches   win rate " + Math.round(wins * 100.0 / ms.size()) + "%   overall K/D " + String.format(Locale.US, "%.2f", tk / (double) Math.max(1, td)), 14, 0xFFFFFFFF, false));
        s.addView(HubUi.text(a, "Personal bests: most kills " + bestK + ",  best match K/D " + String.format(Locale.US, "%.2f", bestKd), 13, HubUi.GOOD, false));
        int n = Math.min(ms.size(), 30);
        float[] kd = new float[n], kl = new float[n];
        for (int i = 0; i < n; i++) {
            JSONObject o = ms.get(ms.size() - n + i);
            kd[i] = o.optInt("k") / (float) Math.max(1, o.optInt("d"));
            kl[i] = o.optInt("k");
        }
        ChartView c1 = new ChartView(a), c2 = new ChartView(a);
        c1.set(kd, "K/D per match (last " + n + ")");
        c2.set(kl, "Kills per match (last " + n + ")");
        s.addView(c1);
        s.addView(c2);

        LinearLayout h = HubUi.card(a, body);
        h.addView(HubUi.text(a, "RECENT (tap one to delete)", 12, HubUi.ACCENT, true));
        JSONArray all = Store.arr(a, "matches");
        int shown = 0;
        for (int i = all.length() - 1; i >= 0 && shown < 15; i--) {
            final JSONObject o = all.optJSONObject(i);
            if (o == null || !game.equals(o.optString("game"))) continue;
            shown++;
            final int index = i;
            TextView t = HubUi.text(a, DATE.format(new Date(o.optLong("t"))) + "  " + o.optString("result") + "  " + o.optString("mode")
                    + (o.optString("map").length() > 0 ? "  " + o.optString("map") : "") + "   " + o.optInt("k") + "/" + o.optInt("d") + "/" + o.optInt("a"), 13, 0xFFFFFFFF, false);
            t.setOnClickListener(v -> confirm(a, "Delete this match?", () -> {
                Store.removeAt(a, "matches", index);
                rerender.run();
            }));
            h.addView(t);
            if (o.optString("note").length() > 0) h.addView(HubUi.text(a, "   " + o.optString("note"), 11, HubUi.DIM, false));
        }
    }

    private static void drawChoice(final Activity a, final LinearLayout holder, final String[] labels, final String[] sel) {
        holder.removeAllViews();
        HubUi.chips(a, holder, labels, sel[0], s -> { sel[0] = s; drawChoice(a, holder, labels, sel); });
    }

    // =====================================================================================
    // DASHBOARD
    // =====================================================================================
    static void dashboard(final Activity a, LinearLayout body, final Runnable rerender) {
        LinearLayout c = HubUi.card(a, body);
        c.addView(HubUi.text(a, "THIS PHONE RIGHT NOW", 12, HubUi.ACCENT, true));
        try {
            Display d = a.getWindowManager().getDefaultDisplay();
            c.addView(HubUi.text(a, "Refresh rate now: " + Math.round(d.getRefreshRate()) + " Hz", 15, 0xFFFFFFFF, true));
            StringBuilder hz = new StringBuilder();
            List<Integer> seen = new ArrayList<>();
            for (Display.Mode m : d.getSupportedModes()) {
                int r = Math.round(m.getRefreshRate());
                if (!seen.contains(r)) {
                    seen.add(r);
                    hz.append(hz.length() > 0 ? ", " : "").append(r);
                }
            }
            c.addView(HubUi.text(a, "Supported by the display: " + hz + " Hz", 12, HubUi.DIM, false));
        } catch (Exception e) {
            c.addView(HubUi.text(a, "Refresh rate unavailable on this phone.", 13, HubUi.WARN, false));
        }
        try {
            Intent b = a.registerReceiver(null, new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            int t = b == null ? Integer.MIN_VALUE : b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
            int lvl = b == null ? -1 : b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            c.addView(HubUi.text(a, t == Integer.MIN_VALUE ? "Battery temperature: unavailable" : "Battery temperature: " + (t / 10f) + " °C   (battery " + lvl + "%)", 15, 0xFFFFFFFF, true));
        } catch (Exception e) {
            c.addView(HubUi.text(a, "Battery temperature unavailable.", 13, HubUi.WARN, false));
        }
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                int th = ((PowerManager) a.getSystemService(Context.POWER_SERVICE)).getCurrentThermalStatus();
                String[] names = {"normal", "light", "moderate", "severe", "critical", "emergency", "shutdown"};
                c.addView(HubUi.text(a, "Thermal status: " + (th >= 0 && th < names.length ? names[th] : String.valueOf(th)), 14, th >= 3 ? HubUi.WARN : HubUi.GOOD, false));
            } catch (Exception ignored) {
            }
        }
        final TextView fpsOut = HubUi.text(a, "Display frame rate test: not run", 13, HubUi.DIM, false);
        c.addView(fpsOut);
        c.addView(HubUi.button(a, "Measure this screen's frame rate (2 s)", false, v -> measureFps(a, c, fpsOut)));
        c.addView(HubUi.text(a, "That test measures only this app's own animation. For FPS inside a game, use the Info overlay in Game Space and type what you see below. Android does not let a normal app read another app's FPS.", 11, HubUi.DIM, false));

        LinearLayout p = HubUi.card(a, body);
        p.addView(HubUi.text(a, "MANUAL PING AND FPS LOG", 12, HubUi.ACCENT, true));
        final EditText ping = HubUi.field(a, "Ping (ms) from the game", true), fps = HubUi.field(a, "In-game FPS (optional)", true), note = HubUi.field(a, "Note, e.g. Wi-Fi 5 GHz", false);
        p.addView(ping);
        p.addView(fps);
        p.addView(note);
        p.addView(HubUi.button(a, "Save entry", true, v -> {
            Double pg = num(ping.getText().toString(), 0, 5000);
            String fr = fps.getText().toString().trim();
            Double fp = fr.length() == 0 ? null : num(fr, 0, 1000);
            if (pg == null || (fr.length() > 0 && fp == null)) {
                HubUi.toast(a, "Enter ping from 0 to 5000 ms, and FPS (if any) from 0 to 1000");
                return;
            }
            try {
                JSONObject o = new JSONObject();
                o.put("t", System.currentTimeMillis()).put("ping", pg.intValue()).put("note", note.getText().toString().trim());
                if (fp != null) o.put("fps", fp.intValue());
                if (Store.append(a, "perf", o, 500)) {
                    HubUi.toast(a, "Saved");
                    rerender.run();
                } else {
                    HubUi.toast(a, "Could not save. Check free storage and try again.");
                }
            } catch (Exception ex) {
                HubUi.toast(a, "Could not save: " + ex.getClass().getSimpleName());
            }
        }));
        List<JSONObject> rows = list(a, "perf", null);
        int n = Math.min(rows.size(), 30);
        float[] pv = new float[n];
        List<Float> fv = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            JSONObject o = rows.get(rows.size() - n + i);
            pv[i] = o.optInt("ping");
            if (o.has("fps")) fv.add((float) o.optInt("fps"));
        }
        ChartView pc = new ChartView(a);
        pc.set(pv, "Ping (ms), last " + n + " entries");
        p.addView(pc);
        if (fv.size() > 0) {
            float[] f = new float[fv.size()];
            for (int i = 0; i < f.length; i++) f[i] = fv.get(i);
            ChartView fc = new ChartView(a);
            fc.set(f, "In-game FPS you recorded");
            p.addView(fc);
        }
        p.addView(HubUi.button(a, "Clear ping and FPS log", false, v -> confirm(a, "Delete the whole log?", () -> {
            Store.put(a, "perf", new JSONArray());
            rerender.run();
        })));
    }

    /** Spinning bar that forces a redraw each frame, so the measured rate reflects real rendering. */
    private static final class Spin extends View {
        private final Paint p = new Paint();
        private float ang;
        boolean running = true;

        Spin(Context c) {
            super(c);
            p.setColor(HubUi.ACCENT);
            p.setStrokeWidth(6 * c.getResources().getDisplayMetrics().density);
        }

        @Override
        protected void onMeasure(int w, int h) {
            setMeasuredDimension(MeasureSpec.getSize(w), HubUi.dp(getContext(), 60));
        }

        @Override
        protected void onDraw(Canvas c) {
            ang += 4;
            float cx = getWidth() / 2f, cy = getHeight() / 2f, r = getHeight() / 2.5f;
            c.drawLine(cx, cy, cx + (float) Math.cos(Math.toRadians(ang)) * r, cy + (float) Math.sin(Math.toRadians(ang)) * r, p);
            if (running) postInvalidateOnAnimation();
        }
    }

    private static void measureFps(Activity a, final LinearLayout parent, final TextView out) {
        final Spin spin = new Spin(a);
        parent.addView(spin);
        out.setText("Measuring...");
        final long[] start = {0};
        final int[] frames = {0};
        Choreographer.getInstance().postFrameCallback(new Choreographer.FrameCallback() {
            @Override
            public void doFrame(long ns) {
                if (start[0] == 0) start[0] = ns;
                frames[0]++;
                if (ns - start[0] < 2000000000L) {
                    Choreographer.getInstance().postFrameCallback(this);
                } else {
                    spin.running = false;
                    parent.removeView(spin);
                    double f = (frames[0] - 1) * 1e9 / (ns - start[0]);
                    out.setText(String.format(Locale.US, "This screen rendered at about %.0f FPS while animating", f));
                }
            }
        });
    }

    private static void confirm(Context c, String msg, final Runnable yes) {
        new AlertDialog.Builder(c).setMessage(msg).setPositiveButton("Yes", (d, w) -> yes.run()).setNegativeButton("No", null).show();
    }
}
