package com.antonyhern16.lowhealth;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Shows a reminder notification when an alarm set from Game Hub fires. */
public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("reminders", "Gaming reminders", NotificationManager.IMPORTANCE_HIGH));
        String title = i.getStringExtra("title");
        String text = i.getStringExtra("text");
        Notification n = new Notification.Builder(c, "reminders")
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(title == null ? "Reminder" : title)
                .setContentText(text == null ? "" : text)
                .setAutoCancel(true)
                .build();
        nm.notify(i.getIntExtra("id", 1), n);
        // forget this reminder in the stored list
        c.getSharedPreferences("gamehub", Context.MODE_PRIVATE).edit().remove("rem_" + i.getIntExtra("id", 1)).apply();
    }
}
