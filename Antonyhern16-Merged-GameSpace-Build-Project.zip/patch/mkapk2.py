import sys, os, zipfile, struct, hashlib, datetime
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
src, out = sys.argv[1], sys.argv[2]
# 1. aligned zip
files=[]
for root,_,fs in os.walk(src):
    for f in fs:
        p=os.path.join(root,f); files.append((os.path.relpath(p,src).replace(os.sep,"/"),p))
files.sort(key=lambda x:(x[0]!="AndroidManifest.xml",x[0]))
with open(out,"wb") as fp:
    zf=zipfile.ZipFile(fp,"w")
    for name,p in files:
        data=open(p,"rb").read()
        zi=zipfile.ZipInfo(name,(2020,1,1,0,0,0)); zi.external_attr=0o644<<16
        stored = name=="resources.arsc" or name.endswith(".so")
        if stored:
            zi.compress_type=zipfile.ZIP_STORED
            off=fp.tell()+30+len(name.encode())
            pad=(-off)%4
            zi.extra=b"\x00"*pad
        else: zi.compress_type=zipfile.ZIP_DEFLATED
        zf.writestr(zi,data)
    zf.close()
buf=open(out,"rb").read()
# 2. locate EOCD
e=buf.rfind(b"PK\x05\x06"); cd_size,cd_off=struct.unpack("<II",buf[e+12:e+20])
contents=buf[:cd_off]; cd=buf[cd_off:e]; eocd=bytearray(buf[e:])
# 3. key + cert
import os
keyfile=sys.argv[3] if len(sys.argv)>3 else None
if keyfile and os.path.exists(keyfile):
    key=serialization.load_pem_private_key(open(keyfile,"rb").read(),None)
else:
    key=rsa.generate_private_key(65537,2048)
    if keyfile: open(keyfile,"wb").write(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,"Android Debug")])
now=datetime.datetime(2024,1,1)
cert=(x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
  .serial_number(1).not_valid_before(now).not_valid_after(now+datetime.timedelta(days=36500))
  .sign(key,hashes.SHA256()))
certder=cert.public_bytes(serialization.Encoding.DER)
pub=key.public_key().public_bytes(serialization.Encoding.DER,serialization.PublicFormat.SubjectPublicKeyInfo)
# 4. digest (EOCD cd offset = start of signing block = cd_off before insert)
def chunks(b):
    for i in range(0,len(b),1<<20): yield b[i:i+(1<<20)]
digs=[]
for part in (contents,cd,bytes(eocd)):
    for c in chunks(part): digs.append(hashlib.sha256(b"\xa5"+struct.pack("<I",len(c))+c).digest())
top=hashlib.sha256(b"\x5a"+struct.pack("<I",len(digs))+b"".join(digs)).digest()
lp=lambda b:struct.pack("<I",len(b))+b
algo=0x0103
digest_rec=struct.pack("<II",algo,0)[:4]+lp(top)
signed=lp(lp(digest_rec))+lp(lp(certder))+lp(b"")
sig=key.sign(signed,padding.PKCS1v15(),hashes.SHA256())
sigs=lp(struct.pack("<I",algo)+lp(sig))
signer=lp(signed)+lp(sigs)+lp(pub)
v2=lp(lp(signer))
pair=struct.pack("<QI",4+len(v2),0x7109871a)+v2
size=len(pair)+8+16
block=struct.pack("<Q",size)+pair+struct.pack("<Q",size)+b"APK Sig Block 42"
# 5. fix EOCD offset
struct.pack_into("<I",eocd,16,cd_off+len(block))
open(out,"wb").write(contents+block+cd+bytes(eocd))
print("ok",os.path.getsize(out))
