import sys
p = sys.argv[1]
s = open(p, encoding="utf-8").read()
perms = ["android.permission.FOREGROUND_SERVICE",
         "android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION",
         "android.permission.SYSTEM_ALERT_WINDOW",
         "android.permission.VIBRATE",
         "android.permission.POST_NOTIFICATIONS",
         "android.permission.FOREGROUND_SERVICE_SPECIAL_USE",
         "android.permission.KILL_BACKGROUND_PROCESSES",
         "android.permission.ACCESS_NOTIFICATION_POLICY",
         "android.permission.WRITE_SETTINGS",
         "android.permission.PACKAGE_USAGE_STATS",
         "android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS",
         "android.permission.QUERY_ALL_PACKAGES",
         "android.permission.INTERNET",
         "android.permission.ACCESS_NETWORK_STATE",
         "android.permission.WAKE_LOCK"]
add = "".join('    <uses-permission android:name="%s" />\n' % x for x in perms if ('"%s"' % x) not in s)
comp = '''        <activity android:name="com.antonyhern16.lowhealth.LowHealthActivity" android:exported="true" android:label="Low-health alert" android:icon="@drawable/abc_btn_check_to_on_mtrl_000" android:theme="@android:style/Theme.Material.NoActionBar">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        <activity android:name="com.antonyhern16.lowhealth.GameHubActivity" android:exported="true" android:label="Game Hub" android:icon="@drawable/abc_btn_check_to_on_mtrl_000" android:theme="@android:style/Theme.Material.NoActionBar">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        <activity android:name="com.antonyhern16.lowhealth.TrainActivity" android:exported="false" android:label="Aim training" android:theme="@android:style/Theme.Material.NoActionBar" android:screenOrientation="unspecified" />
        <receiver android:name="com.antonyhern16.lowhealth.ReminderReceiver" android:exported="false" />
        <service android:name="com.antonyhern16.lowhealth.BoostOverlayService" android:exported="false" android:foregroundServiceType="specialUse">
            <property android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE" android:value="User-enabled gaming stats overlay" />
        </service>
        <activity android:name="com.antonyhern16.lowhealth.FeatureCenterActivity" android:exported="false" android:label="Game Space Feature Center" android:screenOrientation="sensor" android:theme="@android:style/Theme.Material.NoActionBar" />
        <activity android:name="com.antonyhern16.lowhealth.CenterActivity" android:exported="false" android:label="Game Space Center" android:theme="@android:style/Theme.Material.NoActionBar" />
        <activity android:name="com.antonyhern16.lowhealth.ShooterActivity" android:exported="true" android:label="Shooter Center" android:icon="@drawable/abc_btn_check_to_on_mtrl_000" android:screenOrientation="sensorLandscape" android:theme="@android:style/Theme.Material.NoActionBar">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        <service android:name="com.antonyhern16.lowhealth.GameSpaceService" android:exported="false" android:foregroundServiceType="specialUse">
            <property android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE" android:value="User-enabled Game Space panel over games" />
        </service>
        <service android:name="com.antonyhern16.lowhealth.LowHealthService" android:exported="false" android:foregroundServiceType="mediaProjection" />
'''
assert "<application" in s and "</application>" in s
if "com.antonyhern16.lowhealth.LowHealthActivity" not in s:
    s = s.replace("<application", add + "    <application", 1)
    s = s.replace("</application>", comp + "    </application>", 1)
open(p, "w", encoding="utf-8").write(s)
print("manifest patched; added permissions:", add.count("uses-permission"))
