# Antonyhern16

- `base/` the current app APK (v27). The workflow adds the new code on top of it.
- `patch/java/` source of Game Hub, **Booster panel**, aim training, profiles, matches, dashboard and the low-health alert.
- `.github/workflows/build.yml` compiles it, merges it into the base APK, signs it and uploads `Antonyhern16.apk`.

## Booster panel (first tab of Game Hub)
- Permission checklist. When Booster opens it walks you through every missing permission, one system screen at a time (Android does not let apps switch these on silently).
- Live status: free RAM, battery, temperature, heat level, storage, refresh rate.
- BOOST & LAUNCH: closes background apps, Do Not Disturb, max brightness, connection check, stats overlay, then starts CODM / PUBG / BGMI. Restore button undoes it.
- Stats overlay (touch-through) and connection/jitter test.
- Copy-ready adb commands for game mode and the bundled start.sh helper.

Nothing here touches the game, its memory or its input.

Phone steps: upload the contents of this folder to a GitHub repository, open Actions, run "Build APK", then download the artifact.

## Game Space panel + Shooter Center
- **Game Space panel** (Booster tab > Game Space Panel): REDMAGIC-style edge panel over your game: status bar, CPU/RAM gauges, tiles, quick toggles, brightness and volume. New tiles: **SHOOTER MODE** and **Shooter Center**.
- **Shooter Center** (own launcher icon, also opened from the panel): Aim Trainer (Precision, Tracking, Flick, Crosshair), Recoil Trainer (simulated kick you must pull back yourself), Gyro Trainer, Reaction Test, Touch Response Test, Sensitivity profiles (12 values, per game, import/export/duplicate/rename/reset), Game Profiles + BOOST & LAUNCH, Performance dashboard.
- All trainer numbers are measured from your own play inside the app. No injection, memory access, aim/fire/recoil automation or anti-cheat bypass.

## Expanded master-prompt integration
This revision adds a runtime **Feature & Capability Center** and `CapabilityMatrix.java`. It exposes the requested Game Space architecture while classifying device/OEM-dependent functions as SUPPORTED, PARTIALLY SUPPORTED, PERMISSION REQUIRED, ROOT REQUIRED, VENDOR API REQUIRED, HARDWARE REQUIRED, or UNSUPPORTED. It never fabricates fan/RGB/bypass-charging/trigger/FPS support. Shooter Center now links directly to this center while preserving its eight primary training modules.

## Game Space Centers (added)
Open from the Game Space panel tiles or from Feature Center (`CenterActivity`). All values come from public Android APIs; anything Android hides shows N/A, Permission required or Vendor restricted.
- **Network Center**: connection type, validation, metered, signal, link estimate, TCP latency/jitter/packet-loss test (10 probes), live traffic, change events (only while open).
- **Cooling & Charging**: battery temp, thermal status/headroom, charging source, voltage/current, recommendation. Fan and bypass charging are reported as not detected.
- **Display**: current/supported refresh rates, HDR, screen timeout, external displays. **Graphics**: GPU, OpenGL ES, Vulkan. **Controllers**: gamepads/keyboards/mice with battery when exposed.
- **Game Statistics**: launches from Game Space, 7-day play time (Usage access). **Game Notes**: per-game notes with pin/delete and tap-to-paste.
- **Panel**: real Stopwatch/Timer (lap, pause, alarm), floating Network and Cooling monitors, idle ping polling removed.
- Not built: performance profiles, touch center, recording, magnifier, equalizer, RGB, assistant, plugin center. Crosshair/counter/trigger overlays stay removed.
Verified only by a parser-level javac pass; not compiled against android.jar, not run on a device.


## Important compatibility note

The supplied APK is used as the build base. APK patching can fail if its package structure, resources, or manifest are incompatible with the patch. A successful GitHub Actions run and installation test are required before considering the merged APK complete. The build adds local Game Space, Shooter Center, performance/status, sensitivity-profile, and training features; it does not add automated aiming, game-memory modification, or anti-cheat bypass.
