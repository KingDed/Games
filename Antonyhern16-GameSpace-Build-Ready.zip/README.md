# Antonyhern16 Game Space — build-ready project

This package uses the uploaded `Antonyhern16_CODM_Training.apk` as the base APK and combines it with the Java source from the Game Space Enhanced and Expanded Updated ZIPs.

## Build status

**This is a build project, not a compiled APK.** This environment has no Android SDK/build-tools and cannot resolve external download hosts, so I cannot compile or device-test the final APK here. The GitHub Actions workflow is intended to build it on a GitHub-hosted runner. It may still fail if the original APK's manifest/resources or the source code are incompatible; review the Actions log if that happens.

## Build on GitHub from a phone

1. Download this ZIP and extract it on your phone, or upload the ZIP contents directly to a new GitHub repository.
2. Make sure `.github/workflows/build.yml` and the `base/`, `patch/` folders are at the repository root.
3. Open the repository's **Actions** tab.
4. Select **Build Antonyhern16 Game Space APK** and tap **Run workflow** (or wait for the first push build).
5. Open the completed run and download the artifact named `Antonyhern16-GameSpace-Enhanced-APK`.
6. Install only after GitHub reports the workflow succeeded. Android may require uninstalling the previous app first if the signing certificate differs; uninstalling can erase local app data.

## Included feature-source areas

- Game Space panel and quick controls
- Shooter Center and local aim/reaction/touch training
- Sensitivity profiles and game profiles
- Performance and capability information
- Network, display, graphics, controller, cooling/charging and game statistics centers where supported by public Android APIs

Device/OEM-specific functions can be restricted by Android or REDMAGIC firmware. The project does not add automated aiming, game-memory modification, or anti-cheat bypass.

## Signing and installation note

The GitHub workflow creates a temporary signing key during the build instead of storing a private key in the repository. Because that key is newly generated for each build, the resulting APK may not update an existing installation in place. If Android reports a signature conflict, uninstall the older app first (this may erase its local data).
